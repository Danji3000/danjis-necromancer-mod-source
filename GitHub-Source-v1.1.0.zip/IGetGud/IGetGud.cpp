// I Get Gud: offline enemy health configuration for the verified ER 1.17.2 build.
// Scale the instance's fresh base stats after the engine initializes them.
// No actor scan, repeated multiplier, parameter mutation, or saved-state patch.
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <bcrypt.h>
#include <stdint.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <wchar.h>
#include <stdlib.h>
#include <cmath>
#include "vendor/minhook/include/MinHook.h"
#include "EnemyIds.h"
#include "Verified.h"
using Ptr=uintptr_t;
using InitializeStats=void(*)(Ptr,Ptr);
static InitializeStats originalNpc=nullptr,originalHuman=nullptr;
static HMODULE selfModule;
static Ptr base=0;
static HANDLE logFile=INVALID_HANDLE_VALUE,instanceMutex=nullptr;
static SRWLOCK logLock=SRWLOCK_INIT;
struct Settings {bool enabled=true;double multiplier=2.0;bool excludeStartBoss=true;};
static Settings settings{};

static void Log(const char* format,...){
 if(logFile==INVALID_HANDLE_VALUE)return;
 char text[768];va_list a;va_start(a,format);int size=_vsnprintf(text,765,format,a);va_end(a);
 if(size<0)return;text[size++]='\r';text[size++]='\n';
 AcquireSRWLockExclusive(&logLock);DWORD written=0;WriteFile(logFile,text,size,&written,nullptr);ReleaseSRWLockExclusive(&logLock);
}
static bool Read(Ptr address,void* result,size_t length){
 SIZE_T got=0;
 return result&&address>=0x10000&&length>0&&length<=0x7fffffffffffULL&&address<=0x7fffffffffffULL-length&&
  ReadProcessMemory(GetCurrentProcess(),(void*)address,result,length,&got)&&got==length;
}
template<class T>static bool Get(Ptr address,T& result){return Read(address,&result,sizeof(result));}
static bool Bool(const wchar_t* text,bool& value){
 if(!wcscmp(text,L"1")){value=true;return true;}if(!wcscmp(text,L"0")){value=false;return true;}return false;
}
static bool Parse(const wchar_t* enabled,const wchar_t* multiplier,const wchar_t* exclude,Settings& out){
 Settings candidate{};wchar_t* end=nullptr;
 if(!Bool(enabled,candidate.enabled)||!Bool(exclude,candidate.excludeStartBoss))return false;
 candidate.multiplier=wcstod(multiplier,&end);
 if(end==multiplier||*end||!std::isfinite(candidate.multiplier)||candidate.multiplier<0.1||candidate.multiplier>10.0)return false;
 out=candidate;return true;
}
static bool LoadSettings(const wchar_t* path){
 wchar_t enabled[32],multiplier[128],exclude[32];
 GetPrivateProfileStringW(L"I Get Gud",L"Enabled",L"1",enabled,32,path);
 GetPrivateProfileStringW(L"I Get Gud",L"HealthMultiplier",L"2.0",multiplier,128,path);
 GetPrivateProfileStringW(L"I Get Gud",L"ExcludeStartingBoss",L"1",exclude,32,path);
 if(!Parse(enabled,multiplier,exclude,settings)){settings.enabled=false;Log("INI_INVALID: no hooks installed; use Enabled=0/1, HealthMultiplier=0.1..10.0, ExcludeStartingBoss=0/1.");return false;}
 return true;
}
// Respect the game's own hard HP cap and avoid narrowing-overflow.
static int Scale(int value,double multiplier,int cap){
 if(value<=0)return value;
 double result=double(value)*multiplier;
 if(result>=cap)return cap;
 int rounded=int(result+0.5);return rounded>0?rounded:1;
}
struct Health{int current,maximum,uncapped,base;};
static bool Adjust(Health& hp,int& initial,double multiplier){
 if(hp.base<=0||hp.maximum<1||hp.maximum>0x7ffff||hp.uncapped<1||hp.current<0||hp.current>hp.maximum||initial<1)return false;
 hp.current=Scale(hp.current,multiplier,0x7ffff);
 hp.maximum=Scale(hp.maximum,multiplier,0x7ffff);
 hp.uncapped=Scale(hp.uncapped,multiplier,0x7fffffff);
 hp.base=Scale(hp.base,multiplier,0x7fffffff);
 initial=Scale(initial,multiplier,0x7fffffff);
 if(hp.current>hp.maximum)hp.current=hp.maximum;
 return true;
}
#include "Rematches.h"
static bool Eligible(Ptr data,int& npc){

 Ptr header[2]{};
 if(!Read(data,header,sizeof(header))||header[0]!=base+0x2a3a0c8||!header[1])return false;
 const Ptr chr=header[1];
 // One guarded snapshot replaces separate identity/module/entity reads.
 unsigned char identity[0x1ec]{};
 if(!Read(chr,identity,sizeof(identity)))return false;
 Ptr chrType=0,modules=0,ownedData=0,world=0,player=0;int entity=0;
 memcpy(&chrType,identity,8);memcpy(&npc,identity+0x60,4);
 memcpy(&modules,identity+0x190,8);memcpy(&entity,identity+0x1e8,4);
 const unsigned char team=identity[0x6c];
 if(chrType!=base+0x2a49090&&chrType!=base+0x2a81cb0)return false;
 if(team==2||team==5||team==8||team==10||team==26||team==28||team==30||team==47)return false;
 if(!EnemyNpc(npc)&&!RematchNpc(npc))return false;
 if(settings.excludeStartBoss&&(npc==46900008||entity==10010800))return false;
 if(!Get(modules,ownedData)||ownedData!=data)return false;
 if(Get(base+0x3d6d018,world)&&world&&Get(world+0x1e508,player)&&player==chr)return false;
 return true;
}
// The verified initializer only reads its source synchronously; it does not
// retain the source address. Private stack copies never mutate shared params.
static void HookNpc(Ptr data,Ptr source){
 int npc=0;Ptr row=0;unsigned char copy[0xf8]{};
 if(source&&Eligible(data,npc)&&Get(source,row)&&Read(row,copy,sizeof(copy))){
  int hp=0;memcpy(&hp,copy+0x24,4);
  if(hp>0){hp=Scale(hp,FactorForNpc(npc),0x7fffffff);memcpy(copy+0x24,&hp,4);
   Ptr localRow=(Ptr)copy;originalNpc(data,(Ptr)&localRow);return;}
 }
 originalNpc(data,source);
}
static void HookHuman(Ptr data,Ptr source){
 int npc=0;unsigned char copy[0x38]{};
 if(source&&Eligible(data,npc)&&Read(source,copy,sizeof(copy))){
  int hp[3]{};memcpy(hp,copy+0x10,sizeof(hp));
  if(hp[0]>=0&&hp[1]>0&&hp[2]>0&&hp[0]<=hp[1]){
   hp[0]=Scale(hp[0],FactorForNpc(npc),0x7ffff);
   hp[1]=Scale(hp[1],FactorForNpc(npc),0x7fffffff);
   hp[2]=Scale(hp[2],FactorForNpc(npc),0x7fffffff);
   memcpy(copy+0x10,hp,sizeof(hp));originalHuman(data,(Ptr)copy);return;
  }
 }
 originalHuman(data,source);
}
static bool VerifyCode(){
 unsigned char buffer[128];
 for(const auto& s:signatures){if(s.size>sizeof(buffer)||!Read(base+s.rva,buffer,s.size)||memcmp(buffer,s.bytes,s.size))return false;}
 return true;
}
static bool HashFile(const wchar_t* path,unsigned char digest[32]){
 HANDLE file=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ,nullptr,OPEN_EXISTING,0,nullptr);
 if(file==INVALID_HANDLE_VALUE)return false;
 BCRYPT_ALG_HANDLE alg=nullptr;BCRYPT_HASH_HANDLE hash=nullptr;bool ok=false;DWORD count=0;unsigned char buffer[65536];
 if(BCryptOpenAlgorithmProvider(&alg,BCRYPT_SHA256_ALGORITHM,nullptr,0)<0)goto done;
 if(BCryptCreateHash(alg,&hash,nullptr,0,nullptr,0,0)<0)goto done;
 for(;;){if(!ReadFile(file,buffer,sizeof(buffer),&count,nullptr))goto done;if(!count)break;if(BCryptHashData(hash,buffer,count,0)<0)goto done;}
 ok=BCryptFinishHash(hash,digest,32,0)>=0;
done:
 if(hash)BCryptDestroyHash(hash);if(alg)BCryptCloseAlgorithmProvider(alg,0);CloseHandle(file);return ok;
}
static bool Install(){
 if(!VerifyCode()){Log("SIGNATURE_REJECTED: no hooks installed");return false;}
 if(MH_Initialize()!=MH_OK)return false;
 MH_STATUS status=MH_CreateHook((void*)(base+0x439040),(void*)&HookNpc,(void**)&originalNpc);
 if(status==MH_OK)status=MH_CreateHook((void*)(base+0x4391f0),(void*)&HookHuman,(void**)&originalHuman);
 if(status==MH_OK)status=MH_QueueEnableHook(MH_ALL_HOOKS);
 if(status==MH_OK)status=MH_ApplyQueued();
 if(status!=MH_OK){MH_DisableHook(MH_ALL_HOOKS);MH_Uninitialize();Log("HOOK_INSTALL_FAILED status=%d",int(status));return false;}
 Log("HOOKS_INSTALLED: two stat-initialization hooks; private HP inputs; original engine setters; no post-initialization writes; no per-NPC logging, polling or world scans; restart to apply INI changes");return true;
}
static DWORD WINAPI Start(void*){
 HMODULE pinned=nullptr;if(!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_PIN,(LPCWSTR)&Start,&pinned))return 0;
 instanceMutex=CreateMutexW(nullptr,FALSE,L"Local\\IGetGud272");if(!instanceMutex)return 0;
 if(GetLastError()==ERROR_ALREADY_EXISTS){CloseHandle(instanceMutex);instanceMutex=nullptr;return 0;}
 wchar_t path[32768];DWORD length=GetModuleFileNameW(selfModule,path,32768);if(!length||length>=32760)return 0;
 wchar_t* dot=wcsrchr(path,L'.');if(!dot)return 0;
 wcscpy(dot,L".log");logFile=CreateFileW(path,GENERIC_WRITE,FILE_SHARE_READ,nullptr,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,nullptr);
 wcscpy(dot,L".ini");if(!LoadSettings(path))return 0;
 Log("I Get Gud v3.2 rematch difficulty / factor=%.3f enabled=%d exclude_starting_boss=%d",settings.multiplier,settings.enabled,settings.excludeStartBoss);
 // Rematch Hard/Hardcore remain available even when normal-world scaling is disabled.
 unsigned char digest[32];
 DWORD exeLength=GetModuleFileNameW(nullptr,path,32768);
 if(!exeLength||exeLength>=32768||!HashFile(path,digest)||memcmp(digest,expectedSha256,32)){Log("EXE_HASH_REJECTED: no game reads, writes or hooks");return 0;}
 base=(Ptr)GetModuleHandleW(nullptr);if(base)Install();return 0;
}
extern "C" BOOL WINAPI DllMain(HMODULE module,DWORD reason,LPVOID){
 if(reason==DLL_PROCESS_ATTACH){selfModule=module;DisableThreadLibraryCalls(module);HANDLE thread=CreateThread(nullptr,0,Start,nullptr,0,nullptr);if(thread)CloseHandle(thread);}return TRUE;
}
