// HUD-only call replacement. Original area result OR the selected-staff gate.
// Callsite 0x771f92 belongs to the HUD update, not summon eligibility.
static const unsigned char hudOriginal[]={0xe8,0x59,0x57,0xd4,0xff};
static const unsigned char hudStub[]={0xe8,0x00,0x00,0x00,0x00,0x80,0x3d,0xf4,0x0a,0x00,0x00,0x00,0x74,0x02,0xb0,0x01,0xe9,0x00,0x00,0x00,0x00};
static void Relocate_hud(unsigned char* bridge,uintptr_t base){
 int32_t call=(int32_t)((base+0x4b76f0)-((uintptr_t)bridge+1280+5));
 int32_t back=(int32_t)((base+0x771f97)-((uintptr_t)bridge+1280+21));
 memcpy(bridge+1280+1,&call,4);memcpy(bridge+1280+17,&back,4);
}
