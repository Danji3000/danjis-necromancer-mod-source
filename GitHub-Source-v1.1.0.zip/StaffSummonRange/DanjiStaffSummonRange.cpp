// Staff-gated monument range experiment for exact Elden Ring 2.7.2.0 executable.
// Experimental test build: engine integration still requires an offline game test.
// Equipment references: fromsoftware-rs; generated getter checks in verification.json.
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <bcrypt.h>
#include <cstdint>
#include <cstdio>
#include <cstdarg>
#include <cstring>
#include <cwchar>
#include <cstdlib>
#include <cmath>
#include "patch_bytes.h"
#include "world_hooks.h"
#include "hud_hook.h"
static const unsigned char expectedSha256[]={0xf9,0x11,0x8f,0xea,0x2c,0xfd,0x8f,0xa3,0x90,0x1e,0x80,0x60,0xbf,0xad,0xb1,0x55,0x2c,0xb2,0x47,0x17,0x71,0xde,0xd8,0xa5,0xb6,0x62,0xc4,0xe2,0x98,0xff,0xb3,0x28};

using Ptr=uintptr_t;
static HMODULE selfModule;
static Ptr base;
static HANDLE logFile=INVALID_HANDLE_VALUE, instanceMutex;
static SRWLOCK logLock=SRWLOCK_INIT;
static volatile LONG stopped=0;

static void Log(const char* format,...) {
    char line[1024]; va_list args; va_start(args,format);
    int count=_vsnprintf(line,sizeof(line)-3,format,args); va_end(args);
    if(count<0)return;
    size_t n=(size_t)count; if(n>sizeof(line)-4)n=sizeof(line)-4;
    line[n++]='\r';line[n++]='\n';
    AcquireSRWLockExclusive(&logLock);
    if(logFile!=INVALID_HANDLE_VALUE){DWORD written=0;WriteFile(logFile,line,(DWORD)n,&written,nullptr);}
    ReleaseSRWLockExclusive(&logLock);
}
static bool Read(Ptr address,void* out,size_t size) {
    if(!out || !size || size>0x7fffffffffffULL || address<0x10000 || address>0x7fffffffffffULL-size)return false;
    SIZE_T got=0;
    return ReadProcessMemory(GetCurrentProcess(),(void*)address,out,size,&got) && got==size;
}
template<class T> static bool ReadValue(Ptr address,T& out){return Read(address,&out,sizeof(out));}
static bool Typed(Ptr object,Ptr rva){Ptr vt=0;return ReadValue(object,vt)&&vt==base+rva;}
static bool HashFile(const wchar_t* path,unsigned char digest[32]) {
    HANDLE file=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ,nullptr,OPEN_EXISTING,0,nullptr);
    if(file==INVALID_HANDLE_VALUE)return false;
    BCRYPT_ALG_HANDLE alg=nullptr; BCRYPT_HASH_HANDLE hash=nullptr;
    bool ok=false; DWORD count=0; unsigned char buffer[65536];
    if(BCryptOpenAlgorithmProvider(&alg,BCRYPT_SHA256_ALGORITHM,nullptr,0)<0)goto cleanup;
    if(BCryptCreateHash(alg,&hash,nullptr,0,nullptr,0,0)<0)goto cleanup;
    for(;;){
        if(!ReadFile(file,buffer,sizeof(buffer),&count,nullptr))goto cleanup;
        if(count==0)break;
        if(BCryptHashData(hash,buffer,count,0)<0)goto cleanup;
    }
    ok=BCryptFinishHash(hash,digest,32,0)>=0;
cleanup:
    if(hash)BCryptDestroyHash(hash);
    if(alg)BCryptCloseAlgorithmProvider(alg,0);
    CloseHandle(file);return ok;
}
static bool VerifyBuild(){
 wchar_t path[32768]; DWORD length=GetModuleFileNameW(nullptr,path,32768);
 if(!length || length>=32768)return false;
 unsigned char digest[32];
 return HashFile(path,digest)&&memcmp(digest,expectedSha256,32)==0;
}


static unsigned char* bridge=nullptr;
// Only valid before any game hook points to this allocation.
static void ReleaseUnusedBridge(){
 if(bridge && VirtualFree(bridge,0,MEM_RELEASE))bridge=nullptr;
}
static bool SelectedStaff(int& left,int& right){
 Ptr world=0,player=0,assembly=0;uint32_t style=0,slots[2]={};int ids[6]={};
 if(!ReadValue(base+0x3d6d018,world)||!Typed(world,0x2a509d0))return false;
 if(!ReadValue(world+0x1e508,player)||!Typed(player,0x2a81cb0))return false;
 if(!ReadValue(player+0x638,assembly)||!ReadValue(assembly+8,style)||style>3)return false;
 if(!Read(assembly+0xc,slots,sizeof(slots))||slots[0]>2||slots[1]>2||!Read(assembly+0x7c,ids,sizeof(ids)))return false;
 left=ids[2*slots[0]];right=ids[2*slots[1]+1];
 static uint32_t oldStyle=~0u,oldLeft=~0u,oldRight=~0u;
 if(style!=oldStyle||slots[0]!=oldLeft||slots[1]!=oldRight){
  Log("EQUIPMENT style=%u left_slot=%u right_slot=%u selected_left=%d selected_right=%d",style,slots[0],slots[1],left,right);
  oldStyle=style;oldLeft=slots[0];oldRight=slots[1];
 }
 // Both selected hand slots qualify, including a staff stowed while two-handing.
 return (left>=33990000&&left<=33990025)||(right>=33990000&&right<=33990025)||
        (left>=33800000&&left<=33800025)||(right>=33800000&&right<=33800025);
}
static bool Install(){
 Ptr world=0,player=0;
 if(!ReadValue(base+0x3d6d018,world)){Log("WORLD_READ_REJECTED");return false;}
 if(world&&(!Typed(world,0x2a509d0)||!ReadValue(world+0x1e508,player)||player)){Log("LATE_LOAD_REJECTED: restart game; no live patch installed.");return false;}
 const Ptr site=base+0xea2c67;
 unsigned char original[sizeof(originalBytes)]={};
 if(!Read(site,original,sizeof(original))||memcmp(original,originalBytes,sizeof(original))){Log("SIGNATURE_REJECTED");return false;}
 unsigned char hudBytes[5];
 if(!Read(base+0x771f92,hudBytes,5)||memcmp(hudBytes,hudOriginal,5)){Log("HUD_SIGNATURE_REJECTED");return false;}
 unsigned char eligibilityBytes[7],spawnBytes[5];
 if(!Read(base+0x4b744d,eligibilityBytes,7)||memcmp(eligibilityBytes,worldEligibilityOriginal,7)||
    !Read(base+0x4b86fa,spawnBytes,5)||memcmp(spawnBytes,worldSpawnOriginal,5)){
  Log("WORLD_SIGNATURE_REJECTED");return false;
 }
 unsigned char checkRegion[8],checkActivation[8],checkFlag[8],checkManager[7];
 if(!Read(base+0x4bdd22,checkManager,7)||memcmp(checkManager,managerOriginal,7)||!Read(base+0xea6c59,checkFlag,7)||memcmp(checkFlag,usedflagOriginal,7)||!Read(base+0xea6fcd,checkRegion,8)||memcmp(checkRegion,regionOriginal,8)||
    !Read(base+0xea701e,checkActivation,8)||memcmp(checkActivation,activationOriginal,8)){
  Log("GETTER_SIGNATURE_REJECTED");return false;
 }
 for(Ptr delta=0x10000;delta<0x70000000;delta+=0x10000){
  Ptr candidate=(site&~(Ptr)0xffff)+delta;
  bridge=(unsigned char*)VirtualAlloc((void*)candidate,8192,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE);
  if(bridge)break;
 }
 if(!bridge){Log("NEAR_ALLOCATION_FAILED");return false;}
 memcpy(bridge,stubBytes,sizeof(stubBytes));
 for(unsigned pos: returnDisplacements){int32_t rel=(int32_t)((site+12)-((Ptr)bridge+pos+4));memcpy(bridge+pos,&rel,4);}
 memcpy(bridge+128,regionStub,sizeof(regionStub));
 memcpy(bridge+256,activationStub,sizeof(activationStub));
 int32_t regionRel=(int32_t)((base+0xea6c69)-((Ptr)bridge+128+regionReturn+4));
 memcpy(bridge+128+regionReturn,&regionRel,4);
 int32_t activationRel=(int32_t)((base+0xea7026)-((Ptr)bridge+256+activationReturn+4));
 memcpy(bridge+256+activationReturn,&activationRel,4);
 memcpy(bridge+384,usedflagStub,sizeof(usedflagStub));
 int32_t flagRel=(int32_t)((base+0xea6c69)-((Ptr)bridge+384+30));
 memcpy(bridge+384+26,&flagRel,4);
 int32_t flagOriginalRel=(int32_t)((base+0xea6c60)-((Ptr)bridge+384+39));
 memcpy(bridge+384+35,&flagOriginalRel,4);
 memcpy(bridge+512,managerStub,sizeof(managerStub));
 int32_t managerRel=(int32_t)((base+0x4bdd29)-((Ptr)bridge+512+35));memcpy(bridge+512+31,&managerRel,4);
 memcpy(bridge+768,worldEligibilityStub,sizeof(worldEligibilityStub));
 Relocate_worldEligibility(bridge,base);
 memcpy(bridge+1024,worldSpawnStub,sizeof(worldSpawnStub));
 Relocate_worldSpawn(bridge,base);
 memcpy(bridge+1280,hudStub,sizeof(hudStub));
 Relocate_hud(bridge,base);
 float radius=1000.0f;memcpy(bridge+4100,&radius,4);bridge[4096]=0;
 DWORD old=0;
 if(!VirtualProtect(bridge,4096,PAGE_EXECUTE_READ,&old)){Log("BRIDGE_PROTECTION_FAILED");ReleaseUnusedBridge();return false;}
 if(!FlushInstructionCache(GetCurrentProcess(),bridge,4096)){Log("BRIDGE_CACHE_FLUSH_FAILED: no hooks written");ReleaseUnusedBridge();return false;}
 const Ptr sites[]={site,base+0xea6fcd,base+0xea701e,base+0xea6c59,base+0x4bdd22,base+0x4b744d,base+0x4b86fa,base+0x771f92};
 const unsigned lengths[]={12,8,8,7,7,7,5,5},offsets[]={0,128,256,384,512,768,1024,1280};DWORD protections[8]={};
 for(unsigned i=0;i<8;++i){
  if(!VirtualProtect((void*)sites[i],lengths[i],PAGE_EXECUTE_READWRITE,&protections[i])){
   for(int j=(int)i-1;j>=0;--j){DWORD ignored;VirtualProtect((void*)sites[j],lengths[j],protections[j],&ignored);}
   Log("SITE_PROTECTION_FAILED: no hooks written");ReleaseUnusedBridge();return false;
  }
 }
 for(unsigned i=0;i<8;++i){
  unsigned char patch[12];memset(patch,0x90,sizeof(patch));patch[0]=0xe9;
  int32_t rel=(int32_t)(((Ptr)bridge+offsets[i])-(sites[i]+5));memcpy(patch+1,&rel,4);
  memcpy((void*)sites[i],patch,lengths[i]);FlushInstructionCache(GetCurrentProcess(),(void*)sites[i],lengths[i]);
 }
 // Two getter sites share a page: restore in reverse order to recover original protection.
 for(int i=7;i>=0;--i){DWORD ignored;if(!VirtualProtect((void*)sites[i],lengths[i],protections[i],&ignored))Log("WARNING: protection restoration failed");}
 Log("HOOKS_INSTALLED v8: original eight v7 hooks preserved; selected Necromancer or Novice staff qualifies. No bell item or event-flag mutation. New-character bell-free test pending.");return true;
}
static DWORD WINAPI Start(void*){
 HMODULE pinned=nullptr;
 if(!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_PIN,(LPCWSTR)&Start,&pinned))return 0;
 instanceMutex=CreateMutexW(nullptr,FALSE,L"Local\\DanjiStaffSummonRange272");
 if(!instanceMutex)return 0;
 if(GetLastError()==ERROR_ALREADY_EXISTS){CloseHandle(instanceMutex);instanceMutex=nullptr;return 0;}
 wchar_t path[32768];DWORD n=GetModuleFileNameW(selfModule,path,32768);if(!n||n>=32760)return 0;
 wchar_t* dot=wcsrchr(path,L'.');if(!dot)return 0;wcscpy(dot,L".log");
 logFile=CreateFileW(path,GENERIC_WRITE,FILE_SHARE_READ,nullptr,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,nullptr);
 if(logFile==INVALID_HANDLE_VALUE)return 0;
 Log("Danji Staff Summon Range v8.1 review candidate / novice staff 33800000..33800025 added; original behavior preserved");
 base=(Ptr)GetModuleHandleW(nullptr);
 if(!base||!VerifyBuild()){Log("EXE_HASH_REJECTED: no game memory modified.");return 0;}
 if(!Install())return 0;
 int previous=-1;unsigned reportTick=0;int priorStone=-2147483647,priorUsed=-2147483647,priorState=-2147483647;
 // Diagnostic reads only twice a second, log only changed context. No NPC scan.

 while(!InterlockedCompareExchange(&stopped,0,0)){
  int left=-1,right=-1;bool selected=SelectedStaff(left,right);
  *(volatile unsigned char*)(bridge+4096)=selected?1:0;
  if(previous!=(int)selected){Log("STAFF_GATE=%d selected_left=%d selected_right=%d",(int)selected,left,right);previous=(int)selected;}
  if(++reportTick>=5){
   reportTick=0;Ptr world=0,manager=0;int stone=0,used=0,state=-1;
   if(selected&&ReadValue(base+0x3d6d018,world)&&world&&ReadValue(world+0x1e538,manager)&&manager&&
      ReadValue(manager+0x38,stone)&&ReadValue(manager+0x3c,used)&&ReadValue(manager+0x20,state)){
    if(stone!=priorStone||used!=priorUsed||state!=priorState){
     Log("AREA_CONTEXT selected=1 monument=%d last_monument=%d active_request=%d",stone,used,state);
     priorStone=stone;priorUsed=used;priorState=state;
    }
   }
  }
  Sleep(100);
 }
 return 0;
}
extern "C" BOOL WINAPI DllMain(HMODULE module,DWORD reason,LPVOID){
 if(reason==DLL_PROCESS_ATTACH){selfModule=module;DisableThreadLibraryCalls(module);HANDLE t=CreateThread(nullptr,0,Start,nullptr,0,nullptr);if(t)CloseHandle(t);}
 if(reason==DLL_PROCESS_DETACH)InterlockedExchange(&stopped,1);
 return TRUE;
}
