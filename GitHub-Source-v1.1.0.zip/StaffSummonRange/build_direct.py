import os,pathlib,subprocess,ctypes,sys,struct
root=pathlib.Path(__file__).resolve().parent
zig=pathlib.Path(os.environ['FP_ZIG']).resolve();assert zig.exists(),zig
os.environ['ZIG_LIB_DIR']=str(zig.parent/'lib')
os.environ['ZIG_GLOBAL_CACHE_DIR']=str(root/'build-cache-global')
os.environ['ZIG_LOCAL_CACHE_DIR']=str(root/'build-cache')
os.environ['TMP']=os.environ['TEMP']=str(root/'temp');(root/'temp').mkdir(exist_ok=True)
source=sys.argv[1] if len(sys.argv)>1 else 'DanjisFPRegen.cpp'
output=sys.argv[2] if len(sys.argv)>2 else 'Danjis FP Regen.dll'
isdll=output.endswith('.dll');os.chdir(root)
common=['-target','x86_64-windows-gnu','-std=c++17','-O2','-Wall','-Wextra','-fno-exceptions','-fno-rtti']
p=subprocess.run([str(zig),'c++','-v',*common,'-c',source,'-o','direct.obj'],capture_output=True,text=True)
line=next((x.strip() for x in p.stderr.splitlines() if x.strip().startswith('"') and ' -cc1 ' in x),None)
if not line:print(p.stderr);sys.exit(1)
n=ctypes.c_int();parse=ctypes.windll.shell32.CommandLineToArgvW
parse.restype=ctypes.POINTER(ctypes.c_wchar_p);parse.argtypes=[ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_int)]
a=parse(line,ctypes.byref(n));args=[a[i] for i in range(n.value)];args[args.index('-o')+1]='direct.obj'
args.remove('-v');subprocess.run(args,check=True)
subprocess.run([str(zig),'-cc1as','-triple','x86_64-windows-gnu','-filetype','obj','stack_probe.s','-o','stack_probe.obj'],check=True)
# Import libraries list the Windows APIs and system CRT used by this program.
libs={
'kernel32':['DisableThreadLibraryCalls','CreateThread','CloseHandle','GetModuleHandleExW','GetCurrentProcessId','CreateMutexW','GetLastError','GetModuleFileNameW','CreateFileW','GetModuleHandleW','Sleep','VirtualAlloc','VirtualFree','VirtualQuery','VirtualProtect','FlushInstructionCache','GetProcessHeap','HeapAlloc','HeapFree','ReadFile','GetCurrentProcess','ReadProcessMemory','GetCurrentThreadId','AcquireSRWLockExclusive','WriteFile','FlushFileBuffers','ReleaseSRWLockExclusive','GetPrivateProfileStringW','GetTickCount64','LoadLibraryW','ExitProcess'],
'version':['GetFileVersionInfoSizeW','GetFileVersionInfoW','VerQueryValueW'],
'bcrypt':['BCryptOpenAlgorithmProvider','BCryptCreateHash','BCryptHashData','BCryptFinishHash','BCryptDestroyHash','BCryptCloseAlgorithmProvider'],
'msvcrt':['_snwprintf','wcsrchr','wcscpy','printf','calloc','memcpy','memset','puts','exit','memcmp','wcscmp','_vsnprintf','wcstod']}
for dll,names in libs.items():
 pathlib.Path(dll+'.def').write_text('LIBRARY '+dll+'.dll\nEXPORTS\n'+'\n'.join(names)+'\n')
 subprocess.run([str(zig),'dlltool','-m','i386:x86-64','-d',dll+'.def','-l',dll+'.lib'],check=True)
subprocess.run([str(zig),'lld-link','/machine:x64','/nodefaultlib','/dynamicbase','/nxcompat','/opt:ref','/opt:icf','/Brepro',*(['/dll','/entry:DllMain'] if isdll else ['/subsystem:console','/entry:main']),'/out:'+output,'direct.obj','stack_probe.obj',*[k+'.lib' for k in libs]],check=True)
b=pathlib.Path(output).read_bytes();assert b[:2]==b'MZ';print('Built PE x64: '+output+' ('+str(len(b))+' bytes)')

