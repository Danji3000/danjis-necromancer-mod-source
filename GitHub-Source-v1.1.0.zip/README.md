# Danji's Necromancer Mod — v1.1.0 native source

Reproducible source for the four native Windows x64 DLLs distributed with
[Danji's Necromancer Mod](https://www.nexusmods.com/eldenring/mods/11615).
This repository is for transparency and security review. It does not contain
the game, mod assets, save files, compiled DLLs, or a launcher.

## Build

Windows x64, Python 3.12 (tested 3.12.14), and the complete
[Zig 0.15.2 distribution](https://ziglang.org/download/) are required.
No additional Python packages are required.

In PowerShell from this directory:

```powershell
$env:FP_ZIG = 'C:\Tools\zig-0.15.2\zig.exe'
py -3.12 build_all.py
```

Results appear in `_build/native`. The script compares SHA256 hashes with
`modules.json` and fails if they differ. All four rebuilds matched the v1.1.0
release byte-for-byte; see `BUILD_VERIFICATION.json`. Read `BUILD_EN.txt` for
details, including the original build filename of the spells DLL.

## Modules

| Directory | Function |
|---|---|
| Deathblight | Custom deathblight effect behavior |
| NecromancerSpells | Custom summons and spells |
| StaffSummonRange | Staff-dependent spirit summon eligibility and range |
| IGetGud | Configurable enemy health and rematch health scaling |

The modules use current-process memory access and runtime gameplay hooks.
The host executable is verified before installing gameplay hooks. Three
modules include MinHook; StaffSummonRange uses direct inline patches.

## Security review status

The release is quarantined on Nexus. VirusTotal hash lookups on November 15,
2026 reported detections for all four DLLs (5/71, 6/54, 16/71 and 5/71,
respectively in the table order). A prior local Defender scan found no threats;
that does not override the VirusTotal findings or establish vendor clearance.
False positives are suspected but not confirmed. No antivirus bypass or
protection-disabling instructions are provided here.

## Licensing

Third-party notices are in `licenses/` and vendor directories. No blanket
license is granted over those components or game assets. Project-authored
source is published for inspection and reproducibility; no additional general
redistribution license is specified. A repository owner may add an appropriate
license for their own contributions separately.
