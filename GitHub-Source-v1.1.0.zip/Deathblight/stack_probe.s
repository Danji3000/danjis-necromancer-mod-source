.text
.globl ___chkstk_ms
___chkstk_ms:
 pushq %rcx
 pushq %rax
 cmpq $4096, %rax
 leaq 24(%rsp), %rcx
 jb 2f
1:
 subq $4096, %rcx
 testq %rcx, (%rcx)
 subq $4096, %rax
 cmpq $4096, %rax
 ja 1b
2:
 subq %rax, %rcx
 testq %rcx, (%rcx)
 popq %rax
 popq %rcx
 retq
.globl __main
__main:
 retq
