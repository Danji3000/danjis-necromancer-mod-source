#pragma once
#include <stdint.h>
namespace Deathblight {
constexpr int Marker=890310, Holy=890312;
constexpr int First=8904000, Stride=10, Slots=64, Phases=6;
inline bool Hostile(unsigned team) {
    switch(team){case 6:case 7:case 9:case 11:case 21:case 23:case 24:case 25:case 27:case 29:case 33:case 48:case 49:case 50:case 51:case 52:case 54:case 55:case 56:case 57:case 58:case 59:case 60:case 61:case 63:case 64:case 65:case 66:return true;default:return false;}
}
inline int Slot(int effect) {
    int n=effect-First;
    return n>=0 && n<Stride*Slots && n%Stride<Phases ? n/Stride : -1;
}
inline int Available(uint64_t used) {
    for(int i=0;i<Slots;++i)if(!(used&(uint64_t(1)<<i)))return First+i*Stride;
    return -1; // Never overwrite an unfinished proc, even at the safety ceiling.
}
}
