// Own offline gameplay adapter. No Convergence code/assets.
// The engine owns effect lifetime, damage, expiry, death and unload cleanup.
// We keep no actor pointers between calls and perform no per-frame world scan.
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <bcrypt.h>
#include <stdint.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <wchar.h>
#include "vendor/minhook/include/MinHook.h"
#include "DeathblightRules.h"
#include "HumanRules.h"
#include "verified_signatures.h"
using Ptr=uintptr_t;
// Verified x64 arguments at 3e9175/3e9294/3e9384 and 3fb0a0..3fb302.
using Apply=bool(*)(Ptr,int,Ptr,Ptr,Ptr,unsigned char,unsigned char,unsigned char);
static Apply originalApply;
static Ptr base;
static HMODULE selfModule;
static HANDLE logFile=INVALID_HANDLE_VALUE;
static SRWLOCK logLock=SRWLOCK_INIT;
static LONG completed=0;
static bool Read(Ptr address,void* out,size_t n) {
    SIZE_T got=0;
    return address>=0x10000 && address<0x7fffffffffffULL-n &&
        ReadProcessMemory(GetCurrentProcess(),(void*)address,out,n,&got) && got==n;
}
template<class T> static bool Value(Ptr address,T& out){return Read(address,&out,sizeof(out));}
static void Log(const char* format,...) {
    if(logFile==INVALID_HANDLE_VALUE)return;
    char line[512];va_list a;va_start(a,format);int n=_vsnprintf(line,509,format,a);va_end(a);
    if(n<0)return;line[n++]='\r';line[n++]='\n';
    AcquireSRWLockExclusive(&logLock);DWORD done;
    WriteFile(logFile,line,n,&done,nullptr);ReleaseSRWLockExclusive(&logLock);
}
#include "EngineRefresh.h"
static const unsigned char removeBytes[]={0x48,0x8b,0x89,0x78,0x1,0x0,0x0,0xe9,0x74,0x94,0x10,0x0};
using RemoveEffect=bool(*)(Ptr,int); static RemoveEffect removeEffect;
static bool HashFile(const wchar_t* path,unsigned char out[32]) {
    HANDLE f=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ,nullptr,OPEN_EXISTING,0,nullptr);
    if(f==INVALID_HANDLE_VALUE)return false;
    BCRYPT_ALG_HANDLE alg=nullptr;BCRYPT_HASH_HANDLE h=nullptr;
    bool ok=false;DWORD n=0;unsigned char buffer[65536];
    if(BCryptOpenAlgorithmProvider(&alg,BCRYPT_SHA256_ALGORITHM,nullptr,0)<0)goto end;
    if(BCryptCreateHash(alg,&h,nullptr,0,nullptr,0,0)<0)goto end;
    for(;;){if(!ReadFile(f,buffer,sizeof(buffer),&n,nullptr))goto end;if(!n)break;if(BCryptHashData(h,buffer,n,0)<0)goto end;}
    ok=BCryptFinishHash(h,out,32,0)>=0;
end:
    if(h)BCryptDestroyHash(h);if(alg)BCryptCloseAlgorithmProvider(alg,0);CloseHandle(f);return ok;
}
// A bounded read of THIS live receiver's effect list, only on a confirmed proc.
// Even an expiring entry reserves its slot until the engine actually unlinks it.
static bool FindFree(Ptr chr,int& id,unsigned& active,int first=Deathblight::First) {
    Ptr effects=0,owner=0,node=0;
    if(!Value(chr+0x178,effects)||!Value(effects+0x10,owner)||owner!=chr||!Value(effects+8,node))return false;
    uint64_t used=0;
    for(unsigned n=0;node && n<2048;++n){
        unsigned char data[0x38];if(!Read(node,data,sizeof(data)))return false;
        int effect;Ptr next;memcpy(&effect,data+8,4);memcpy(&next,data+0x30,8);
        int slot=Deathblight::Slot(effect-first+Deathblight::First);if(slot>=0)used|=uint64_t(1)<<slot;
        if(next==node)return false;node=next;
    }
    if(node)return false; // corrupt/cyclic/oversize lists fail closed.
    active=0;for(uint64_t n=used;n;n&=n-1)++active;
    id=Deathblight::Available(used);if(id>=0)id+=first-Deathblight::First;return true;
}
static bool Eligible(Ptr chr,int& hp,int& maximum,unsigned char& team,bool human=false) {
    Ptr world=0,player=0,modules=0,data=0;
    if(!Value(base+0x3d6d018,world)||!world||!Value(world+0x1e508,player)||!player||chr==player)return false;
    if(!Value(chr+0x6c,team))return false;
    int npc=-1;
    if(!Deathblight::Hostile(team) && !(human && Value(chr+0x60,npc) && HumanDeathblight::SpecialHostile(npc,team)))return false;
    if(!Value(chr+0x190,modules)||!Value(modules,data)||!data)return false;
    if(!Value(data+0x138,hp)||!Value(data+0x13c,maximum))return false;
    return hp>0 && maximum>0 && hp<=maximum;
}
// Exact NPC-param IDs, never the local player, summoned helpers or a blanket
// Team1 exemption. Runs only for a completed Deathblight proc (effect70).
static int HumanRoute(Ptr chr) {
    int npc=-1;
    if(!Value(chr+0x60,npc))return 0;
    int route=HumanDeathblight::IsVanilla(npc)?1:(HumanDeathblight::IsCustom(npc)?2:0);
    if(!route)return 0;
    int hp=0,max=0;unsigned char team=0;
    return Eligible(chr,hp,max,team,true)?route:0;
}
static bool HookApply(Ptr chr,int effect,Ptr source,Ptr context,Ptr extra,unsigned char a,unsigned char b,unsigned char c) {
    bool human=false;
    if(effect==70){
        int route=HumanRoute(chr);
        if(route==1)return originalApply(chr,HumanDeathblight::Vanilla,source,context,extra,a,b,c);
        if(route==2){effect=HumanDeathblight::Marker;human=true;}
    }
    // A private human marker cannot act as an alternative route for players,
    // allies or ordinary NPCs, even if another source tries to apply it.
    if(effect==HumanDeathblight::Marker && !human){
        if(HumanRoute(chr)!=2)return false;
        human=true;
    }
    bool accepted=originalApply(chr,effect,source,context,extra,a,b,c);
    if((effect!=Deathblight::Marker&&!human)||!accepted)return accepted;
    if(!human){
        int npc=-1;
        if(Value(chr+0x60,npc) && (HumanDeathblight::IsVanilla(npc)||HumanDeathblight::IsCustom(npc)||HumanDeathblight::IsProtectedUndead(npc)))return accepted;
    }
    int hp=0,maximum=0,free=-1;unsigned active=0;unsigned char team=0;
    if(!Eligible(chr,hp,maximum,team,human)){Log("PROC_SKIPPED ineligible team=%u",team);return accepted;}
    if(!FindFree(chr,free,active,human?HumanDeathblight::First:Deathblight::First)){Log("PROC_SKIPPED invalid effect list");return accepted;}
    // Call the unhooked trampoline with ALL original arguments. Child effects
    // retain the engine's source/attribution and run on the current game thread.
    bool damage=free>=0 && originalApply(chr,free,source,context,extra,a,b,c);
    float prior=-1,remaining=-1;
    const int holyId=human?HumanDeathblight::Holy:Deathblight::Holy;
    bool refreshed=false;
    bool holy=RenewEffect(chr,holyId,Read,removeEffect,[&](){return originalApply(chr,holyId,source,context,extra,a,b,c);},prior,remaining,refreshed);
    uint64_t handle=0;Value(chr+8,handle);
    Log("PROC handle=%llx team=%u human=%d hp=%d max=%d active_before=%u slot=%d dot=%d holy=%d chr=%llx refreshed=%d holy_before=%.3f holy_after=%.3f",(unsigned long long)handle,team,human,hp,maximum,active,free,damage,holy,(unsigned long long)chr,refreshed,prior,remaining);
    return accepted; // Never alter success/failure of the original marker.
}
static DWORD WINAPI Initialize(void*) {
    wchar_t path[32768];unsigned char digest[32];
    GetModuleFileNameW(selfModule,path,32768);wchar_t* slash=wcsrchr(path,L'\\');
    if(slash){wcscpy(slash+1,L"DanjiDeathblight.log");logFile=CreateFileW(path,GENERIC_WRITE,FILE_SHARE_READ|FILE_SHARE_WRITE,nullptr,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,nullptr);}
    if(!GetModuleFileNameW(nullptr,path,32768)||!HashFile(path,digest)||memcmp(digest,expectedSha256,32)){
        Log("DISABLED: host is not the verified offline Elden Ring 1.17.2 executable");InterlockedExchange(&completed,-1);return 0;
    }
    base=(Ptr)GetModuleHandleW(nullptr);
    unsigned char actual[sizeof(applySignature)];
    if(!Read(base+ApplyRva,actual,sizeof(actual))||memcmp(actual,applySignature,sizeof(actual))){
        Log("DISABLED: apply entry changed or already hooked");InterlockedExchange(&completed,-2);return 0;
    }
    unsigned char removeCheck[sizeof(removeBytes)];
    if(!Read(base+0x3ee2e0,removeCheck,sizeof(removeCheck))||memcmp(removeCheck,removeBytes,sizeof(removeCheck))){Log("DISABLED: remove entry changed");return 0;}
    removeEffect=(RemoveEffect)(base+0x3ee2e0);
    // Pin first: the game must never keep a jump to an unloaded module.
    HMODULE pinned=nullptr;
    if(!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_PIN,(LPCWSTR)&Initialize,&pinned)){
        Log("DISABLED: module pin failed");InterlockedExchange(&completed,-3);return 0;
    }
    MH_STATUS s=MH_Initialize();
    if(s==MH_OK)s=MH_CreateHook((void*)(base+ApplyRva),(void*)&HookApply,(void**)&originalApply);
    if(s==MH_OK)s=MH_EnableHook((void*)(base+ApplyRva));
    if(s!=MH_OK){Log("DISABLED: MinHook status=%d",s);MH_Uninitialize();InterlockedExchange(&completed,-4);return 0;}
    Log("READY v5: engine remove/reapply timer refresh without stacking; diagnostic target addresses; original human death route preserved; explicit formerly immune NPC routes; five independent 2%% max-HP ticks; holy=1.20 for30s;64 slots; no world polling");
    InterlockedExchange(&completed,1);return 0;
}
extern "C" __declspec(dllexport) LONG DeathblightStatus(){return InterlockedCompareExchange(&completed,0,0);}
BOOL WINAPI DllMain(HINSTANCE module,DWORD reason,LPVOID) {
    if(reason==DLL_PROCESS_ATTACH){selfModule=module;DisableThreadLibraryCalls(module);HANDLE t=CreateThread(nullptr,0,Initialize,nullptr,0,nullptr);if(t)CloseHandle(t);}
    return TRUE;
}


