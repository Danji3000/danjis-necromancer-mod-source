import os,pathlib,subprocess,ctypes,sys,json
root=pathlib.Path(__file__).resolve().parent
zig=pathlib.Path(os.environ['FP_ZIG']).resolve();assert zig.exists(),zig
os.environ['ZIG_LIB_DIR']=str(zig.parent/'lib')
os.environ['ZIG_GLOBAL_CACHE_DIR']=str(root/'build-cache-global');os.environ['ZIG_LOCAL_CACHE_DIR']=str(root/'build-cache')
os.environ['TMP']=os.environ['TEMP']=str(root/'temp');(root/'temp').mkdir(exist_ok=True)
os.chdir(root)
source=sys.argv[1] if len(sys.argv)>1 else 'DanjiDeathblight.cpp'
output=sys.argv[2] if len(sys.argv)>2 else 'DanjiDeathblight-v3.dll'
parse=ctypes.windll.shell32.CommandLineToArgvW;parse.restype=ctypes.POINTER(ctypes.c_wchar_p);parse.argtypes=[ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_int)]
sources=[source,*[str(pathlib.Path('vendor/minhook/src')/s) for s in ['buffer.c','hook.c','trampoline.c','hde/hde64.c']]]
objects=[]
for index,src in enumerate(sources):
 obj=f'build-{pathlib.Path(source).stem}-{index}.obj';objects.append(obj)
 args=['-target','x86_64-windows-gnu','-O2','-Wall','-Wextra','-fno-stack-protector']
 if src.endswith('.cpp'):args+=['-std=c++17','-fno-exceptions','-fno-rtti']
 process=subprocess.run([str(zig),'c++' if src.endswith('.cpp') else 'cc','-v',*args,'-c',src,'-o',obj],capture_output=True,text=True)
 line=next((s.strip() for s in process.stderr.splitlines() if s.strip().startswith('"') and ' -cc1 ' in s),None)
 if not line:print(process.stderr);sys.exit(1)
 n=ctypes.c_int();a=parse(line,ctypes.byref(n));cmd=[a[i] for i in range(n.value)];cmd.remove('-v');cmd[cmd.index('-o')+1]=obj
 if subprocess.run(cmd).returncode:sys.exit(1)
subprocess.run([str(zig),'-cc1as','-triple','x86_64-windows-gnu','-filetype','obj','stack_probe.s','-o','stack_probe.obj'],check=True)
libs={
'kernel32':['GetLastError','DisableThreadLibraryCalls','CreateThread','CloseHandle','GetModuleHandleExW','GetModuleFileNameW','CreateFileW','GetModuleHandleW','GetProcessHeap','HeapAlloc','HeapFree','HeapReAlloc','HeapCreate','HeapDestroy','ReadFile','GetCurrentProcess','ReadProcessMemory','WriteProcessMemory','WriteFile','AcquireSRWLockExclusive','ReleaseSRWLockExclusive','QueryPerformanceCounter','QueryPerformanceFrequency','VirtualAlloc','VirtualFree','VirtualProtect','VirtualQuery','FlushInstructionCache','GetCurrentProcessId','GetCurrentThreadId','CreateToolhelp32Snapshot','Thread32First','Thread32Next','OpenThread','SuspendThread','ResumeThread','GetThreadContext','SetThreadContext','Sleep','GetSystemInfo','GetProcAddress','LoadLibraryW','FreeLibrary','ExitProcess'],
'bcrypt':['BCryptOpenAlgorithmProvider','BCryptCreateHash','BCryptHashData','BCryptFinishHash','BCryptDestroyHash','BCryptCloseAlgorithmProvider'],
'msvcrt':['memcpy','memset','memcmp','wcsrchr','wcscpy','_vsnprintf','printf','puts','exit']}
for dll,names in libs.items():
 pathlib.Path(dll+'.def').write_text('LIBRARY '+dll+'.dll\nEXPORTS\n'+'\n'.join(names)+'\n')
 subprocess.run([str(zig),'dlltool','-m','i386:x86-64','-d',dll+'.def','-l',dll+'.lib'],check=True)
subprocess.run([str(zig),'lld-link','/machine:x64','/nodefaultlib','/dynamicbase','/nxcompat','/opt:ref','/opt:icf','/Brepro',*(['/dll','/entry:DllMain'] if output.endswith('.dll') else ['/subsystem:console','/entry:main']),'/out:'+output,*objects,'stack_probe.obj',*[k+'.lib' for k in libs]],check=True)
print('Built',output,pathlib.Path(output).stat().st_size,'bytes')



