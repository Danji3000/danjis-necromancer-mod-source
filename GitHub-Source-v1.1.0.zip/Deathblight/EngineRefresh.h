#pragma once
template<class Reader>
static int EffectRemaining(uintptr_t chr,int wanted,Reader read,float& remaining){
 uintptr_t manager=0,owner=0,node=0;
 if(!read(chr+0x178,&manager,8)||!manager||!read(manager+0x10,&owner,8)||owner!=chr||!read(manager+8,&node,8))return -1;
 int count=0;
 for(unsigned n=0;node&&n<2048;++n){
  unsigned char b[0x44];if(!read(node,b,sizeof(b)))return -1;
  int id;uintptr_t next;memcpy(&id,b+8,4);memcpy(&next,b+0x30,8);
  if(id==wanted){++count;memcpy(&remaining,b+0x40,4);}
  if(next==node)return -1;node=next;
 }
 return node||count>1?-1:count;
}
template<class Reader,class Remove,class Apply>
static bool RenewEffect(uintptr_t chr,int id,Reader read,Remove remove,Apply apply,float& before,float& after,bool& renewed){
 int present=EffectRemaining(chr,id,read,before);if(present<0)return false;
 if(present){
  remove(chr,id);
  float check=0;if(EffectRemaining(chr,id,read,check)!=0)return false;
 }
 if(!apply())return false;
 renewed=present!=0;
 return EffectRemaining(chr,id,read,after)==1&&after>29.f&&after<=30.1f;
}
