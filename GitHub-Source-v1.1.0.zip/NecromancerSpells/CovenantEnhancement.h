#pragma once
#include "HitClassification.h"
#include "enhancement_signatures.h"

static constexpr int AllyAura=8909010,ShieldAura=8909011,FPFlash=8909012;
using ApplyEffect=uint64_t(*)(Ptr,int,bool);
using RemoveEffect=uint64_t(*)(Ptr,int);
using SetFP=void(*)(Ptr,int);
using DamageHit=uint64_t(*)(Ptr,Ptr,Ptr,unsigned char,unsigned char);
static ApplyEffect applyVisual=nullptr;
static RemoveEffect removeVisual=nullptr;
static SetFP setCovenantFP=nullptr;
static DamageHit originalDamageHit=nullptr;
static bool enhancementReady=false,fpFlashPending=false;
static unsigned fpHundredths=0,fpRewards=0;
static int fpCarryMaximum=0;
static double visualNext=0;
struct VisualTrack {necro_spells::Identity id{};Ptr chr=0;bool seen=false;};
static VisualTrack allyVisuals[necro_spells::MaxRecipients]{};
static VisualTrack shieldVisual{};
static VisualTrack flashVisual{};
static double flashUntil=0;

static bool CurrentPlayerData(Ptr& data){
 Ptr world=0,player=0,mods=0,owner=0;int hp=0;
 return !epochInvalid&&playerNow&&ReadValue(base+0x3d6d018,world)&&world==worldNow
  &&ReadValue(world+0x1e508,player)&&player==playerNow&&ReadValue(player+0x190,mods)
  &&ReadValue(mods,data)&&ReadValue(data+8,owner)&&owner==player&&ReadValue(data+0x138,hp)&&hp>0;
}
static bool SameVisualActor(const VisualTrack& track){
 Ptr effects=0,owner=0;
 return CurrentTrackedActor(track.id,track.chr)&&ReadValue(track.chr+0x178,effects)&&effects
  &&ReadValue(effects+0x10,owner)&&owner==track.chr;
}
static void DropVisual(VisualTrack& track,int effect){
 if(removeVisual&&SameVisualActor(track)&&EffectPresent(track.chr,effect)==1)removeVisual(track.chr,effect);
 track={};
}
static bool KeepVisual(Ptr chr,int id){
 if(!applyVisual)return false;
 Ptr effects=0,owner=0,node=0;
 if(!ReadValue(chr+0x178,effects)||!ReadValue(effects+0x10,owner)||owner!=chr||!ReadValue(effects+8,node))return false;
 for(unsigned i=0;node&&i<512;++i){
  unsigned char block[0x44]{};if(!Read(node,block,sizeof(block)))return false;
  int found=0;Ptr next=0;float remaining=0;memcpy(&found,block+8,4);memcpy(&next,block+0x30,8);memcpy(&remaining,block+0x40,4);
  if(found==id&&remaining>0)return Put<float>(node+0x40,1.f);
  if(next==node)return false;node=next;
 }
 if(node)return false;
 applyVisual(chr,id,true);return EffectPresent(chr,id)==1;
}
static void ResetEnhancement(){
 for(auto& t:allyVisuals)if(t.id.handle)DropVisual(t,AllyAura);
 if(shieldVisual.id.handle)DropVisual(shieldVisual,ShieldAura);
 if(flashVisual.id.handle)DropVisual(flashVisual,FPFlash);
 flashUntil=0;
 fpFlashPending=false;fpHundredths=0;fpCarryMaximum=0;visualNext=0;
}
static void TickEnhancement(const Recipient* shared=nullptr,unsigned sharedCount=0){
 PerfScope perf(PerfVisuals);
 if(!enhancementReady)return;
 Ptr data=0;bool active=CurrentPlayerData(data)&&covenant.Active(spellTime,sessionEpoch);
 // The flash is queued ONLY by our successful hit credit. Never observe total
 // FP deltas: flask use and the user's passive-regeneration DLL cannot trigger it.
 if(fpFlashPending){
  uint64_t handle=0;
  if(active&&ReadValue(playerNow+8,handle)&&handle){
   KeepVisual(playerNow,FPFlash);flashVisual={{handle,sessionEpoch},playerNow,true};flashUntil=spellTime+1.0;
  }
  fpFlashPending=false;
 }
 // Explicit expiry also bounds the blue flash when another mod multiplies
 // SpEffect durations. Repeated qualifying credits refresh this one instance.
 if(flashVisual.id.handle&&(spellTime>=flashUntil||!SameVisualActor(flashVisual)))DropVisual(flashVisual,FPFlash);
 if(active&&spellTime<visualNext)return;
 visualNext=spellTime+.2;
 for(auto& t:allyVisuals)t.seen=false;
 unsigned count=0;Recipient local[necro_spells::MaxRecipients]{};const Recipient* recipients=shared?shared:local;
 if(active){
  count=shared?sharedCount:Recipients(local);
  for(unsigned i=0;i<count;++i){
   VisualTrack* slot=nullptr;
   for(auto& t:allyVisuals)if(t.id==recipients[i].actor.id){slot=&t;break;}
   if(!slot)for(auto& t:allyVisuals)if(!t.id.handle){slot=&t;break;}
   if(!slot)continue;
   *slot={recipients[i].actor.id,recipients[i].chr,true};KeepVisual(slot->chr,AllyAura);
  }
 }
 for(auto& t:allyVisuals)if(t.id.handle&&!t.seen)DropVisual(t,AllyAura);
 if(active&&count){
  uint64_t handle=0;if(ReadValue(playerNow+8,handle)&&handle){
   if(shieldVisual.id.handle&&(!SameVisualActor(shieldVisual)||shieldVisual.chr!=playerNow))DropVisual(shieldVisual,ShieldAura);
   shieldVisual={{handle,sessionEpoch},playerNow,true};KeepVisual(playerNow,ShieldAura);
  }
 }else if(shieldVisual.id.handle)DropVisual(shieldVisual,ShieldAura);
 if(!active){fpHundredths=0;fpCarryMaximum=0;}
}
static const WeaponKindRow* MeleeWeapon(int id){
 size_t lo=0,hi=sizeof(meleeWeapons)/sizeof(*meleeWeapons);
 while(lo<hi){size_t mid=(lo+hi)/2;if(meleeWeapons[mid].id<id)lo=mid+1;else hi=mid;}
 return lo<sizeof(meleeWeapons)/sizeof(*meleeWeapons)&&meleeWeapons[lo].id==id?&meleeWeapons[lo]:nullptr;
}
static bool DualWielding(const Recipient& a){
 int npc=-1,model=-1;if(!ReadValue(a.chr+0x60,npc)||!ReadValue(a.chr+0x64,model))return false;
 if(model!=0){
  for(int id:dualNpcIds)if(id==npc)return true;
  return false;
 }
 Ptr assembly=0;unsigned slots[2]{},style=~0u;int ids[6]{};
 if(!ReadValue(a.chr+0x638,assembly)||!ReadValue(assembly+8,style)||!Read(assembly+0xc,slots,8)
  ||slots[0]>=3||slots[1]>=3||!Read(assembly+0x7c,ids,24))return false;
 const auto*l=MeleeWeapon(ids[slots[0]*2]);const auto*r=MeleeWeapon(ids[slots[1]*2+1]);
 if(style==2)return l&&l->paired;
 if(style==3)return r&&r->paired;
 return (style==0||style==1)&&l&&r;
}
static int KindForAttack(int category,int id){
 size_t lo=0,hi=sizeof(attackKinds)/sizeof(*attackKinds);
 while(lo<hi){size_t mid=(lo+hi)/2;const auto& row=attackKinds[mid];
  if(row.category<category||(row.category==category&&row.id<id))lo=mid+1;else hi=mid;}
 if(lo==sizeof(attackKinds)/sizeof(*attackKinds))return -1;
 const auto& row=attackKinds[lo];return row.category==category&&row.id==id?row.kind:-1;
}
static unsigned FieldKind(Ptr field){uint64_t h=0;return ReadValue(field+8,h)?unsigned(h>>28)&15:15;}
struct HitCredit {necro_spells::Identity source{},target{};Ptr targetChr=0,targetData=0;int hp=0,rate=0,attack=-1,category=-1,npc=-1;Ptr sourceChr=0;};
static HitCredit CaptureHit(Ptr damageModule,Ptr source,Ptr hit){
 HitCredit result{};Ptr pd=0;
 if(!enhancementReady||!setCovenantFP||!covenant.Active(spellTime,sessionEpoch)||covenant.depth||source==playerNow||!CurrentPlayerData(pd))return result;
 Ptr target=0,mods=0,damage=0,data=0,owner=0;unsigned char team=255;int hp=0,incoming=0,category=-1,attack=-1;
 if(!ReadValue(damageModule+8,target)||target==playerNow||!ReadValue(target+0x190,mods)
  ||!ReadValue(mods+0x98,damage)||damage!=damageModule||!ReadValue(mods,data)||!ReadValue(data+8,owner)||owner!=target
  ||!ReadValue(data+0x138,hp)||hp<=0||!ReadValue(target+0x6c,team)||team==1||team==47
  ||!ReadValue(hit+0x228,incoming)||incoming<=0||!ReadValue(hit+0x40,attack)||!ReadValue(hit+0x44,category))return result;
 Ptr projectile=0;ReadValue(hit+0x1d8,projectile);
 unsigned sourceKind=FieldKind(source),projectileKind=FieldKind(projectile);bool bullet=sourceKind==3||projectileKind==3;
 uint64_t ownerHandle=0,sourceHandle=0;
 if(sourceKind==3)ReadValue(source+0x4c0,ownerHandle);
 else if(projectileKind==3)ReadValue(projectile+0x4c0,ownerHandle);
 Recipient found{};bool have=false;
 if(sourceKind==1&&ReadValue(source+8,sourceHandle))have=LookupRecipient(sourceHandle,source,found);
 if(!have&&ownerHandle)have=LookupRecipient(ownerHandle,0,found);
 if(!have)return result;const Recipient* ally=&found;
 // Teams1/47 were rejected above, so a valid allied target cannot grant credit.
 int kind=KindForAttack(category,attack),rate=0;
 if(kind==2)rate=4;
 else if(kind==1&&(!bullet||(category==0&&attack==4960900)))rate=DualWielding(*ally)?1:2;
 if(!rate)return result;
 uint64_t h=0;if(!ReadValue(target+8,h)||!h)return result;
 int npc=-1;ReadValue(ally->chr+0x60,npc);
 result={ally->actor.id,{h,sessionEpoch},target,data,hp,rate,attack,category,npc,ally->chr};return result;
}
static void CreditHit(const HitCredit& hit){
 if(!hit.rate||hit.source.epoch!=sessionEpoch||hit.target.epoch!=sessionEpoch)return;
 Ptr pd=0;int after=0;uint64_t targetHandle=0;
 if(!CurrentPlayerData(pd)||!covenant.Active(spellTime,sessionEpoch)||covenant.depth
  ||!ReadValue(hit.targetChr+8,targetHandle)||targetHandle!=hit.target.handle
  ||!ReadValue(hit.targetData+0x138,after)||after>=hit.hp||after<0)return;
 Recipient source{};
 if(!LookupRecipient(hit.source.handle,hit.sourceChr,source)||!(source.actor.id==hit.source))return;
 int fp=0,maximum=0;if(!ReadValue(pd+0x148,fp)||!ReadValue(pd+0x14c,maximum)||maximum<=0||fp<0||fp>maximum)return;
 if(maximum!=fpCarryMaximum){fpHundredths=0;fpCarryMaximum=maximum;}
 if(fp==maximum){fpHundredths=0;return;}
 // Flat bonus is part of the same validated per-hit credit and FP cap.
 const unsigned flatHundredths=hit.rate==4?400u:200u;
 uint64_t scaled=uint64_t(maximum)*unsigned(hit.rate)+flatHundredths+fpHundredths;
 int gain=int(scaled/100),available=maximum-fp;
 unsigned carry=unsigned(scaled%100);
 if(gain>=available){gain=available;carry=0;}
 if(gain<=0){fpHundredths=carry;return;}
 setCovenantFP(pd,fp+gain);
 int check=0;if(!ReadValue(pd+0x148,check)||check!=fp+gain){Log("COVENANT_FP_WRITE_REJECTED");return;}
 fpHundredths=carry;fpFlashPending=true;++fpRewards;
 if(fpRewards<=8||DetailedHitLogDue())Log("COVENANT_FP_HIT n=%u npc=%d source=%llx target=%llx atk=%d:%d rate=%d max=%d before=%d gain=%d after=%d hp_loss=%d",fpRewards,hit.npc,(unsigned long long)hit.source.handle,(unsigned long long)hit.target.handle,hit.category,hit.attack,hit.rate,maximum,fp,gain,check,hit.hp-after);
}
static uint64_t HookDamageHit(Ptr damage,Ptr source,Ptr hit,unsigned char flag,unsigned char flag2){
 HitCredit credit{};{SpellLock guard;PerfScope perf(PerfHitCapture);credit=CaptureHit(damage,source,hit);}
 // Never hold our lock while forwarding: the original can invoke the HP hook.
 uint64_t result=originalDamageHit(damage,source,hit,flag,flag2);
 if(credit.rate){SpellLock guard;PerfScope perf(PerfHitCredit);CreditHit(credit);}return result;
}
#include "StaminaDiscount.h"
static bool ConfigureEnhancement(){
 for(const auto& s:enhancementSignatures){unsigned char observed[32]{};
  if(s.size>sizeof(observed)||!Read(base+s.rva,observed,s.size)||memcmp(observed,s.bytes,s.size)){
   Log("COVENANT_ENHANCEMENT_SIGNATURE_REJECTED rva=%llx",(unsigned long long)s.rva);return false;
  }
 }
 applyVisual=(ApplyEffect)(base+0x3e8dc0);removeVisual=(RemoveEffect)(base+0x3ee2e0);setCovenantFP=(SetFP)(base+0x438990);
 MH_STATUS status=MH_CreateHook((void*)(base+0x4489f0),(void*)&HookDamageHit,(void**)&originalDamageHit);
 if(status==MH_OK)status=MH_EnableHook((void*)(base+0x4489f0));
 enhancementReady=status==MH_OK;
 Log("COVENANT_ENHANCEMENT status=%d melee=2 dual=1 spell=4 successful_hits_only=1 visual_only_effects=1",int(status));
 if(enhancementReady)ConfigureStaminaDiscount();
 return enhancementReady;
}

