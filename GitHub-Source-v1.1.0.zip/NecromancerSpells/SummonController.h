#pragma once
#include <stdint.h>
#include <stddef.h>
#include <math.h>
namespace necro {
struct Position { float x,y,z; };
struct Candidate { int model,npc,think; bool boss,approved; };
// Only this manually selected candidate is exposed by the phase-one prototype.
constexpr Candidate skeleton{3510,35100000,8905100,false,true};
enum class State { Idle,Requested,Active,Removing,Quarantined };
struct Observation {
 uint64_t epoch,handle; bool playerReady,staffSelected,creatorReady,onGround;
 bool exists,removalConfirmed; int hp; Position position; float forwardX,forwardZ;
};
struct SpawnRequest { Candidate npc; Position position; unsigned team; unsigned formationSlot=0,formationCount=1; };
class Engine {
public:
 virtual bool Request(const SpawnRequest&)=0;
 virtual bool SetAlly(uint64_t epoch,uint64_t handle,unsigned team)=0;
 virtual bool FollowHome(uint64_t epoch,uint64_t handle,Position)=0;
 virtual bool Remove(uint64_t epoch,uint64_t handle)=0;
};
class Controller {
 State state_=State::Idle; uint64_t epoch_=0,handle_=0; float wait_=0;
 static bool finite(Position p){return isfinite(p.x)&&isfinite(p.y)&&isfinite(p.z);}
public:
 State state()const{return state_;}
 // Called by the game's post-physics task, never a background input thread.
 // Recast invariant: never remove/replace existing NPCs to make room.
 bool Trigger(const Observation&o,Engine&e){
  if(state_!=State::Idle||!o.playerReady||!o.staffSelected||!o.creatorReady||!o.onGround||!finite(o.position))return false;
  if(!skeleton.approved||skeleton.boss)return false;
  const float len=o.forwardX*o.forwardX+o.forwardZ*o.forwardZ;
  if(!isfinite(len)||len<.9f||len>1.1f)return false;
  // Preliminary position only. Engine adapter MUST validate ground/collision before Request succeeds.
  SpawnRequest req{skeleton,{o.position.x+o.forwardX*2.5f,o.position.y+.3f,o.position.z+o.forwardZ*2.5f},47};
  if(!e.Request(req))return false;
  epoch_=o.epoch;handle_=0;wait_=0;state_=State::Requested;return true;
 }
 void Tick(const Observation&o,float dt,Engine&e){
  if(state_==State::Idle||state_==State::Quarantined)return;
  // Changing worlds invalidates the right to access or remove the old handle.
  if(!o.playerReady||o.epoch!=epoch_){state_=State::Quarantined;return;}
  if(!isfinite(dt)||dt<0||dt>1)return;
  if(state_==State::Requested){
   wait_+=dt;
   if(o.exists&&o.handle){
    handle_=o.handle;
    if(!e.SetAlly(epoch_,handle_,47)){state_=State::Quarantined;return;}
    state_=State::Active;
   }else if(wait_>=15){state_=State::Quarantined;}
   return;
  }
  if(o.removalConfirmed&&!o.exists){state_=State::Idle;handle_=0;return;}
  if(!o.exists||o.handle!=handle_){state_=State::Quarantined;return;}
  if(state_==State::Removing)return;
  // HP <= 0 alone is NOT removal: skeletons can reassemble.
  if(o.hp>0&&finite(o.position)){
   if(!e.SetAlly(epoch_,handle_,47)){state_=State::Quarantined;return;}
   Position home{o.position.x-o.forwardX*2.8f,o.position.y,o.position.z-o.forwardZ*2.8f};
   if(!e.FollowHome(epoch_,handle_,home))state_=State::Quarantined;
  }
 }
 bool RequestRemoval(const Observation&o,Engine&e){
  if(state_!=State::Active||o.epoch!=epoch_||!o.exists||o.handle!=handle_)return false;
  if(!e.Remove(epoch_,handle_))return false;
  state_=State::Removing;return true;
 }
};
}
