#pragma once
// d41220 is the Magic use-permission accessor invoked twice by the native
// availability routine 6909b0. Its wrapper stores Magic ID at0 and row at8.
// Only our spell's16 permission flags are zero in regulation: unavailable
// without this verified adapter. All surrounding stat/FP/region checks remain.
using MagicPermission=bool(*)(Ptr,unsigned char);
static MagicPermission originalMagicPermission=nullptr;
static int lastSacrificePermission=-1;
static unsigned sacrificePermissionReports=0;
static bool SacrificeEligibleHandle(uint64_t handle,Ptr expected){
 Recipient r{};necro::Position p{};
 return !SacrificeReserved(handle)&&LookupRecipient(handle,expected,r)&&SacrificeTier(r)>=0&&SacrificePosition(r.chr,p);
}
static bool SacrificeAvailable(){
 Ptr playerData=0;
 if(!sacrificeGateReady||!enhancementReady||sacrificeInFlight||!originalSetHP||!originalSacrificeSpawn||!CurrentPlayerData(playerData))return false;
 bool capacity=false;for(const auto& order:sacrificeOrders)if(!order.victim.handle){capacity=true;break;}if(!capacity)return false;
 // Early exit through our small owned rosters; no global NPC scan or polling.
 for(unsigned i=0;i<groupCount;++i)if(SacrificeEligibleHandle(groupNPCs[i].handle,groupNPCs[i].origin))return true;
 for(unsigned i=0;i<callCount;++i)if(SacrificeEligibleHandle(callNPCs[i].handle,callNPCs[i].origin))return true;
 ChrCollection c{};if(!ReadCollection(worldNow+0x10f90,c))return false;
 for(unsigned i=0;i<c.capacity;++i){
  Ptr chr=0;uint64_t handle=0;
  if(!ReadValue(c.entries+16*i,chr)||!chr||!ReadValue(chr+8,handle))continue;
  if(SacrificeEligibleHandle(handle,chr))return true;
 }return false;
}
static bool HookMagicPermission(Ptr wrapper,unsigned char covenantIndex){
 int magic=-1;if(!ReadValue(wrapper,magic))return false;
 if(magic!=SacrificeSpell)return originalMagicPermission(wrapper,covenantIndex);
 Ptr row=0;int trigger=-1;
 if(covenantIndex>15||!ReadValue(wrapper+8,row)||!row||!ReadValue(row+0x68,trigger)||trigger!=SacrificeTrigger)return false;
 SpellLock guard;const bool available=SacrificeAvailable();
 if(int(available)!=lastSacrificePermission){lastSacrificePermission=available;if(sacrificePermissionReports++<40)Log("SACRIFICE_PERMISSION allowed=%d living_non_giant_non_reserved=1",int(available));}
 return available;
}
static bool ConfigureSacrificeGate(){
 const unsigned char expected[]={0x4c,0x8b,0x49,0x08,0x45,0x32,0xc0,0x4d,0x85,0xc9};unsigned char bytes[sizeof(expected)];
 if(!Read(base+0xd41220,bytes,sizeof(bytes))||memcmp(expected,bytes,sizeof(bytes))){Log("SACRIFICE_PERMISSION disabled_signature; spell remains locked");return false;}
 MH_STATUS status=MH_CreateHook((void*)(base+0xd41220),(void*)&HookMagicPermission,(void**)&originalMagicPermission);
 if(status==MH_OK)status=MH_EnableHook((void*)(base+0xd41220));
 Log("SACRIFICE_PERMISSION_HOOK status=%d native_ui_and_cast_gate=1",int(status));return status==MH_OK;
}
