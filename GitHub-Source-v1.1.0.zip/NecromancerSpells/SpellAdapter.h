#pragma once
#include "SpellRules.h"
#include "spell_signatures.h"
#include "vendor/minhook/include/MinHook.h"
#include <intrin.h>

// Convergence reference: direct recipient HP debit, and behavior-module speed.
// Our adapter instead intercepts the un-clamped player HP commit and enumerates
// the current ChrSets at EVERY hit. It does not use the five HUD summon slots.
static necro_spells::Covenant covenant;
static necro_spells::Giants giants;
static Ptr giantOrigins[2]{};
static double spellTime=0;
static bool covenantMarkerSeen=false,giantMarkerSeen=false,giantPending=false,giantRequested=false,giantBlocked=false;
static float giantWait=0;
static uint64_t giantEpoch=0;
static unsigned spellHits=0;
static bool spellRuntimeReady=false;
static int EffectPresent(Ptr chr,int wanted){
 Ptr effects=0,node=0,owner=0;
 if(!ReadValue(chr+0x178,effects)||!ReadValue(effects+0x10,owner)||owner!=chr||!ReadValue(effects+8,node))return -1;
 for(unsigned i=0;node&&i<512;++i){unsigned char block[0x44]{};if(!Read(node,block,sizeof(block)))return -1;
  int id;Ptr next;float remaining;memcpy(&id,block+8,4);memcpy(&next,block+0x30,8);memcpy(&remaining,block+0x40,4);
  if(id==wanted&&remaining!=0)return 1;
  if(next==node)return -1;node=next;
 }return node?-1:0;
}
struct Recipient {necro_spells::Actor actor{};Ptr chr=0,data=0;};
struct ChrCollection {Ptr vtable=0;unsigned index=0,pad0=0,capacity=0,pad1=0;Ptr entries=0;};
static_assert(sizeof(ChrCollection)==0x20,"ChrSet layout");
static bool ReadCollection(Ptr set,ChrCollection& c){return Read(set,&c,sizeof(c))&&c.vtable==base+0x2a43348&&c.capacity<=4096&&c.entries;}
// Spirit ashes use type 5/team 1. Require their exact current buddy slot:
// a friendly world NPC or a stale pointer must never qualify as an ash.
static bool CurrentSpiritAsh(Ptr chr){
 uint64_t handle=0;ChrCollection c{};Ptr registered=0;
 if(!worldNow||!ReadValue(chr+8,handle)||!handle||!ReadCollection(worldNow+0x10f90,c))return false;
 unsigned slot=unsigned(handle)&0xfffff,index=(unsigned(handle)>>20)&255;
 return c.index==index&&slot<c.capacity&&ReadValue(c.entries+16*slot,registered)&&registered==chr;
}
static bool RecipientAt(Ptr chr,Recipient& out,bool buddyOrDebug){
 if(!chr||chr==playerNow)return false;
 struct IdentityFields {int model,type;unsigned char team,padding[3];} identity{};
 if(!Read(chr+0x64,&identity,sizeof(identity))||identity.model==8000||!((buddyOrDebug&&identity.team==47)||(identity.type==19&&identity.team==1)||(buddyOrDebug&&identity.type==5&&identity.team==1&&CurrentSpiritAsh(chr))))return false;
 Ptr mods=0,data=0,owner=0;uint64_t handle=0;int hp[2]{};
 if(!ReadValue(chr+8,handle)||!handle||!ReadValue(chr+0x190,mods)||!ReadValue(mods,data)||!data||!ReadValue(data+8,owner)||owner!=chr||!Read(data+0x138,hp,sizeof(hp))||hp[0]<=0||hp[0]>hp[1])return false;
 out={{{handle,sessionEpoch},true,true,true,false,hp[0]},chr,data};return true;
}
// Resolve only the live exact registry slot. No cached roster and no game call.
static Ptr RegisteredActor(uint64_t handle,Ptr expected,bool& buddyOrDebug){
 if(!handle)return 0;
 const unsigned slot=unsigned(handle)&0xfffff,index=(unsigned(handle)>>20)&255;
 const Ptr offsets[]={0x10ee0,0x10f90,0x10fe8};
 for(Ptr off:offsets){ChrCollection c{};
  if(!ReadCollection(worldNow+off,c)||c.index!=index||slot>=c.capacity)continue;
  Ptr chr=0;uint64_t actual=0;
  if(!ReadValue(c.entries+16*slot,chr)||!chr||(expected&&expected!=chr)||!ReadValue(chr+8,actual)||actual!=handle)continue;
  buddyOrDebug=off!=0x10ee0;return chr;
 }return 0;
}
static bool LookupRecipient(uint64_t handle,Ptr expected,Recipient& out){
 bool buddy=false;Ptr chr=RegisteredActor(handle,expected,buddy);
 return chr&&RecipientAt(chr,out,buddy)&&out.actor.id.handle==handle;
}
static unsigned Recipients(Recipient* out){
 PerfScope perf(PerfRegistry);unsigned n=0;
 const Ptr offsets[]={0x10ee0,0x10f90,0x10fe8};
 for(Ptr off:offsets){
  ChrCollection c{};if(!ReadCollection(worldNow+off,c))continue;
  Ptr snapshot[8192];if(!Read(c.entries,snapshot,size_t(c.capacity)*16))continue;
  for(unsigned i=0;i<c.capacity;++i){Recipient candidate{};if(!RecipientAt(snapshot[2*i],candidate,off!=0x10ee0))continue;
   bool duplicate=false;for(unsigned j=0;j<n;++j)if(out[j].actor.id==candidate.actor.id)duplicate=true;
   if(duplicate)continue;
   if(n==necro_spells::MaxRecipients){Log("COVENANT_REGISTRY_OVERFLOW: no partial split");return 0;}
   out[n++]=candidate;
  }
 }return n;
}
using SetHP=void(*)(Ptr,int,unsigned char,float,float,unsigned char);
static SetHP originalSetHP=nullptr;
static void ProcessSetHP(Ptr returnRva,Ptr data,int requested,unsigned char reset,float regain,float duration,unsigned char force){
 // Verified signed HP-delta callers; scripted kills, restores and stat reloads
 // use other return sites and retain the game's original behavior.
 Ptr owner=0,world=0,player=0,mods=0,currentData=0;
 bool damageCall=returnRva==0x436b56||returnRva==0x436bf9;
 if(!damageCall||!ReadValue(data+8,owner)||owner!=playerNow||!ReadValue(base+0x3d6d018,world)||world!=worldNow||!ReadValue(world+0x1e508,player)||player!=playerNow||!ReadValue(player+0x190,mods)||!ReadValue(mods,currentData)||currentData!=data){originalSetHP(data,requested,reset,regain,duration,force);return;}
 SpellLock guard;PerfScope perf(PerfDamageShare);
 int hp=0;
 if(epochInvalid||!ReadValue(data+0x138,hp)||hp<=0||requested>=hp||!covenant.Active(spellTime,sessionEpoch)||covenant.depth){originalSetHP(data,requested,reset,regain,duration,force);return;}
 Recipient recipients[necro_spells::MaxRecipients]{};necro_spells::Actor actors[necro_spells::MaxRecipients]{};
 unsigned count=Recipients(recipients);for(unsigned i=0;i<count;++i)actors[i]=recipients[i].actor;
 const auto before=covenant;
 auto plan=covenant.Plan(int64_t(hp)-requested,necro_spells::Origin::Combat,spellTime,sessionEpoch,actors,count);
 if(!plan.count){originalSetHP(data,requested,reset,regain,duration,force);return;}
 necro_spells::RedirectGuard redirect(covenant);
 unsigned committed=0;bool ok=true;
 for(unsigned i=0;i<plan.count;++i){
  // Plan preserves collection order after deduplication. Fresh identity/HP
  // check immediately before every write prevents reuse of a retired handle.
  Recipient fresh{};
  if(!RecipientAt(recipients[i].chr,fresh,true)||!(fresh.actor.id==plan.ally[i].target)||fresh.data!=recipients[i].data||fresh.actor.hp!=actors[i].hp){ok=false;break;}
  int next=int(fresh.actor.hp>plan.ally[i].damage?fresh.actor.hp-plan.ally[i].damage:0);
  if(!Put<int>(fresh.data+0x138,next)){ok=false;break;}++committed;
 }
 if(!ok){
  for(unsigned i=0;i<committed;++i)if(!Put<int>(recipients[i].data+0x138,int(actors[i].hp)))Log("COVENANT_ROLLBACK_FAILED recipient=%u",i);
  covenant.quarterCarry=before.quarterCarry;covenant.recipientCursor=before.recipientCursor;
  Log("COVENANT_TRANSACTION_REJECTED: player gets original damage");
  originalSetHP(data,requested,reset,regain,duration,force);return;
 }
 int64_t next=int64_t(hp)-plan.player;int playerNext=next<INT32_MIN?INT32_MIN:int(next);
 originalSetHP(data,playerNext,reset,regain,duration,force);
 ++spellHits;Log("COVENANT_HIT n=%u original=%lld player=%lld shared=%lld recipients=%u",spellHits,(long long)(int64_t(hp)-requested),(long long)plan.player,(long long)(int64_t(hp)-requested-plan.player),plan.count);
}
static void HookSetHP(Ptr data,int requested,unsigned char reset,float regain,float duration,unsigned char force){
 ProcessSetHP((Ptr)__builtin_return_address(0)-base,data,requested,reset,regain,duration,force);
}
static bool ConfigureSpellHook(){
 unsigned char actual[sizeof(hpSetSignature)]{};
 if(!Read(base+0x4374e0,actual,sizeof(actual))||memcmp(actual,hpSetSignature,sizeof(actual)))return false;
 HMODULE pinned=nullptr;if(!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_PIN,(LPCWSTR)&ConfigureSpellHook,&pinned))return false;
 MH_STATUS status=MH_Initialize();
 if(status==MH_OK)status=MH_CreateHook((void*)(base+0x4374e0),(void*)&HookSetHP,(void**)&originalSetHP);
 if(status==MH_OK)status=MH_EnableHook((void*)(base+0x4374e0));
 Log("SPELL_HP_HOOK status=%d pre-clamp=1 redirected-direct=1",int(status));return status==MH_OK;
}
// Validate registry ownership before dereferencing a retained actor pointer.
// An unloaded actor can retain its handle bytes after its modules were freed.
static bool CurrentTrackedActor(necro_spells::Identity id,Ptr expected){
 Ptr world=0,current=0;
 if(epochInvalid||!id.handle||id.epoch!=sessionEpoch||!expected||!ReadValue(base+0x3d6d018,world)||world!=worldNow||!Typed(world,0x2a509d0))return false;
 if(expected==playerNow){if(!ReadValue(world+0x1e508,current)||current!=expected)return false;}
 else{
  bool buddy=false;current=RegisteredActor(id.handle,expected,buddy);
  if(current!=expected)return false;
 }
 uint64_t handle=0;return ReadValue(current+8,handle)&&handle==id.handle;
}
struct SpeedTrack {necro_spells::Identity id{};Ptr chr=0,behavior=0;float baseline=1,last=1;bool written=false,seen=false;};
static SpeedTrack speeds[necro_spells::MaxRecipients]{};
static bool AnimationAttack(Ptr chr,Ptr& behavior){
 Ptr mods=0,tae=0,owner=0;unsigned idx=0;int anim=0,model=0;
 if(!ReadValue(chr+0x190,mods)||!ReadValue(mods+0x28,behavior)||!ReadValue(behavior+8,owner)||owner!=chr||!ReadValue(mods+0x18,tae)||!ReadValue(tae+8,owner)||owner!=chr||!ReadValue(tae+0xc4,idx)||idx>=10||!ReadValue(tae+0x20+16*idx,anim)||anim<0||!ReadValue(chr+0x64,model))return false;
 const int local=anim%1000000;
 return model==0?(local>=30000&&local<50000):((local>=3000&&local<4000)||(model==4960&&local>=20010&&local<=20012));
}
static void RestoreSpeed(SpeedTrack& s){
 Ptr mods=0,b=0,owner=0;float current=0;
 if(s.written&&CurrentTrackedActor(s.id,s.chr)&&ReadValue(s.chr+0x190,mods)&&ReadValue(mods+0x28,b)&&b==s.behavior&&ReadValue(b+8,owner)&&owner==s.chr&&ReadValue(b+0x17c8,current)&&current==s.last)Put<float>(b+0x17c8,s.baseline);
 s=SpeedTrack{};
}
static void TickSpeed(const Recipient* shared=nullptr,unsigned sharedCount=0){
 PerfScope perf(PerfSpeed);
 for(auto& s:speeds)s.seen=false;
 if(!epochInvalid&&covenant.Active(spellTime,sessionEpoch)){
  Recipient local[necro_spells::MaxRecipients]{};const Recipient* recipients=shared?shared:local;unsigned n=shared?sharedCount:Recipients(local);
  for(unsigned i=0;i<n;++i){Ptr behavior=0;if(!AnimationAttack(recipients[i].chr,behavior))continue;
   SpeedTrack* slot=nullptr;for(auto& s:speeds)if(s.id==recipients[i].actor.id){slot=&s;break;}
   if(!slot)for(auto& s:speeds)if(!s.id.handle){slot=&s;break;}
   if(!slot)continue;
   float current=0;if(!ReadValue(behavior+0x17c8,current)||!std::isfinite(current)||current<=0||current>8)continue;
   if(!slot->id.handle)*slot={recipients[i].actor.id,recipients[i].chr,behavior,current,current,false,true};
   if(slot->behavior!=behavior){RestoreSpeed(*slot);continue;}
   if(!slot->written||current!=slot->last)slot->baseline=current;
   float wanted=slot->baseline*1.25f;slot->seen=true;
   if(current==wanted||Put<float>(behavior+0x17c8,wanted)){slot->last=wanted;slot->written=true;}
  }
 }
 for(auto& s:speeds)if(s.id.handle&&!s.seen)RestoreSpeed(s);
}
#include "CovenantEnhancement.h"
static void ForgetCovenantActor(uint64_t handle,Ptr chr){
 for(auto& s:speeds)if(s.id.handle==handle&&s.chr==chr)s={};
 for(auto& t:allyVisuals)if(t.id.handle==handle&&t.chr==chr)t={};
}
static void ResetSpells(){
 ResetEnhancement();
 for(auto& s:speeds)if(s.id.handle)RestoreSpeed(s);
 covenant.Clear();covenantMarkerSeen=giantMarkerSeen=false;giantRequested=false;
 // Missing owned handles are confirmed by TickSpells, never freed on a stale
 // world pointer. Keep the pending creator quarantined until it completes.
}
static void TickGiants(const necro::Observation&o,float dt){
 for(unsigned i=0;i<2;++i){auto& g=giants.slots[i];if(!g.id.handle)continue;Ptr chr=0;
  if(g.id.epoch!=sessionEpoch||Probe(g.id.handle,chr)==Presence::Missing){giants.ConfirmGone(g.id);giantOrigins[i]=0;}
 }
 if(epochInvalid){giantRequested=false;giantBusy=giantPending||giants.Count()>0;return;}
 if(giantPending){
  giantWait+=dt;Ptr chr=0;uint64_t handle=0;int npc=0;
  if(ReadValue(creatorNow+0x1b0,chr)&&chr&&ReadValue(chr+8,handle)&&Resolve(handle)==chr&&ReadValue(chr+0x60,npc)&&npc==89090000){
   if(!giants.Capture({handle,sessionEpoch},spellTime)){giantBlocked=true;Log("GIANT_CAPTURE_REJECTED");return;}
   for(unsigned i=0;i<2;++i)if(giants.slots[i].id.handle==handle)giantOrigins[i]=chr;
   RestoreRiseInput();npcHandle=handle;npcOrigin=chr;engine->SetAlly(sessionEpoch,handle,47);giantPending=false;giantBusy=false;sentOnce=false;
   Ptr mods=0,data=0;int hp[2]{};if(ReadValue(chr+0x190,mods)&&ReadValue(mods,data))Read(data+0x138,hp,8);
   ReportGiantCapture();
   Log("GIANT_CREATED handle=%llx count=%u duration=30 hp=%d max=%d",(unsigned long long)handle,giants.Count(),hp[0],hp[1]);
  }else if(giantWait>15){giantBlocked=true;Log("GIANT_SPAWN_TIMEOUT: creator quarantined");}return;
 }
 giantBusy=giantRequested&&!callBusy&&!castRemaining&&!groupSpawnPending;
 if(callBusy||!giantRequested||giantBlocked||groupBlocked||groupSpawnPending||castRemaining||groupManualRetire||replaceRemaining||!o.creatorReady||!o.onGround||giants.Count()>=2)return;
 sentOnce=false;npcHandle=0;npcOrigin=0;removalAttempted=removalFailed=false;
 if(engine->Request({necro::colossus,o.position,47,0,1})){giantPending=true;giantWait=0;giantEpoch=sessionEpoch;giantRequested=false;}
 else{giantRequested=false;giantBusy=false;Log("GIANT_REQUEST_REJECTED");}
}
static void SpellMarkers(int& covenantResult,int& giantResult){
 covenantResult=giantResult=-1;Ptr effects=0,node=0,owner=0;
 if(!ReadValue(playerNow+0x178,effects)||!effects||!ReadValue(effects+0x10,owner)||owner!=playerNow||!ReadValue(effects+8,node))return;
 for(unsigned i=0;node&&i<512;++i){unsigned char block[0x44]{};if(!Read(node,block,sizeof(block)))return;
  int id=0;Ptr next=0;float remaining=0;memcpy(&id,block+8,4);memcpy(&next,block+0x30,8);memcpy(&remaining,block+0x40,4);
  if(remaining!=0){if(id==8909000)covenantResult=1;if(id==8909001)giantResult=1;}
  if(covenantResult==1&&giantResult==1)return;
  if(next==node)return;node=next;
 }
 if(!node){if(covenantResult<0)covenantResult=0;if(giantResult<0)giantResult=0;}
}
static void TickSpells(const necro::Observation&o,float dt){
 if(!spellRuntimeReady)return;
 if(!std::isfinite(dt)||dt<=0||dt>1)return;spellTime+=dt;
 int c=-1,g=-1;SpellMarkers(c,g);
 if(c==1&&!covenantMarkerSeen&&!epochInvalid){covenant.Cast(spellTime,sessionEpoch);Log("COVENANT_CAST duration=60 all_loaded_allied_summons=1 player_speed=0");}
 if(c>=0)covenantMarkerSeen=c==1;
 if(g==1&&!giantMarkerSeen&&!epochInvalid&&!giantBlocked&&!giantPending){giantRequested=true;Log("GIANT_CAST queued=1 limit=2 duration=30");}
 if(g>=0)giantMarkerSeen=g==1;
 TickGiants(o,dt);
 Recipient recipients[necro_spells::MaxRecipients]{};unsigned count=0;
 if(!epochInvalid&&covenant.Active(spellTime,sessionEpoch))count=Recipients(recipients);
 TickSpeed(recipients,count);TickEnhancement(recipients,count);
}
static void RetireGiants(){
 if(callBusy||giantBlocked||epochInvalid||giantPending||groupSpawnPending)return;
 necro_spells::Identity target{};
 for(const auto& g:giants.slots)if(g.id.handle&&giants.Due(g.id,spellTime)){target=g.id;break;}
 if(!target.handle&&giantRequested&&giants.Count()>=2)target=giants.Oldest();
 if(!target.handle)return;
 for(unsigned i=0;i<2;++i)if(giants.slots[i].id==target){
  npcHandle=target.handle;npcOrigin=giantOrigins[i];removalAttempted=removalFailed=false;removalPhase=true;
  bool ok=RetireOwned(target.epoch,target.handle);removalPhase=false;
  if(ok){giants.ConfirmGone(target);giantOrigins[i]=0;sentOnce=false;Log("GIANT_RETIRED count=%u",giants.Count());}
  else if(removalAttempted||removalFailed){giantBlocked=true;Log("GIANT_RETIRE_QUARANTINED");}
  npcHandle=0;npcOrigin=0;return;
 }
}
