#pragma once
// Independent FIFO roster; shares only the verified creator/retirement primitives.
static constexpr unsigned kCallCapacity=6;
struct CallNPC {uint64_t handle=0;Ptr origin=0;CombatGate combat{};float missing=0;bool trio=false;};
static CallNPC callNPCs[kCallCapacity];
static unsigned callCount=0,callRemaining=0,callReplace=0,callCastSize=0,callLimit=4;
static int callUpgrade=-1;
static bool callPending=false,callBlocked=false,callManualRetire=false;
static float callWait=0;
static uint64_t callEpoch=0;
static necro::Candidate callCandidate=necro::CallCandidate(0);
static bool CallHasOwnedOrPending(){return callCount||callPending;}
static void UpdateCallBusy(){callBusy=callPending||callRemaining||callReplace||callManualRetire;}
static void EraseCallNPC(unsigned i){for(unsigned j=i+1;j<callCount;++j)callNPCs[j-1]=callNPCs[j];callNPCs[--callCount]=CallNPC{};}
static bool PayCallCost(){
 Ptr mods=0,data=0;int fp=0,stamina=0,maxFP=0,maxStamina=0;
 if(!ReadValue(playerNow+0x190,mods)||!ReadValue(mods,data)||!data||!ReadValue(data+0x148,fp)||!ReadValue(data+0x14c,maxFP)||!ReadValue(data+0x154,stamina)||!ReadValue(data+0x158,maxStamina))return false;
 if(fp<20||fp>maxFP||stamina<20||stamina>maxStamina)return false;
 if(!Put<int>(data+0x148,fp-20))return false;
 if(!Put<int>(data+0x154,stamina-20)){Put<int>(data+0x148,fp);return false;}
 return true;
}
static bool BeginCallCast(const necro::Observation&o,bool debug){
 if(callBusy||callBlocked||giantBusy||giantRequested||groupBlocked||groupSpawnPending||castRemaining||replaceRemaining||groupManualRetire||epochInvalid||!o.playerReady||!o.staffSelected||!o.onGround||!o.creatorReady)return false;
 const int staff=debug?debugStaff:castingStaff;if(!necro::IsCallStaff(staff))return false;
 const int level=staff-33800000;const bool trio=level==25;
 const unsigned amount=debug?1u:trio?3u:2u,limit=trio?6u:4u;
 unsigned replace=callCount+amount>limit?callCount+amount-limit:0;
 // Switching between +25 and earlier levels replaces this skill's old roster.
 for(unsigned i=0;i<callCount;++i)if(callNPCs[i].trio!=trio){replace=callCount;break;}
 if(replace&&!removalAPI.detach)return false;
 if(!debug&&!PayCallCost()){Log("CALL_REJECTED: needs20FP and20stamina");return false;}
 callUpgrade=level;callCastSize=callRemaining=amount;callLimit=limit;callReplace=replace;callEpoch=sessionEpoch;UpdateCallBusy();
 Log("CALL_ACCEPTED upgrade=%d count=%u limit=%u replace_oldest=%u cost=%s",level,amount,limit,replace,debug?"debug-free":"20FP/20stamina");return true;
}
static void TickCall(const necro::Observation&o,float dt){
 if(!std::isfinite(dt)||dt<=0||dt>1)return;
 for(unsigned i=0;i<callCount;){
  Ptr chr=0;Presence state=Probe(callNPCs[i].handle,chr);
  if(state==Presence::Missing){callNPCs[i].missing+=dt;if(callNPCs[i].missing>=.5f){EraseCallNPC(i);continue;}}
  else callNPCs[i].missing=0;
  if(state==Presence::Present&&chr!=callNPCs[i].origin){callBlocked=true;callRemaining=callReplace=0;UpdateCallBusy();Log("CALL_OWNERSHIP_CHANGED: no NPC writes; restart required");return;}
  if(state==Presence::Present&&!epochInvalid&&!callBlocked){
   Ptr mods=0,data=0;int hp=0;
   if(ReadValue(chr+0x190,mods)&&ReadValue(mods,data)&&ReadValue(data+0x138,hp)){
    callNPCs[i].combat.Tick(playerHP,hp,playerActions,dt,playerInCombat);
    if(hp>0&&!SacrificeReserved(callNPCs[i].handle)){AICommand(chr,callNPCs[i].combat.Active()?1.f:0.f,true);CatchUp(chr,o);engine->SetAlly(sessionEpoch,callNPCs[i].handle,47);necro::Position home{o.position.x-o.forwardX*2.8f,o.position.y,o.position.z-o.forwardZ*2.8f};engine->FollowHome(sessionEpoch,callNPCs[i].handle,home);}
   }
  }
  ++i;
 }
 if(epochInvalid){callRemaining=callReplace=0;callManualRetire=false;UpdateCallBusy();return;}
 if(callBlocked){UpdateCallBusy();return;}
 if(callPending){
  callWait+=dt;Ptr chr=0;uint64_t handle=0;
  if(ReadValue(creatorNow+0x1b0,chr)&&chr&&ReadValue(chr+8,handle)&&Resolve(handle)==chr){
   int npc=0,model=0;
   if(!ReadValue(chr+0x60,npc)||!ReadValue(chr+0x64,model)||npc!=callCandidate.npc||model!=3500){callBlocked=true;callRemaining=0;Log("CALL_WRONG_CANDIDATE: creator quarantined");return;}
   bool duplicate=false;for(unsigned i=0;i<callCount;++i)if(callNPCs[i].handle==handle)duplicate=true;
   if(duplicate||callCount>=callLimit||callCount>=kCallCapacity){callBlocked=true;callRemaining=0;Log("CALL_CAPTURE_REJECTED: creator quarantined");return;}
   auto& slot=callNPCs[callCount++];slot={};slot.handle=handle;slot.origin=chr;slot.trio=callUpgrade==25;slot.combat.Reset();
   RestoreRiseInput();npcHandle=handle;npcOrigin=chr;engine->SetAlly(sessionEpoch,handle,47);callPending=false;sentOnce=false;if(callRemaining)--callRemaining;
   Ptr mods=0,data=0;int hp[2]={-1,-1};if(ReadValue(chr+0x190,mods)&&ReadValue(mods,data))Read(data+0x138,hp,8);
   Log("CALL_CREATED upgrade=%d npc=%d active=%u limit=%u hp=%d max_hp=%d handle=%llx",callUpgrade,npc,callCount,callLimit,hp[0],hp[1],(unsigned long long)handle);
  }else if(callWait>15){callBlocked=true;callRemaining=0;Log("CALL_SPAWN_TIMEOUT: creator quarantined");}
  UpdateCallBusy();return;
 }
 if(callRemaining&&!callReplace&&!giantBusy&&!groupSpawnPending&&!castRemaining&&callCount<callLimit&&o.creatorReady&&o.onGround&&o.staffSelected&&callEpoch==sessionEpoch){
  sentOnce=false;npcHandle=0;npcOrigin=0;removalAttempted=removalFailed=false;
  const auto candidate=necro::CallCandidate(callUpgrade);
  if(engine->Request({candidate,o.position,47,callCastSize-callRemaining,callCastSize})){callCandidate=candidate;callPending=true;callWait=0;}
  else{callRemaining=0;Log("CALL_SPAWN_REJECTED: survivors retained");}
 }
 UpdateCallBusy();
}
static void RetireCall(){
 if(callBlocked||epochInvalid||callPending||groupSpawnPending||giantPending||(!callReplace&&!callManualRetire))return;
 if(!callCount){callReplace=0;callManualRetire=false;UpdateCallBusy();return;}
 necro::Observation o{};if(!PlayerState(o)||epochInvalid)return;
 npcHandle=callNPCs[0].handle;npcOrigin=callNPCs[0].origin;removalAttempted=removalFailed=false;removalPhase=true;
 bool ok=RetireOwned(sessionEpoch,npcHandle);removalPhase=false;
 if(ok){EraseCallNPC(0);if(callReplace)--callReplace;callManualRetire=false;sentOnce=false;Log("CALL_OLDEST_REMOVED active=%u replace_remaining=%u",callCount,callReplace);}
 else{callRemaining=callReplace=0;callManualRetire=false;if(removalAttempted||removalFailed)callBlocked=true;Log("CALL_REMOVE_REJECTED blocked=%d",callBlocked);}
 npcHandle=0;npcOrigin=0;UpdateCallBusy();
}
