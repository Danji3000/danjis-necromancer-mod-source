#pragma once
struct HealingSoul {bool active=false;uint64_t epoch=0,handle=0;Ptr player=0,world=0;double due=0,expires=0;necro::Position end{};};
static HealingSoul healingSouls[16]{};
static volatile LONG healingSoulPending=0;
static unsigned soulArrivalReports=0;
static constexpr double HealingSoulFlight=.4;
static bool StartSacrificeSoul(necro::Position position,uint64_t epoch){
 uint64_t handle=0;Ptr player=0,world=0;double now=0;
 {SpellLock guard;Ptr data=0;if(epoch!=sessionEpoch||!CurrentPlayerData(data)||!ReadValue(playerNow+8,handle))return false;player=playerNow;world=worldNow;now=spellTime;}
 necro::Position end{};if(!SalvoSoulVisual({true,epoch,position},&end))return false;
 SpellLock guard;
 if(epoch!=sessionEpoch||player!=playerNow||world!=worldNow)return false;
 for(auto& s:healingSouls)if(!s.active){s={true,epoch,handle,player,world,now+HealingSoulFlight,now+8.,end};InterlockedExchange(&healingSoulPending,1);return true;}
 if(soulArrivalReports++<80)Log("SACRIFICE_SOUL queue_full_no_heal=1");return false;
}
static void TickSacrificeSouls(){
 if(!InterlockedCompareExchange(&healingSoulPending,0,0))return;
 for(auto& s:healingSouls){
  SalvoSoul relay{};double expiry=0;
  {
   SpellLock guard;if(!s.active)continue;Ptr data=0;uint64_t handle=0;necro::Position current{};
   if(s.epoch!=sessionEpoch||s.player!=playerNow||s.world!=worldNow||epochInvalid||!CurrentPlayerData(data)||!ReadValue(playerNow+8,handle)||handle!=s.handle||!SacrificePosition(playerNow,current)||spellTime>s.expires){s={};continue;}
   if(spellTime<s.due)continue;
   if(Distance2(current,s.end)>1.5625f){relay={true,s.epoch,s.end};expiry=s.expires;s.due=spellTime+HealingSoulFlight;}
   else{
    // Consume exactly once before native calls. Never revive a dead/replaced player.
    s.active=false;int hp=0,maximum=0;ReadValue(data+0x138,hp);ReadValue(data+0x13c,maximum);int gain=0;
    if(hp>0&&maximum>hp){int next=hp>maximum-maximum/2?maximum:hp+maximum/2;originalSetHP(data,next,0,0.f,1.f,1);int after=hp;
     if(ReadValue(data+0x138,after)&&after>hp){gain=after-hp;if(applyVisual){if(removeVisual&&EffectPresent(playerNow,SacrificeHealVfx)==1)removeVisual(playerNow,SacrificeHealVfx);applyVisual(playerNow,SacrificeHealVfx,true);}}
    }
    if(soulArrivalReports++<80)Log("SACRIFICE_SOUL_ARRIVED healed=%d visual=%d",gain,int(gain>0&&applyVisual));
   }
  }
  if(relay.active){necro::Position end{};bool ok=SalvoSoulVisual(relay,&end);SpellLock guard;if(ok&&relay.epoch==sessionEpoch&&spellTime<expiry){s.end=end;s.due=spellTime+HealingSoulFlight;}else s={};}
 }
 {SpellLock guard;bool any=false;for(const auto& s:healingSouls)any|=s.active;InterlockedExchange(&healingSoulPending,any?1:0);}
}
