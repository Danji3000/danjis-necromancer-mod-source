#pragma once
// Coarse, bounded measurements. Never time every individual pointer read.
enum PerfKind {PerfRegistry,PerfSpeed,PerfVisuals,PerfHitCapture,PerfHitCredit,PerfDamageShare,PerfSpawn,PerfKinds};
struct PerfMetric {double total=0,peak=0;unsigned count=0;};
static PerfMetric perfMetrics[PerfKinds]{};
static SRWLOCK perfLock=SRWLOCK_INIT;
static double perfFrequency=0,callbackGapTotal=0,callbackGapPeak=0,spawnGapPeak=0;
static unsigned callbackGapCount=0;
static LONGLONG previousCallback=0;
static ULONGLONG giantRequestAt=0,giantObserveUntil=0,lastDetailedHit=0;
static double PerfFrequency(){
 if(!perfFrequency){LARGE_INTEGER f{};QueryPerformanceFrequency(&f);perfFrequency=double(f.QuadPart);}
 return perfFrequency;
}
struct PerfScope {
 LARGE_INTEGER start{};PerfKind kind;
 explicit PerfScope(PerfKind k):kind(k){QueryPerformanceCounter(&start);}
 ~PerfScope(){LARGE_INTEGER end{};QueryPerformanceCounter(&end);AcquireSRWLockExclusive(&perfLock);
  double ms=double(end.QuadPart-start.QuadPart)*1000.0/PerfFrequency();auto& m=perfMetrics[kind];m.total+=ms;++m.count;if(ms>m.peak)m.peak=ms;
  ReleaseSRWLockExclusive(&perfLock);
 }
};
static void ObserveCallbackGap(LARGE_INTEGER now){
 AcquireSRWLockExclusive(&perfLock);
 if(previousCallback){double ms=double(now.QuadPart-previousCallback)*1000.0/PerfFrequency();
  callbackGapTotal+=ms;++callbackGapCount;if(ms>callbackGapPeak)callbackGapPeak=ms;
  if(giantObserveUntil&&GetTickCount64()<=giantObserveUntil&&ms>spawnGapPeak)spawnGapPeak=ms;
 }
 previousCallback=now.QuadPart;ReleaseSRWLockExclusive(&perfLock);
}
static void MarkGiantRequest(){AcquireSRWLockExclusive(&perfLock);giantRequestAt=GetTickCount64();giantObserveUntil=giantRequestAt+5000;ReleaseSRWLockExclusive(&perfLock);}
static void ReportGiantCapture(){
 AcquireSRWLockExclusive(&perfLock);ULONGLONG elapsed=giantRequestAt?GetTickCount64()-giantRequestAt:0;ReleaseSRWLockExclusive(&perfLock);
 Log("GIANT_TIMING request_to_capture_ms=%llu; includes engine load/scheduling, not GPU timing",elapsed);
}
static bool DetailedHitLogDue(){ULONGLONG now=GetTickCount64();if(now-lastDetailedHit<1000)return false;lastDetailedHit=now;return true;}
static void ReportPerformance(){
 PerfMetric snapshot[PerfKinds];double total=0,peak=0,spawnPeak=0;unsigned count=0;
 AcquireSRWLockExclusive(&perfLock);memcpy(snapshot,perfMetrics,sizeof(snapshot));for(auto& m:perfMetrics)m={};
 total=callbackGapTotal;peak=callbackGapPeak;spawnPeak=spawnGapPeak;count=callbackGapCount;
 callbackGapTotal=callbackGapPeak=spawnGapPeak=0;callbackGapCount=0;ReleaseSRWLockExclusive(&perfLock);
 const char* names[]={"registry","speed","auras","fp_capture","fp_credit","hp_share","spawn_request"};
 for(unsigned i=0;i<PerfKinds;++i){const auto& m=snapshot[i];if(m.count)Log("PERF_SCOPE name=%s count=%u total_ms=%.4f avg_ms=%.4f peak_ms=%.4f",names[i],m.count,m.total,m.total/m.count,m.peak);}
 Log("PERF_CADENCE avg_callback_gap_ms=%.4f peak_gap_ms=%.4f giant_window_peak_ms=%.4f; callback cadence is not a Present/GPU FPS measurement",count?total/count:0,peak,spawnPeak);
}
