#pragma once
// Immediate casts reuse only synchronous engine input. Delayed orders store scalar
// identifiers and revalidate handles; fresh native input has no retained graph pointers.
static constexpr int SacrificeSpell=5097,SacrificeTrigger=18931000,SacrificeBlast=18931001,SacrificeHealVfx=8909020,SacrificeRunMarker=8909021;
using BulletSpawn=int*(*)(Ptr,int*,const void*,int*);
static BulletSpawn originalSacrificeSpawn=nullptr;
static bool sacrificeInFlight=false;
static bool sacrificeGateReady=false;
static uint64_t sacrificeLastEpoch=0;
static double sacrificeLastTime=-100;
struct SacrificeOrder {necro_spells::Identity victim{},target{};Ptr origin=0;double expires=0;unsigned char scalar[0x48]{};necro::Position oldHome{};};
static SacrificeOrder sacrificeOrders[16]{};
static volatile LONG sacrificePending=0;
using ConstructBullet=void*(*)(void*);static ConstructBullet constructSacrificeInput=nullptr;
static bool SacrificeReserved(uint64_t handle){for(const auto& o:sacrificeOrders)if(o.victim.handle==handle&&o.victim.epoch==sessionEpoch)return true;return false;}
// Vanilla c9997 IsDead/ExecTransToDeathIdle: regenerating skeletons collapse
// at one HP; zero HP bypasses reconstruction. Inspect actual effects, not model.
// -1 = invalid / rebuilding; 0 = ordinary mortal; 1 = native skeleton revival.
static int SacrificeRevival(const Recipient& r){
 int hp=0;if(!ReadValue(r.data+0x138,hp)||hp<=0)return -1;
 Ptr effects=0,owner=0,node=0;
 if(!ReadValue(r.chr+0x178,effects)||!effects||!ReadValue(effects+0x10,owner)||owner!=r.chr||!ReadValue(effects+8,node))return -1;
 bool revives=false;
 for(unsigned i=0;node&&i<512;++i){
  int id=0;float remaining=0;Ptr next=0;
  if(!ReadValue(node+8,id)||!ReadValue(node+0x40,remaining)||!ReadValue(node+0x30,next)||next==node)return -1;
  if(remaining!=0){
   if(id==5831||id==5833||id==5834||id==5861||id==5862||id==12510||id==10592||id==5835||id==5863)return -1;
   if(id==5832||id==5860)revives=true;
  }node=next;
 }
 if(node||(revives&&hp<=1))return -1;
 return revives?1:0;
}
static int SacrificeTier(const Recipient& r){
 if(SacrificeRevival(r)<0)return -1;
 int model=0;if(!ReadValue(r.chr+0x64,model)||model==4960)return -1;
 for(const auto& g:giants.slots)if(g.id==r.actor.id)return -1;
 for(unsigned i=0;i<groupCount;++i)if(groupNPCs[i].handle==r.actor.id.handle&&groupNPCs[i].origin==r.chr)return 0;
 for(unsigned i=0;i<callCount;++i)if(callNPCs[i].handle==r.actor.id.handle&&callNPCs[i].origin==r.chr)return 0;
 return CurrentSpiritAsh(r.chr)?1:-1;
}
static bool SacrificePosition(Ptr chr,necro::Position& p){Ptr physics=0;int hp=0;return CharacterPhysics(chr,physics,p,hp)&&hp>0&&std::isfinite(p.x)&&std::isfinite(p.y)&&std::isfinite(p.z);}
static Ptr(*sacrificeResolve)(uint64_t)=nullptr;
static Ptr SacrificeTarget(uint64_t handle){if(!handle||handle==~uint64_t(0))return 0;if(sacrificeResolve){Ptr chr=sacrificeResolve(handle);uint64_t actual=0;return chr&&ReadValue(chr+8,actual)&&actual==handle?chr:0;}bool buddy=false;return RegisteredActor(handle,0,buddy);}
static bool ChooseSacrifice(uint64_t targetHandle,Recipient& chosen,necro::Position& position){
 necro::Position anchor{};if(!SacrificePosition(playerNow,anchor))return false;
 Ptr target=SacrificeTarget(targetHandle);necro::Position enemy{};
 if(target&&target!=playerNow&&SacrificePosition(target,enemy))anchor=enemy;
 Recipient list[necro_spells::MaxRecipients]{};unsigned count=Recipients(list);int bestTier=2;float bestDistance=3.4e38f;bool found=false;
 for(unsigned i=0;i<count;++i){int tier=SacrificeTier(list[i]);necro::Position p{};
  if(tier<0||SacrificeReserved(list[i].actor.id.handle)||!SacrificePosition(list[i].chr,p))continue;
  float distance=Distance2(p,anchor);
  if(tier<bestTier||(tier==bestTier&&distance<bestDistance)){chosen=list[i];position=p;bestTier=tier;bestDistance=distance;found=true;}
 }return found;
}
static bool StartSacrificeSoul(necro::Position,uint64_t);
static void TickSacrificeSouls();
static void NoteSacrificePayment();
static int DetonateSacrifice(Ptr manager,unsigned char* input,const Recipient& victim,necro::Position position,uint64_t epoch){
 const int blast=SacrificeBlast,dummy=-1;const uint64_t noTarget=~uint64_t(0);
 float xyz[4]={position.x,position.y+.8f,position.z,1.f};
 memcpy(input+0x14,&blast,4);memcpy(input+0x1c,&dummy,4);memcpy(input+0x20,&noTarget,8);memcpy(input+0x80,xyz,16);
 int result=-1,why=0;originalSacrificeSpawn(manager,&result,input,&why);
 {
  SpellLock guard;sacrificeInFlight=false;Recipient fresh{};Ptr pd=0;
  if(result==-1||epoch!=sessionEpoch||!CurrentPlayerData(pd)||!LookupRecipient(victim.actor.id.handle,victim.chr,fresh)||SacrificeTier(fresh)<0){Log("SACRIFICE_ABORT spawn=%d reason=%d",result,why);return -1;}
  const int collapseHP=SacrificeRevival(fresh);if(collapseHP<0)return -1;
  originalSetHP(fresh.data,collapseHP,0,0.f,1.f,1);int remaining=-1;
  Log("SACRIFICE_COLLAPSE victim=%llx hp=%d native_revival=%d",(unsigned long long)fresh.actor.id.handle,collapseHP,collapseHP);
  if(!ReadValue(fresh.data+0x138,remaining)||remaining!=collapseHP){Log("SACRIFICE_ABORT hp_collapse_mismatch=%d",remaining);return -1;}
  Log("SACRIFICE_CAST victim=%llx heal_deferred_until_soul_arrival=1 blast=%d",(unsigned long long)fresh.actor.id.handle,blast);
  NoteSacrificePayment();
 }
 StartSacrificeSoul(position,epoch);
 return result;
}
static bool StartSacrificeRun(Ptr chr,const necro::Position& target){
 if(!KeepVisual(chr,SacrificeRunMarker))return false;
 bool ok=Write(chr+0x90,&target,sizeof(target))&&AICommand(chr,110,true);
 Ptr manip=0,ai=0;unsigned flags=0;
 // Even an existing follow command110 must generate a fresh interrupt now.
 if(ok)ok=ReadValue(chr+0x580,manip)&&ReadValue(manip+0xc0,ai)&&ReadValue(ai+0xc46c,flags)&&Put<unsigned>(ai+0xc46c,flags|1);
 if(!ok&&removeVisual)removeVisual(chr,SacrificeRunMarker);
 return ok;
}
static int* HookSacrificeSpawn(Ptr manager,int* output,const void* source,int* error){
 int bullet=0,magic=0;uint64_t caster=0,target=0,playerHandle=0;
 if(!source||!ReadValue((Ptr)source+0x14,bullet)||bullet!=SacrificeTrigger){return originalSacrificeSpawn(manager,output,source,error);}
 // A dedicated trigger can never become a projectile when the runtime rejects it.
 if(output)*output=-1;if(error)*error=0;
 alignas(16) unsigned char input[0x110];Recipient victim{};necro::Position position{};uint64_t epoch=0;
 {
  SpellLock guard;Ptr playerData=0;
  if(!sacrificeGateReady||!enhancementReady||sacrificeInFlight||!CurrentPlayerData(playerData)||!originalSetHP||
     !ReadValue((Ptr)source,caster)||!ReadValue(playerNow+8,playerHandle)||caster!=playerHandle||
     !ReadValue((Ptr)source+0xc,magic)||magic!=SacrificeSpell||
     !ReadValue((Ptr)source+0x20,target)||!Read((Ptr)source,input,sizeof(input)))return output;
  if(!ReadValue(playerNow+0x6b0,target))return output;
  // The cloned spell emits once. Also reject duplicate dispatch in one frame.
  if(sacrificeLastEpoch==sessionEpoch&&sacrificeLastTime==spellTime)return output;
  if(!ChooseSacrifice(target,victim,position)){Log("SACRIFICE_REJECTED no_living_eligible_minion=1");return output;}
  epoch=sessionEpoch;sacrificeLastEpoch=epoch;sacrificeLastTime=spellTime;
  Ptr enemy=SacrificeTarget(target);necro::Position ep{};
  if(enemy&&enemy!=playerNow&&SacrificePosition(enemy,ep)){
   SacrificeOrder* slot=nullptr;for(auto& o:sacrificeOrders)if(!o.victim.handle){slot=&o;break;}
   if(!slot||!constructSacrificeInput||!Read(victim.chr+0x90,&slot->oldHome,sizeof(slot->oldHome)))return output;
   if(!StartSacrificeRun(victim.chr,ep)){Write(victim.chr+0x90,&slot->oldHome,sizeof(slot->oldHome));Log("SACRIFICE_REJECTED cannot_command_runner=1");return output;}
   slot->victim=victim.actor.id;slot->origin=victim.chr;slot->target={target,epoch};slot->expires=spellTime+45;InterlockedExchange(&sacrificePending,1);memcpy(slot->scalar,input,sizeof(slot->scalar));
   NoteSacrificePayment();Log("SACRIFICE_RUN victim=%llx target=%llx timeout=45",(unsigned long long)slot->victim.handle,(unsigned long long)target);return output;
  }
  sacrificeInFlight=true;
 }
 int result=DetonateSacrifice(manager,input,victim,position,epoch);if(output)*output=result;return output;
}

static void ClearSacrificeOrder(SacrificeOrder& o){
 bool buddy=false;Ptr chr=0; if(o.victim.epoch==sessionEpoch&&!epochInvalid)chr=RegisteredActor(o.victim.handle,o.origin,buddy);if(chr){if(removeVisual&&EffectPresent(chr,SacrificeRunMarker)==1)removeVisual(chr,SacrificeRunMarker);AICommand(chr,0,true);Write(chr+0x90,&o.oldHome,sizeof(o.oldHome));}o={};
 bool any=false;for(const auto& x:sacrificeOrders)if(x.victim.handle)any=true;InterlockedExchange(&sacrificePending,any?1:0);
}
static void ExecuteSacrifice(void*,const void*){
 TickSacrificeSouls();
 if(!InterlockedCompareExchange(&sacrificePending,0,0))return;
 for(unsigned i=0;i<16;++i){
  alignas(16) unsigned char input[0x110]{};Recipient victim{};necro::Position vp{};uint64_t epoch=0;Ptr manager=0;bool ready=false;
  {
   SpellLock guard;auto& o=sacrificeOrders[i];if(!o.victim.handle)continue;Ptr pd=0;necro::Position ep{};
   if(o.victim.epoch!=sessionEpoch||!CurrentPlayerData(pd)){ClearSacrificeOrder(o);continue;}
   Ptr target=SacrificeTarget(o.target.handle);
   if(o.victim.epoch!=sessionEpoch||!CurrentPlayerData(pd)||spellTime>=o.expires||!target||!SacrificePosition(target,ep)||!LookupRecipient(o.victim.handle,o.origin,victim)||SacrificeTier(victim)<0||!SacrificePosition(victim.chr,vp)){Log("SACRIFICE_RUN_CANCELLED victim=%llx",(unsigned long long)o.victim.handle);ClearSacrificeOrder(o);continue;}
   if(Distance2(vp,ep)>6.25f){Write(victim.chr+0x90,&ep,sizeof(ep));AICommand(victim.chr,110,true);continue;}
   if(sacrificeInFlight||!constructSacrificeInput||!ReadValue(base+0x3d697c8,manager)||!manager)continue;
   constructSacrificeInput(input);memcpy(input,o.scalar,sizeof(o.scalar));epoch=sessionEpoch;ClearSacrificeOrder(o);sacrificeInFlight=true;ready=true;
  }
  if(ready)DetonateSacrifice(manager,input,victim,vp,epoch);
 }
}
#include "SacrificeGate.h"
static bool ConfigureSacrifice(){
 const unsigned char sig[]={0x40,0x53,0x55,0x56,0x57,0x48,0x81,0xec,0x98,0x07,0x00,0x00,0x48,0xc7,0x44,0x24,0x50,0xfe,0xff,0xff,0xff};unsigned char observed[sizeof(sig)];
 if(!Read(base+0x3a2cb0,observed,sizeof(observed))||memcmp(sig,observed,sizeof(sig))){Log("SACRIFICE_DISABLED spawn_signature");return false;}
 const unsigned char ctor[]={0x48,0x89,0x4c,0x24,0x08,0x57,0x48,0x83,0xec,0x30};unsigned char gotCtor[sizeof(ctor)];
 if(!Read(base+0x38c580,gotCtor,sizeof(ctor))||memcmp(ctor,gotCtor,sizeof(ctor)))return false;
 constructSacrificeInput=(ConstructBullet)(base+0x38c580);
 sacrificeResolve=(Ptr(*)(uint64_t))(base+0x62f360);
 MH_STATUS s=MH_CreateHook((void*)(base+0x3a2cb0),(void*)&HookSacrificeSpawn,(void**)&originalSacrificeSpawn);if(s==MH_OK)s=MH_EnableHook((void*)(base+0x3a2cb0));Log("SACRIFICE_HOOK status=%d",int(s));sacrificeGateReady=s==MH_OK&&ConfigureSacrificeGate();return sacrificeGateReady;
}

