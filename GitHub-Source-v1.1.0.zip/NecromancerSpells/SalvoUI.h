#pragma once
using MagicUses=int(*)(Ptr);
static MagicUses originalMagicUses=nullptr;
static int SalvoUses(Ptr chr,int magic,int uses){
 if(uses>0||chr!=playerNow||(magic!=SalvoSpell&&!NecroSpell(magic)))return uses;
 SpellLock guard;if(magic==SalvoSpell)return SalvoCanPay(0)?1:uses;
 int fp=0;return NecroPlayerFP(fp)&&NecroCandidate()?1:uses;
}
static int HookMagicUses(Ptr chr){
 int result=originalMagicUses(chr);if(result>0||chr!=playerNow)return result;
 int magic=-1;
 {SpellLock guard;Ptr data=0,mods=0,equipment=0,vt=0,get=0;
  if(!CurrentPlayerData(data)||!ReadValue(chr+0x190,mods)||!ReadValue(mods+0x60,equipment)||!ReadValue(equipment,vt)||!ReadValue(vt+0x28,get)||get<base+0x1000||get>=base+0x3000000)return result;
  // Identical selected-magic accessor and output size to native657330.
  alignas(16) unsigned char out[32]{};Ptr entry=((Ptr(*)(Ptr,Ptr))get)(equipment,(Ptr)out);if(!ReadValue(entry,magic))return result;
 }
 return SalvoUses(chr,magic,result);
}
static void ConfigureSalvoUI(){
 const unsigned char sig[]={0x40,0x53,0x48,0x83,0xec,0x30,0x48,0x8b,0x81,0x90,0x01,0x00,0x00};unsigned char b[sizeof(sig)];
 if(!Read(base+0x657330,b,sizeof(b))||memcmp(b,sig,sizeof(b))){Log("SALVO_UI uses_signature_rejected");return;}
 auto s=MH_CreateHook((void*)(base+0x657330),(void*)&HookMagicUses,(void**)&originalMagicUses);if(s==MH_OK)s=MH_EnableHook((void*)(base+0x657330));Log("SALVO_UI remaining_casts_hook=%d readonly_eligibility=1",int(s));
}
