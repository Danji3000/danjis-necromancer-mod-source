// Phase-one real skeleton NPC prototype. ABI references and licenses in adjacent files.
// Experimental test build: engine integration still requires an offline game test.
// ABI references: fromsoftware-rs cs/task.rs and fd4/task.rs.
// Independent static checks are in verified_signatures.h and task_evidence.json.
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <bcrypt.h>
#include <cstdint>
#include <cstdio>
#include <cstdarg>
#include <cstring>
#include <cwchar>
#include <cstdlib>
#include <cmath>
#include "verified_signatures.h"
#include "retirement_signatures.h"
#include "known_unload_hook.h"
#include "SummonController.h"
#include "SkillPriority.h"
#include "Balance.h"
#include "CompactSpawn.h"
#include <new>

using Ptr=uintptr_t;
static HMODULE selfModule;
static Ptr base;
static unsigned long long readCalls=0,writeCalls=0;
static double writeMilliseconds=0,readMilliseconds=0;
static double stageMilliseconds[4]={};
struct StageTiming {LARGE_INTEGER start{};unsigned stage;StageTiming(unsigned n):stage(n){QueryPerformanceCounter(&start);}~StageTiming(){LARGE_INTEGER end{},freq{};QueryPerformanceCounter(&end);QueryPerformanceFrequency(&freq);stageMilliseconds[stage]+=(double)(end.QuadPart-start.QuadPart)*1000.0/freq.QuadPart;}};
static HANDLE logFile=INVALID_HANDLE_VALUE, instanceMutex;
static SRWLOCK logLock=SRWLOCK_INIT;
static volatile LONG stopped=0;

static void Log(const char* format,...) {
    char line[1024]; va_list args; va_start(args,format);
    int count=_vsnprintf(line,sizeof(line)-3,format,args); va_end(args);
    if(count<0)return;
    size_t n=(size_t)count; if(n>sizeof(line)-4)n=sizeof(line)-4;
    line[n++]='\r';line[n++]='\n';
    AcquireSRWLockExclusive(&logLock);
    if(logFile!=INVALID_HANDLE_VALUE){DWORD written=0;WriteFile(logFile,line,(DWORD)n,&written,nullptr);/* Do not force synchronous disk flush on the game thread. */}
    ReleaseSRWLockExclusive(&logLock);
}
#include "Performance.h"
// Measure game-thread work, excluding the periodic report itself.
struct CallbackTiming {
 LARGE_INTEGER start{}; bool main;
 CallbackTiming(bool isMain):main(isMain){QueryPerformanceCounter(&start);if(main)ObserveCallbackGap(start);}
 ~CallbackTiming(){
  static LARGE_INTEGER frequency{};static double mainTotal=0,retireTotal=0,peak=0;static unsigned mainCount=0,retireCount=0;static ULONGLONG last=0;
  LARGE_INTEGER end{};QueryPerformanceCounter(&end);if(!frequency.QuadPart)QueryPerformanceFrequency(&frequency);
  double ms=(double)(end.QuadPart-start.QuadPart)*1000.0/(double)frequency.QuadPart;
  if(main){mainTotal+=ms;++mainCount;}else{retireTotal+=ms;++retireCount;}if(ms>peak)peak=ms;
  ULONGLONG now=GetTickCount64();if(!last)last=now;
  if(main&&now-last>=10000){Log("PERF main_avg_ms=%.4f retire_avg_ms=%.4f peak_ms=%.4f main_calls=%u retire_calls=%u reads=%llu writes=%llu write_total_ms=%.4f",mainCount?mainTotal/mainCount:0,retireCount?retireTotal/retireCount:0,peak,mainCount,retireCount,readCalls,writeCalls,writeMilliseconds);ReportPerformance();readMilliseconds=0;for(double &v:stageMilliseconds)v=0;mainTotal=retireTotal=peak=0;mainCount=retireCount=0;readCalls=writeCalls=0;writeMilliseconds=0;last=now;}
 }
};
static bool Read(Ptr address,void* out,size_t size) {
    ++readCalls;
    if(address<0x10000 || address>0x7fffffffffffULL-size)return false;
    SIZE_T got=0;
    return ReadProcessMemory(GetCurrentProcess(),(void*)address,out,size,&got)&&got==size;
}
template<class T> static bool ReadValue(Ptr address,T& out){return Read(address,&out,sizeof(out));}
static bool Typed(Ptr object,Ptr rva){Ptr vt=0;return ReadValue(object,vt)&&vt==base+rva;}
static bool HashFile(const wchar_t* path,unsigned char digest[32]) {
    HANDLE file=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ,nullptr,OPEN_EXISTING,0,nullptr);
    if(file==INVALID_HANDLE_VALUE)return false;
    BCRYPT_ALG_HANDLE alg=nullptr; BCRYPT_HASH_HANDLE hash=nullptr;
    bool ok=false; DWORD count=0; unsigned char buffer[65536];
    if(BCryptOpenAlgorithmProvider(&alg,BCRYPT_SHA256_ALGORITHM,nullptr,0)<0)goto cleanup;
    if(BCryptCreateHash(alg,&hash,nullptr,0,nullptr,0,0)<0)goto cleanup;
    for(;;){
        if(!ReadFile(file,buffer,sizeof(buffer),&count,nullptr))goto cleanup;
        if(count==0)break;
        if(BCryptHashData(hash,buffer,count,0)<0)goto cleanup;
    }
    ok=BCryptFinishHash(hash,digest,32,0)>=0;
cleanup:
    if(hash)BCryptDestroyHash(hash);
    if(alg)BCryptCloseAlgorithmProvider(alg,0);
    CloseHandle(file);return ok;
}
static bool VerifyBuild(){
 wchar_t path[32768]; if(!GetModuleFileNameW(nullptr,path,32768))return false;
 unsigned char digest[32];
 return HashFile(path,digest)&&memcmp(digest,expectedSha256,32)==0;
}


// Kernel-validated data writes without WriteProcessMemory's page-query/protection path.
// This API never makes a read-only page writable. Same process; actual byte count checked.
extern "C" __declspec(dllimport) LONG NTAPI NtWriteVirtualMemory(HANDLE,PVOID,const void*,SIZE_T,PSIZE_T);
static bool Write(Ptr address,const void* data,size_t size){
 ++writeCalls;
 if(address<0x10000||address>0x7fffffffffffULL||!data||!size||size>0x7fffffffffffULL-address)return false;
 SIZE_T done=0;LONG status=NtWriteVirtualMemory(GetCurrentProcess(),(void*)address,data,size,&done);
 return status>=0&&done==size;
}
template<class T> static bool Put(Ptr a,T v){return Write(a,&v,sizeof(v));}
#include "PlayerCombat.h"
static bool playerInCombat=false,playerCombatReadable=false;
static Ptr worldNow=0,playerNow=0,creatorNow=0;
static int castingStaff=-1,debugStaff=-1;
static uint64_t sessionEpoch=1,npcHandle=0;static Ptr npcOrigin=0;
static bool giantBusy=false,callBusy=false;
static SRWLOCK spellLock=SRWLOCK_INIT;
struct SpellLock {SpellLock(){AcquireSRWLockExclusive(&spellLock);}~SpellLock(){ReleaseSRWLockExclusive(&spellLock);}};
static bool sentOnce=false,epochInvalid=false;static bool skillHeld=false,staffTwoHanded=false;static unsigned selectedStyle=~0u;static uint64_t playerActions=0;static int playerHP=0;static float spawnPosition[4]={};
enum class Presence { Unknown, Present, Missing };
static Presence Probe(uint64_t handle,Ptr& chr){
 chr=0;if(!worldNow||!handle)return Presence::Unknown;
 Ptr set=worldNow+0x10fe8,entries=0;uint32_t capacity=0,index=0;
 unsigned slot=(unsigned)handle&0xfffff,container=((unsigned)handle>>20)&255;
 if(!Typed(set,0x2a43348)||!ReadValue(set+8,index)||!ReadValue(set+0x10,capacity)||capacity>4096)return Presence::Unknown;
 if(!capacity)return Presence::Missing;
 if(!ReadValue(set+0x18,entries)||!entries)return Presence::Unknown;
 // Rest/load may reindex the debug collection. Scan the current valid set for the exact old handle.
 if(index!=container||slot>=capacity){
  for(unsigned i=0;i<capacity;++i){Ptr candidate=0;uint64_t actual=0;if(!ReadValue(entries+16*i,candidate))return Presence::Unknown;
   if(candidate){if(!ReadValue(candidate+8,actual))return Presence::Unknown;if(actual==handle)return Presence::Unknown;}}
  return Presence::Missing;
 }
 if(!ReadValue(entries+16*slot,chr))return Presence::Unknown;
 if(!chr)return Presence::Missing;
 uint64_t actual=0;int model=0,npc=0;
 if(!ReadValue(chr+8,actual))return Presence::Unknown;
 if(actual!=handle){chr=0;return Presence::Missing;}
 if(!ReadValue(chr+0x64,model)||!ReadValue(chr+0x60,npc)||!necro::ApprovedIdentity(model,npc))return Presence::Unknown;
 return Presence::Present;
}
static Ptr Resolve(uint64_t handle){Ptr chr=0;return Probe(handle,chr)==Presence::Present?chr:0;}
static bool PlayerState(necro::Observation& o){
 playerInCombat=false;playerCombatReadable=false;
 Ptr world=0,player=0,modules=0,physics=0,data=0,owner=0;
 if(!ReadValue(base+0x3d6d018,world)||!Typed(world,0x2a509d0)||!ReadValue(world+0x1e508,player)||!Typed(player,0x2a81cb0))return false;
 if(worldNow&&(worldNow!=world||playerNow!=player))epochInvalid=true;
 worldNow=world;playerNow=player;
 if(!ReadValue(player+0x190,modules)||!ReadValue(modules+0x68,physics)||!ReadValue(physics+8,owner)||owner!=player)return false;
 if(!ReadValue(modules,data)||!data)return false;
 int hp=0;unsigned char grounded=0;float q[4],pos[4];
 if(!ReadValue(data+0x138,hp)||hp<=0||!Read(physics+0x50,q,16)||!Read(physics+0x70,pos,16)||!ReadValue(physics+0x92,grounded))return false;
 for(float v:pos)if(!std::isfinite(v)||fabsf(v)>1e7f)return false;
 for(float v:q)if(!std::isfinite(v)||fabsf(v)>1.01f)return false;
 playerCombatReadable=ReadPlayerCombat(playerInCombat);
 playerHP=hp;playerActions=0;skillHeld=false;staffTwoHanded=false;castingStaff=debugStaff=-1;
 Ptr action=0;
 if(ReadValue(modules+0x80,action)&&Typed(action,0x2a34790)&&ReadValue(action+8,owner)&&owner==player)ReadValue(action+0x10,playerActions);
 skillHeld=(playerActions&8)!=0;
 o.position={pos[0],pos[1],pos[2]};o.forwardX=2*(q[0]*q[2]+q[3]*q[1]);o.forwardZ=1-2*(q[0]*q[0]+q[1]*q[1]);
 o.playerReady=true;o.onGround=grounded!=0;o.epoch=sessionEpoch+(epochInvalid?1:0);
 Ptr assembly=0;uint32_t slots[2]={};int ids[6]={};
 if(ReadValue(player+0x638,assembly)&&Read(assembly+0xc,slots,8)&&slots[0]<3&&slots[1]<3&&Read(assembly+0x7c,ids,24)){
  int l=ids[slots[0]*2],r=ids[slots[1]*2+1];unsigned style=0;ReadValue(assembly+8,style);selectedStyle=style;staffTwoHanded=(style==2&&necro::IsSummonStaff(l))||((style==3||style==0||style==1)&&necro::IsSummonStaff(r));o.staffSelected=necro::IsSummonStaff(l)||necro::IsSummonStaff(r);
  castingStaff=necro::SummonStaffForCast(l,r,style);debugStaff=castingStaff>=0?castingStaff:(necro::IsSummonStaff(l)?l:(necro::IsSummonStaff(r)?r:-1));
 }
 creatorNow=0;ReadValue(world+0x1e658,creatorNow);
 unsigned char pending=1;
 o.creatorReady=Typed(creatorNow,0x2a53340)&&ReadValue(creatorNow+0x44,pending)&&pending==0;
 return true;
}
// Use the game's actual equipped (including infused) left-hand skill, not weapon-ID guesses.
static int (*skillGetter)(Ptr,int)=nullptr;
static bool AriseHasPriority(){
 if(!staffTwoHanded)return false;
 if(selectedStyle==2||selectedStyle==3)return true;
 if(selectedStyle!=1&&selectedStyle!=0)return false;
 Ptr modules=0,arts=0,owner=0;
 if(!skillGetter||!ReadValue(playerNow+0x190,modules)||!ReadValue(modules+0x110,arts)||!Typed(arts,0x2a40218)||!ReadValue(arts+8,owner)||owner!=playerNow)return false;
 return LeftArtAllowsRight(skillGetter(arts,-2));
}
static float TaskSeconds(const void* taskData){
 // FD4TaskData starts with FD4Time: vtable (8 bytes), THEN float time.
 float dt=0;if(!taskData||!ReadValue((Ptr)taskData+8,dt)||!std::isfinite(dt)||dt<0||dt>1)return 0;
 return dt;
}
static bool CharacterPhysics(Ptr chr,Ptr& physics,necro::Position& pos,int& hp){
 Ptr modules=0,data=0,owner=0;
 if(!ReadValue(chr+0x190,modules)||!ReadValue(modules+0x68,physics)||!Typed(physics,0x2a3e890)||!ReadValue(physics+8,owner)||owner!=chr||!ReadValue(modules,data)||!ReadValue(data+0x138,hp)||!Read(physics+0x70,&pos,sizeof(pos)))return false;
 return std::isfinite(pos.x)&&std::isfinite(pos.y)&&std::isfinite(pos.z)&&fabsf(pos.x)<1e7f&&fabsf(pos.y)<1e7f&&fabsf(pos.z)<1e7f;
}
static float Distance2(necro::Position a,necro::Position b){float x=a.x-b.x,y=a.y-b.y,z=a.z-b.z;return x*x+y*y+z*z;}
static bool AICommand(Ptr chr,float command,bool own){
 if(!Typed(chr,0x2a49090))return false;
 Ptr manip=0,owner=0,ai=0;
 // EnemyIns::com_manipulator; ComManipulator::owner +0xa8 / AiIns +0xc0.
 if(!ReadValue(chr+0x580,manip)||!Typed(manip,0x2a2ed80)||!ReadValue(manip+0xa8,owner)||owner!=chr||!ReadValue(manip+0xc0,ai)||!ai)return false;
 float before=0;unsigned flags=0;
 if(!ReadValue(ai+0xc45c,before)||!ReadValue(ai+0xc46c,flags))return false;
 if(!own&&before!=0&&before!=100&&before!=110)return false;
 if(before==command)return true;
 // Same float slot + changed-bit update as verified game setter 0x2da060.
 return Put<float>(ai+0xc45c,command)&&Put<unsigned>(ai+0xc46c,flags|1);
}
static bool CatchUp(Ptr chr,const necro::Observation&o){
 Ptr physics=0;necro::Position pos{};int hp=0;
 if(!o.onGround||!CharacterPhysics(chr,physics,pos,hp)||hp<=0||Distance2(pos,o.position)<=2500)return false;
 // Land on the player's verified ground location. Do not place blindly behind a cliff edge.
 necro::Position target=o.position;target.y+=.3f;
 if(!Write(physics+0x70,&target,sizeof(target))||!Put<unsigned char>(physics+0x91,1))return false;
 Log("CATCH_UP npc=%p distance2=%.1f",(void*)chr,Distance2(pos,o.position));return true;
}
struct CombatGate {
 int player=-1,npc=-1;float seconds=0;uint64_t previous=0;bool playerEngaged=false;
 void Tick(int playerNowHP,int npcNowHP,uint64_t actions,float dt,bool inCombat=false){
  playerEngaged=inCombat;
  // R1/R2, caster actions. L2 summon and guard alone never open combat.
  const uint64_t attacks=3ULL|(3ULL<<33);
  if((player>=0&&playerNowHP<player)||(npc>0&&npcNowHP<npc)||((actions&attacks)&~previous))seconds=12;
  else if(dt>0){seconds-=dt;if(seconds<0)seconds=0;}
  player=playerNowHP;npc=npcNowHP;previous=actions&attacks;
 }
 bool Active() const{return playerEngaged||seconds>0;}
 void Reset(){player=npc=-1;seconds=0;previous=0;playerEngaged=false;}
};
static CombatGate combat;
struct SpiritTrack {uint64_t handle;bool command;};static SpiritTrack spiritTracks[4096]={};
static bool SacrificeReserved(uint64_t handle);
static void SpiritFollow(const necro::Observation&o){
 Ptr set=worldNow+0x10f90,entries=0;unsigned cap=0;
 if(!Typed(set,0x2a43348)||!ReadValue(set+0x10,cap)||cap>4096||!ReadValue(set+0x18,entries)||!entries)return;
 Ptr snapshot[8192];if(!Read(entries,snapshot,(size_t)cap*16))return;
 for(unsigned i=0;i<cap;++i){
  Ptr chr=snapshot[i*2],physics=0;uint64_t handle=0;int model=0,hp=0;necro::Position pos{};
  if(!chr||!ReadValue(chr+8,handle)||!ReadValue(chr+0x64,model)||model==8000||!CharacterPhysics(chr,physics,pos,hp)||hp<=0)continue;
  if(SacrificeReserved(handle))continue;
  if(spiritTracks[i].handle!=handle)spiritTracks[i]={handle,false};
  if(!o.staffSelected){if(spiritTracks[i].command&&AICommand(chr,0,false))spiritTracks[i].command=false;continue;}
  // Buddy set excludes ordinary world enemies; exclude Torrent explicitly.
  necro::Position home{o.position.x-o.forwardX*2.8f,o.position.y,o.position.z-o.forwardZ*2.8f};
  necro::Position previousHome{};if(Read(chr+0x90,&previousHome,sizeof(previousHome))&&memcmp(&previousHome,&home,sizeof(home)))Write(chr+0x90,&home,sizeof(home));
  float d2=Distance2(pos,o.position);
  if(d2>144){if(AICommand(chr,110,false))spiritTracks[i].command=true;}
  else if(d2<36&&spiritTracks[i].command){if(AICommand(chr,0,false))spiritTracks[i].command=false;}
  CatchUp(chr,o);
 }
}
// Uses the game's single-character deferred-retirement sequence at 0x4ed146..0x4ed1b6.
// Never calls a destructor/free directly from this callback.
// Accept the vanilla entry or the exact observed SubtleFemaleShape UniHook chain.
// Calling the chain preserves the other mod's bookkeeping before vanilla unload.
static bool VerifiedUnload(Ptr target,Ptr shapeModule){
 if(target==base+0x4d0370)return true;
 if(!shapeModule||target<0x50)return false;
 Ptr header=target-0x50,slot=0,callback=0,original=0;
 unsigned char magic[8]={},code[sizeof(knownUnloadTrampoline)]={},cb[sizeof(knownShapeUnloadCallback)]={};
 static const unsigned char expectedMagic[8]={'U','n','i','H','o','o','k',0};
 return Read(header,magic,8)&&!memcmp(magic,expectedMagic,8)
  &&ReadValue(header+0x30,slot)&&slot==base+0x2a49090+0x58
  &&ReadValue(header+0x38,callback)&&callback==shapeModule+0xe440
  &&ReadValue(header+0x40,original)&&original==base+0x4d0370
  &&Read(target,code,sizeof(code))&&!memcmp(code,knownUnloadTrampoline,sizeof(code))
  &&Read(callback,cb,sizeof(cb))&&!memcmp(cb,knownShapeUnloadCallback,sizeof(cb));
}
struct RemovalAPI {
 Ptr (*detach)(Ptr,unsigned)=nullptr;
 void (*prepare)(Ptr)=nullptr;
 void (*unload)(Ptr)=nullptr;
 bool (*enqueue)(Ptr,Ptr)=nullptr;
 bool (*validate)()=nullptr;
};
static RemovalAPI removalAPI;
static bool ValidateRemovalDispatch(){
 Ptr prepare=0,unload=0;
 return ReadValue(base+0x2a49090+0x618,prepare)&&prepare==(Ptr)removalAPI.prepare
  &&ReadValue(base+0x2a49090+0x58,unload)&&unload==(Ptr)removalAPI.unload
  &&VerifiedUnload(unload,(Ptr)GetModuleHandleW(L"SubtleFemaleShape.dll"));
}
static bool removalAttempted=false,removalFailed=false,removalPhase=false;
static volatile LONG removalPending=0;static uint64_t pendingHandle=0,pendingEpoch=0;
// WorldChrMan respawn vector is consumed by 507360 and erased by native 50b5f0..50b62d.
// Remove only our exact owned pointer before unload, otherwise grace dereferences freed modules.
static bool UnlinkRespawnEntry(Ptr chr){
 Ptr bounds[3]{};
 if(!Read(worldNow+0x1e640,bounds,sizeof(bounds)))return false;
 Ptr begin=bounds[0],end=bounds[1],cap=bounds[2];
 if(begin==0&&end==0&&cap==0)return true;
 if(begin<0x10000||end<begin||cap<end||((end-begin)&7)||(end-begin)/8>4096)return false;
 size_t count=(end-begin)/8;if(!count)return true;
 Ptr original[4096],kept[4096];if(!Read(begin,original,count*8))return false;
 size_t n=0;for(size_t i=0;i<count;++i)if(original[i]!=chr)kept[n++]=original[i];
 if(n==count)return true;
 Ptr current[3]{};if(!Read(worldNow+0x1e640,current,sizeof(current))||memcmp(current,bounds,sizeof(bounds)))return false;
 // At FrameEnd, no game respawn iteration is active. Never leave a half-updated vector on error.
 if(n&&!Write(begin,kept,n*8)){
  if(!Write(begin,original,count*8))removalFailed=true;
  return false;
 }
 if(!Put<Ptr>(worldNow+0x1e648,begin+n*8)){
  if(!Write(begin,original,count*8))removalFailed=true;
  return false;
 }
 Log("RETIRE_RESPAWN_UNLINK removed=%u kept=%u",unsigned(count-n),unsigned(n));return true;
}
static void ForgetCovenantActor(uint64_t handle,Ptr chr);
static bool RetireOwned(uint64_t epoch,uint64_t handle){
 if(!removalPhase||removalAttempted||removalFailed||epochInvalid||epoch!=sessionEpoch||!handle||handle!=npcHandle||!removalAPI.detach||!removalAPI.prepare||!removalAPI.unload||!removalAPI.enqueue){Log("RETIRE_PRECONDITION phase=%d attempted=%d failed=%d epoch_invalid=%d epoch=%llu current=%llu handle=%llx tracked=%llx",removalPhase,removalAttempted,removalFailed,epochInvalid,(unsigned long long)epoch,(unsigned long long)sessionEpoch,(unsigned long long)handle,(unsigned long long)npcHandle);return false;}
 if(removalAPI.validate&&!removalAPI.validate()){Log("RETIRE_DISPATCH_CHANGED: no removal performed");return false;}
 Ptr chr=Resolve(handle),queue=0,allocator=0,allocatorVT=0,lists=0,alternateLists=0;unsigned rings=0;unsigned char flags=0;
 if(!chr||chr!=npcOrigin||chr==playerNow||!Typed(chr,0x2a49090)||!ReadValue(chr+0x1c5,flags)){Log("RETIRE_OWNERSHIP_REJECTED chr=%llx origin=%llx player=%llx",(unsigned long long)chr,(unsigned long long)npcOrigin,(unsigned long long)playerNow);return false;}
 if(!ReadValue(base+0x4590748,queue)||!queue||!ReadValue(queue,allocator)||!ReadValue(allocator,allocatorVT)||!allocatorVT||!ReadValue(queue+0xc,rings)||!rings||!ReadValue(queue+0x10,lists)||!lists||!ReadValue(queue+0x60,alternateLists)||!alternateLists){Log("RETIRE_QUEUE_GUARD queue=%llx allocator=%llx allocator_vt=%llx rings=%u lists=%llx",(unsigned long long)queue,(unsigned long long)allocator,(unsigned long long)allocatorVT,rings,(unsigned long long)lists);return false;}
 // Native e7a48b..e7a4c3 selects min(1, rings-1) from either list array.
 // Validate exactly the used slots; there is no native upper bound of eight rings.
 Ptr selectedOffset=(rings>1?1:0)*16;Ptr queueSlot[2]{};
 if(!Read(lists+selectedOffset,queueSlot,sizeof(queueSlot))||!Read(alternateLists+selectedOffset,queueSlot,sizeof(queueSlot))){Log("RETIRE_QUEUE_SLOT_UNREADABLE");return false;}
 // Exact handle and origin rechecked immediately before the first mutation.
 if(Resolve(handle)!=chr){Log("RETIRE_HANDLE_CHANGED");return false;}
 Ptr creatorAlias=0;
 if(creatorNow&&ReadValue(creatorNow+0x1b0,creatorAlias)&&creatorAlias==chr&&!Put<Ptr>(creatorNow+0x1b0,0)){Log("RETIRE_CREATOR_ALIAS_FAILED");return false;}
 if(!UnlinkRespawnEntry(chr)){Log("RETIRE_RESPAWN_UNLINK_REJECTED: no unload");return false;}
 removalAttempted=true;
 Ptr removed=removalAPI.detach(worldNow+0x10fe8,(unsigned)handle&0xfffff);
 if(removed!=chr){removalFailed=true;Log("RETIRE_DETACH_REJECTED: quarantine; no retry");return false;}
 Ptr remaining=0;
 if(Probe(handle,remaining)!=Presence::Missing){removalFailed=true;Log("RETIRE_DETACH_NOT_CONFIRMED: quarantine");return false;}
 // The registry no longer owns this actor. Forget retained aura/speed pointers
 // before native unload clears +178 and frees the effect/behavior modules.
 ForgetCovenantActor(handle,chr);
 if(!Put<unsigned char>(chr+0x1c5,flags|0x20)){removalFailed=true;Log("RETIRE_FLAG_FAILED: quarantine");return false;}
 removalAPI.prepare(chr);
 removalAPI.unload(chr);
 // The native queue owns final destruction. Do not read chr after enqueue.
 bool queued=removalAPI.enqueue(queue,chr);
 if(!queued){removalFailed=true;Log("RETIRE_QUEUE_FAILED: detached allocation retained; restart required");return false;}
 Log("RETIRE_QUEUED handle=%llx detached=1 hp_unchanged=1; native deferred destruction; game test pending",(unsigned long long)handle);
 return true;
}
// Same c3510 skeleton and original registered finite get-up animation.
// Only initialize our own request; restore the shared creator input after capture.
static constexpr int kAriseRiseAnimation=20000;
static Ptr riseCreator=0;
static int risePreviousAnimation=0;
static bool riseInputPending=false;
static int riseRequestedAnimation=20000;
static bool PrepareRiseInput(int animation=20000){
 if(riseInputPending)return false;
 int previous=0;if(!ReadValue(creatorNow+0x1a4,previous))return false;
 if(!Put<int>(creatorNow+0x1a4,animation))return false;
 riseRequestedAnimation=animation;riseCreator=creatorNow;risePreviousAnimation=previous;riseInputPending=true;return true;
}
static void RestoreRiseInput(){
 if(!riseInputPending)return;
 int current=0;
 if(creatorNow==riseCreator&&ReadValue(riseCreator+0x1a4,current)&&current==riseRequestedAnimation){
  if(!Put<int>(riseCreator+0x1a4,risePreviousAnimation)){Log("ARISE_RISE_RESTORE_FAILED: no further casts");epochInvalid=true;return;}
 }
 riseInputPending=false;riseCreator=0;
}
class NativeEngine final:public necro::Engine {
public:
 bool Request(const necro::SpawnRequest&r)override{
  PerfScope perf(PerfSpawn);
  if(sentOnce||epochInvalid||!necro::ApprovedCandidate(r.npc)||r.team!=47)return false;
  Ptr debugSet=worldNow+0x10fe8,entryArray=0;unsigned cap=0,setIndex=0;
  if(!Typed(debugSet,0x2a43348)||!ReadValue(debugSet+8,setIndex)||setIndex>=196||!ReadValue(debugSet+0x10,cap)||!cap||cap>4096||!ReadValue(debugSet+0x18,entryArray)||!entryArray){Log("DEBUG_CHR_SET_REJECTED: no spawn");return false;}
  necro::Observation now{};if(!PlayerState(now)||!now.onGround||(r.npc.npc!=89090000&&!now.staffSelected)||!now.creatorReady)return false;
  // Compact group placement, only while the player is grounded. Keep the confirmed height/rise motion.
  auto point=CompactSpawn(now,r.formationSlot,r.formationCount);
  if(r.npc.npc==89090000){point=now.position;point.x+=now.forwardX*6.f;point.z+=now.forwardZ*6.f;}
  float pos[4]={point.x,point.y+.3f,point.z,0};
  wchar_t name[32]={L'c',wchar_t(L'0'+r.npc.model/1000%10),wchar_t(L'0'+r.npc.model/100%10),wchar_t(L'0'+r.npc.model/10%10),wchar_t(L'0'+r.npc.model%10)};
  // All preparation must succeed before committing the engine's spawn flag.
  bool ok=Put<Ptr>(creatorNow+0x1b0,0)&&Write(creatorNow+0xb0,pos,sizeof(pos))&&
   Put<int>(creatorNow+0xf0,r.npc.npc)&&Put<int>(creatorNow+0xf4,r.npc.think)&&
   Put<int>(creatorNow+0xf8,0)&&Put<int>(creatorNow+0xfc,0)&&Write(creatorNow+0x100,name,sizeof(name))&&Put<int>(creatorNow+0x17c,-1)&&Put<unsigned>(creatorNow+0x19c,1);
  if(!ok||!PrepareRiseInput(r.npc.npc==89090000?20011:kAriseRiseAnimation)){epochInvalid=true;Log("PREPARE_FAILED: restart required");return false;}
  sentOnce=true;memcpy(spawnPosition,pos,16);
  if(!Put<unsigned char>(creatorNow+0x44,1)){RestoreRiseInput();epochInvalid=true;Log("SPAWN_COMMIT_FAILED");return false;}
  if(r.npc.npc==89090000)MarkGiantRequest();
  Log("SPAWN_REQUEST c%d npc=%d think=%d team=47 initial_animation=20000; own spawn",r.npc.model,r.npc.npc,r.npc.think);return true;
 }
 bool SetAlly(uint64_t epoch,uint64_t handle,unsigned team)override{
  if(epoch!=sessionEpoch||epochInvalid||team!=47)return false;Ptr chr=Resolve(handle);
  unsigned char current=0;return chr&&ReadValue(chr+0x6c,current)&&(current==47||Put<unsigned char>(chr+0x6c,47));
 }
 bool FollowHome(uint64_t epoch,uint64_t handle,necro::Position pos)override{
  if(epoch!=sessionEpoch||epochInvalid)return false;Ptr chr=Resolve(handle);
  necro::Position current{};return chr&&Read(chr+0x90,&current,sizeof(current))&&(!memcmp(&current,&pos,sizeof(pos))||Write(chr+0x90,&pos,sizeof(pos)));
 }
 bool Remove(uint64_t epoch,uint64_t handle)override{return RetireOwned(epoch,handle);}
};
alignas(NativeEngine) static unsigned char engineStorage[sizeof(NativeEngine)];
alignas(necro::Controller) static unsigned char controllerStorage[sizeof(necro::Controller)];
static NativeEngine* engine;static necro::Controller* controller;
// Missing handles must be observed in a readable collection; HP0 is never removal.
static float missingSeconds=0;
static bool Rearm(const necro::Observation& o,float dt){
 Ptr chr=0;
 if(removalFailed||!sentOnce||!npcHandle||!o.playerReady||!o.creatorReady||!std::isfinite(dt)||dt<=0||dt>1||Probe(npcHandle,chr)!=Presence::Missing){missingSeconds=0;return false;}
 missingSeconds+=dt;if(missingSeconds<.5f)return false;
 InterlockedExchange(&removalPending,0);pendingHandle=0;pendingEpoch=0;
 *controller=necro::Controller();combat.Reset();removalAttempted=false;removalFailed=false;++sessionEpoch;sentOnce=false;npcHandle=0;npcOrigin=0;epochInvalid=false;missingSeconds=0;
 Log("REMOVAL_CONFIRMED: READY; no existing NPC removed");return true;
}
static void Execute(void*,const void* taskData){
 CallbackTiming timing(true);
 static bool first=true,oldKey=false;static unsigned frames=0;static bool hadPlayer=false;static bool havePosition=false;static necro::Position lastPosition{};
 if(InterlockedCompareExchange(&stopped,0,0))return;
 if(first){Log("GAME_TASK_ACTIVE group=113; normal skill input only");first=false;}
 necro::Observation o{};bool ready=false;{StageTiming stage(0);ready=PlayerState(o);}
 if(!ready){if(hadPlayer&&sentOnce)epochInvalid=true;oldKey=false;havePosition=false;missingSeconds=0;return;}hadPlayer=true;
 float dt=TaskSeconds(taskData);
 if(havePosition&&sentOnce){float dx=o.position.x-lastPosition.x,dy=o.position.y-lastPosition.y,dz=o.position.z-lastPosition.z;if(dx*dx+dy*dy+dz*dz>6400)epochInvalid=true;}
 lastPosition=o.position;havePosition=true;
 {StageTiming stage(1);SpiritFollow(o);}
 {StageTiming stage(2);
 Rearm(o,dt);o.epoch=sessionEpoch+(epochInvalid?1:0);
 if(sentOnce){
  if(!npcHandle&&creatorNow){
   Ptr candidate=0;uint64_t h=0;
   if(ReadValue(creatorNow+0x1b0,candidate)&&candidate&&ReadValue(candidate+8,h)&&Resolve(h)==candidate){npcHandle=h;npcOrigin=candidate;Log("CREATED handle=%llx; team assignment pending",(unsigned long long)h);}
  }
  Ptr chr=Resolve(npcHandle);o.handle=npcHandle;o.exists=chr!=0;
  if(chr){Ptr mods=0,data=0;if(ReadValue(chr+0x190,mods)&&ReadValue(mods,data))ReadValue(data+0x138,o.hp);}
  if(chr&&!epochInvalid){
   combat.Tick(playerHP,o.hp,playerActions,dt,playerInCombat);
   if(o.hp>0){AICommand(chr,combat.Active()?1.f:0.f,true);CatchUp(chr,o);}
  }
  o.epoch=sessionEpoch+(epochInvalid?1:0);
 }
 necro::State before=controller->state();controller->Tick(o,dt,*engine);
 if(controller->state()!=before)Log("STATE %u -> %u hp=%d",(unsigned)before,(unsigned)controller->state(),o.hp);
 }
 StageTiming inputStage(3);
 bool down=skillHeld&&staffTwoHanded;
 if(down&&!oldKey){bool ok=controller->Trigger(o,*engine);Log("SUMMON accepted=%d selected=%d ground=%d creator=%d state=%u",ok,o.staffSelected,o.onGround,o.creatorReady,(unsigned)controller->state());}
 oldKey=down;
 if(sentOnce&&++frames%300==0)Log("NPC_STATUS state=%u exists=%d hp=%d epoch_valid=%d",(unsigned)controller->state(),o.exists,o.hp,!epochInvalid);
 if(sentOnce&&frames%300==0){Ptr p=0;Log("DIAGNOSTIC dt=%.6f presence=%u combat=%.2f skill=%d",dt,(unsigned)Probe(npcHandle,p),combat.seconds,skillHeld);}
}
// Registration uses index 168; the live scheduler stores its qualified ID 0x900000a8.
// Accept only these two exact identities, never arbitrary groups with matching low bits.
static bool IsRetirementPhase(unsigned phase){return phase==168||phase==0x900000a8;}
static void ExecuteRetirement(void*,const void* taskData){
 CallbackTiming timing(false);
 static bool first=true;unsigned phase=0;
 if(InterlockedCompareExchange(&stopped,0,0)||!taskData||!ReadValue((Ptr)taskData+0x10,phase))return;
 if(first){Log("RETIREMENT_CALLBACK_ACTIVE raw_phase=%08x recognized=%d",phase,IsRetirementPhase(phase));first=false;}
 if(!IsRetirementPhase(phase)){
  if(InterlockedExchange(&removalPending,0))Log("RETIRE_PHASE_REJECTED raw_phase=%08x; no removal",phase);
  return;
 }
 if(InterlockedExchange(&removalPending,0)==0)return;
 necro::Observation o{};
 if(pendingEpoch!=sessionEpoch||pendingHandle!=npcHandle||!PlayerState(o)){Log("RETIRE_CANCELLED: player/epoch changed");return;}
 o.handle=npcHandle;o.exists=Resolve(npcHandle)!=0;
 Log("RETIRE_CONTROLLER_INPUT state=%u epoch=%llu current=%llu exists=%d handle=%llx",(unsigned)controller->state(),(unsigned long long)o.epoch,(unsigned long long)sessionEpoch,o.exists,(unsigned long long)o.handle);
 removalPhase=true;bool ok=controller->RequestRemoval(o,*engine);removalPhase=false;
 Log("FRAME_END_RETIRE accepted=%d state=%u handle=%llx",ok,(unsigned)controller->state(),(unsigned long long)npcHandle);
}
#include "GroupAdapter.h"
#include "Sacrifice.h"
#include "SalvoPayment.h"
#include "SoulArrival.h"
#include "SalvoUI.h"
#include "RollThrough.h"
static Ptr RuntimeClass(void*){return 0;}
static void Destroy(void*){InterlockedExchange(&stopped,1);}
struct Task {void** vtable;Ptr unk8;};
static void* taskVtable[]={(void*)&RuntimeClass,(void*)&Destroy,(void*)&ExecuteGroup};
static Task task={taskVtable,0};
static void* sacrificeVtable[]={(void*)&RuntimeClass,(void*)&Destroy,(void*)&ExecuteSacrifice};
static Task sacrificeTask={sacrificeVtable,0};
static void* retirementVtable[]={(void*)&RuntimeClass,(void*)&Destroy,(void*)&ExecuteGroupRetirement};
static Task retirementTask={retirementVtable,0};
static void ConfigureSkillGetter(){
 unsigned char bytes[sizeof(skillGetterBytes)]{};
 if(Read(base+0x47ffe0,bytes,sizeof(bytes))&&!memcmp(bytes,skillGetterBytes,sizeof(bytes)))skillGetter=(int(*)(Ptr,int))(base+0x47ffe0);
 else Log("SKILL_GETTER_REJECTED: one-handed Arise disabled");
}
static bool ConfigureRemoval(){
 removalAPI={};
 bool signaturesOK=true;
 for(const auto& sig:retirementSignatures){unsigned char observed[128];if(sig.size>sizeof(observed)||!Read(base+sig.rva,observed,sig.size)||memcmp(observed,sig.bytes,sig.size)){Log("RETIREMENT_SIGNATURE_REJECTED rva=%llx; retirement disabled, summon remains available",(unsigned long long)sig.rva);signaturesOK=false;break;}}
 Ptr virtualPrepare=0,virtualUnload=0;
 bool prepareRead=ReadValue(base+0x2a49090+0x618,virtualPrepare);
 bool unloadRead=ReadValue(base+0x2a49090+0x58,virtualUnload);
 Log("RETIREMENT_DIAGNOSTIC base=%llx prepare=%llx expected=%llx read=%d unload=%llx expected=%llx read=%d",(unsigned long long)base,(unsigned long long)virtualPrepare,(unsigned long long)(base+0x3ee5c0),prepareRead,(unsigned long long)virtualUnload,(unsigned long long)(base+0x4d0370),unloadRead);
 if(!signaturesOK||!prepareRead||virtualPrepare!=base+0x3ee5c0||!unloadRead||!VerifiedUnload(virtualUnload,(Ptr)GetModuleHandleW(L"SubtleFemaleShape.dll"))){Log("REMOVAL_DISABLED: verification failed; skill input and following remain enabled");return false;}
 removalAPI.detach=(Ptr(*)(Ptr,unsigned))(base+0x494ff0);
 removalAPI.prepare=(void(*)(Ptr))(base+0x3ee5c0);
 removalAPI.unload=(void(*)(Ptr))virtualUnload;
 removalAPI.validate=&ValidateRemovalDispatch;
 Log("REMOVAL_ENABLED: unload=%s; dispatch rechecked before detach",virtualUnload==base+0x4d0370?"vanilla":"verified SubtleFemaleShape UniHook chain");
 removalAPI.enqueue=(bool(*)(Ptr,Ptr))(base+0xe7a400);
 return true;
}
static DWORD WINAPI Start(void*){
 HMODULE pinned=nullptr;if(!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_PIN,(LPCWSTR)&Start,&pinned))return 0;
 instanceMutex=CreateMutexW(nullptr,FALSE,L"Local\\DanjiOneSkeleton272");if(!instanceMutex||GetLastError()==ERROR_ALREADY_EXISTS)return 0;
 wchar_t path[32768];DWORD n=GetModuleFileNameW(selfModule,path,32768);if(!n||n>=32760)return 0;
 wchar_t* dot=wcsrchr(path,L'.');if(!dot)return 0;wcscpy(dot,L".log");logFile=CreateFileW(path,GENERIC_WRITE,FILE_SHARE_READ,nullptr,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,nullptr);
 Log("Danji Necromancer Mod 1.0.0 / player combat state + existing attack/retaliation / progression0..25 / maximum10 / five per Arise / 50FP+30stamina / release: no keyboard test commands / follow, resurrection and retirement unchanged");
 Log("CALL_OF_THE_GRAVE v3: novice staff0..24=2/cap4,25=trio3/cap6;20FP+20stamina;separate FIFO;ash-reference strength;Covenant enhancement v2 preserved");
 Log("PERFORMANCE v4: fresh exact-hit lookup, batched guarded reads, shared per-tick recipient scan; VFX and gameplay assets unchanged; per-field timing disabled");
 base=(Ptr)GetModuleHandleW(nullptr);if(!base||!VerifyBuild()){Log("EXE_HASH_REJECTED: no game writes or calls");return 0;}
 combatReaderVerified=ValidateCombatReader();
 if(!combatReaderVerified){Log("COMBAT_READER_SIGNATURE_REJECTED: no new combat reads; previous attack/damage behavior retained.");}
 else Log("COMBAT_READER_VERIFIED: read-only map/stamina battle state; all summon/follow/removal behavior retained.");
 unsigned char bytes[sizeof(registerSignature)]={};
 if(!Read(base+0xeb5540,bytes,sizeof(bytes))||memcmp(bytes,registerSignature,sizeof(bytes))){Log("REGISTER_SIGNATURE_REJECTED");return 0;}
 engine=new(engineStorage) NativeEngine();controller=new(controllerStorage) necro::Controller();combat.Reset();
 for(unsigned i=0;i<2400;++i){
  Ptr tasks=0,world=0,player=0;
  if(ReadValue(base+0x4592ea8,tasks)&&Typed(tasks,0x2c06db0)&&ReadValue(base+0x3d6d018,world)&&Typed(world,0x2a509d0)&&ReadValue(world+0x1e508,player)&&Typed(player,0x2a81cb0)){
   ConfigureSkillGetter();bool canRemove=ConfigureRemoval();
 spellRuntimeReady=canRemove&&ConfigureSpellHook();
 if(spellRuntimeReady&&!ConfigureEnhancement())Log("COVENANT_ENHANCEMENT_DISABLED: existing covenant and giants retained");
 if(spellRuntimeReady && enhancementReady){ConfigureSacrifice();ConfigureRollThrough();ConfigureSalvoPayment();ConfigureSalvoUI();}
 if(!spellRuntimeReady)Log("SPELL_RUNTIME_DISABLED: verification failed; existing Arise remains available");
   using Register=void(*)(Ptr,unsigned,Task*);((Register)(base+0xeb5540))(tasks,113,&task);
   if(constructSacrificeInput)((Register)(base+0xeb5540))(tasks,113,&sacrificeTask);
   if(canRemove)((Register)(base+0xeb5540))(tasks,168,&retirementTask);
   Log("TASK_REGISTERED: waiting for callback");return 0;
  }
  Sleep(250);
 }
 Log("PLAYER_WAIT_TIMEOUT");return 0;
}
extern "C" BOOL WINAPI DllMain(HMODULE module,DWORD reason,LPVOID){
 if(reason==DLL_PROCESS_ATTACH){selfModule=module;DisableThreadLibraryCalls(module);HANDLE t=CreateThread(nullptr,0,Start,nullptr,0,nullptr);if(t)CloseHandle(t);}
 if(reason==DLL_PROCESS_DETACH)InterlockedExchange(&stopped,1);return TRUE;
}


