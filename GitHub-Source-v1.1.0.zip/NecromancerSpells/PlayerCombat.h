#pragma once
// Exact executable evidence: map restriction AND out-of-combat stamina setter.
// Only read the existing engine state; no hook, flag writes, or actor scan.
static bool combatReaderVerified=false;
static bool ValidateCombatReader(){
 const unsigned char sig0[]={0x48,0x8b,0x89,0x28,0x03,0x00,0x00,0x48,0x85,0xc9,0x0f,0x85,0x80,0xbd,0x00,0x00,0x32,0xc0,0xc3};
 unsigned char got0[sizeof(sig0)]={};
 if(!Read(base+0xdaa5e0,got0,sizeof(got0))||memcmp(got0,sig0,sizeof(got0)))return false;
 const unsigned char sig1[]={0xe9,0xce,0x15,0x34,0xff};
 unsigned char got1[sizeof(sig1)]={};
 if(!Read(base+0xdb6370,got1,sizeof(got1))||memcmp(got1,sig1,sizeof(got1)))return false;
 const unsigned char sig2[]={0x0f,0xb6,0x41,0x04,0x48,0x8d,0x64,0x24,0x08,0xff,0x64,0x24,0xf8};
 unsigned char got2[sizeof(sig2)]={};
 if(!Read(base+0xf7943,got2,sizeof(got2))||memcmp(got2,sig2,sizeof(got2)))return false;
 const unsigned char sig3[]={0x48,0x8d,0x05,0xdc,0x2b,0xe2,0x01,0x48,0x89,0x01};
 unsigned char got3[sizeof(sig3)]={};
 if(!Read(base+0xda524d,got3,sizeof(got3))||memcmp(got3,sig3,sizeof(got3)))return false;
 const unsigned char sig4[]={0x48,0x8b,0x0d,0x65,0x9b,0x87,0x03,0xe8,0xd8,0x93,0x89,0x00,0x84,0xc0,0x0f,0x94,0xc2};
 unsigned char got4[sizeof(sig4)]={};
 if(!Read(base+0x5111fc,got4,sizeof(got4))||memcmp(got4,sig4,sizeof(got4)))return false;
 const unsigned char sig5[]={0x48,0x8b,0x0d,0xcd,0x5e,0x3c,0x03,0xe8,0x40,0x57,0x3e,0x00,0x84,0xc0,0x75,0x11};
 unsigned char got5[sizeof(sig5)]={};
 if(!Read(base+0x9c4e94,got5,sizeof(got5))||memcmp(got5,sig5,sizeof(got5)))return false;
 return true;
}
static bool ReadPlayerCombat(bool& inCombat){
 inCombat=false;
 if(!combatReaderVerified)return false;
 Ptr manager=0,state=0;unsigned char value=0;
 if(!ReadValue(base+0x3d8ad68,manager)||!Typed(manager,0x2bc7e30)||
    !ReadValue(manager+0x328,state)||!ReadValue(state+4,value)||value>1)return false;
 inCombat=value!=0;return true;
}
