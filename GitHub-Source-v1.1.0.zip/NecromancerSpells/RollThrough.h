#pragma once
// Narrow shape-query rejection, never disable actor/map/hit collision flags.
// HKS pulses only its ordinary rolling states; deactivation clears immediately.
static constexpr int RollPulse=8909030,RollStop=8909031;
static volatile LONG64 rollActor=0,rollDeadline=0;
static volatile LONG rollStarts=0,rollPasses=0;
static volatile LONG64 passActiveUntil=0;
static ApplyEffect originalRollApply=nullptr;
using BodyFilter=bool(*)(Ptr,int,Ptr,Ptr);
static BodyFilter originalRollFilter=nullptr;
static bool RollRead(Ptr a,void* d,size_t n){
 if(a<0x10000||n>4096||a>0x7fffffffffffULL-n)return false;
 SIZE_T got=0;return ReadProcessMemory(GetCurrentProcess(),(void*)a,d,n,&got)&&got==n;
}
template<class T>static bool RollValue(Ptr a,T& v){return RollRead(a,&v,sizeof(v));}
static bool RollLocalPlayer(Ptr actor){
 Ptr world=0,player=0,vt=0;
 return actor&&RollValue(base+0x3d6d018,world)&&world&&RollValue(world+0x1e508,player)&&player==actor&&RollValue(player,vt)&&vt==base+0x2a81cb0;
}
static uint64_t HookRollApply(Ptr chr,int id,bool flag){
 if(id!=RollPulse&&id!=RollStop)return originalRollApply(chr,id,flag);
 // Reserved messages are consumed, never create a persistent gameplay effect.
 if(!RollLocalPlayer(chr))return 0;
 if(id==RollStop){InterlockedExchange64(&rollDeadline,0);return 0;}
 InterlockedExchange64(&rollDeadline,LONG64(GetTickCount64()+150));
 LONG64 previous=InterlockedExchange64(&rollActor,LONG64(chr));
 if(!previous&&InterlockedIncrement(&rollStarts)<=6)Log("ROLL_BRIDGE start: movement input received");
 return 0;
}
static bool RollOwned(Ptr chr){
 uint64_t handle=0;Recipient r{};int model=0;
 if(!ReadValue(chr+8,handle)||!LookupRecipient(handle,chr,r)||!ReadValue(chr+0x64,model)||model==4960||model==8000||model==8002)return false;
 if(CurrentSpiritAsh(chr))return true;
 for(unsigned i=0;i<groupCount&&i<kAriseSummonLimit;++i)if(groupNPCs[i].origin==chr&&groupNPCs[i].handle==handle)return true;
 for(unsigned i=0;i<callCount&&i<6;++i)if(callNPCs[i].origin==chr&&callNPCs[i].handle==handle)return true;
 return false;
}
static bool RollCapsule(Ptr chr,unsigned& filter,unsigned& body){
 Ptr mods=0,phys=0,owner=0,proxy=0,hk=0,vt=0;
 return ReadValue(chr+0x190,mods)&&ReadValue(mods+0x68,phys)&&ReadValue(phys,vt)&&vt==base+0x2a3e890&&ReadValue(phys+8,owner)&&owner==chr&&
  ReadValue(phys+0x2e8,filter)&&ReadValue(phys+0x98,proxy)&&ReadValue(proxy,vt)&&vt==base+0x2b96bb0&&ReadValue(proxy+0x10,owner)&&owner==chr&&
  ReadValue(proxy+0x88,hk)&&ReadValue(hk+0x38,body)&&(body&0xffffff)!=0xffffff;
}
static bool PassQueryEligible(Ptr query,Ptr body,Ptr player){
 // Called under a non-blocking lock, only after vanilla allowed the query.
 Ptr world=0,current=0,queryOwner=0,holder=0,data=0,target=0;unsigned qfilter=0,bfilter=0,bid=0;unsigned short kind=0;
 if(epochInvalid||!ReadValue(base+0x3d6d018,world)||world!=worldNow||!ReadValue(world+0x1e508,current)||current!=player||current!=playerNow)return false;
 if(!ReadValue(query+8,queryOwner)||!queryOwner||!ReadValue(query+4,qfilter)||!ReadValue(body+0x70,bid)||!ReadValue(body+0x6c,bfilter)||
    !ReadValue(body+0xa0,holder)||!ReadValue(holder,data)||!ReadValue(data+8,kind)||kind!=2||!ReadValue(data+0x10,target)||!target||target==queryOwner)return false;
 Ptr minion=queryOwner==player?target:target==player?queryOwner:0;
 if(!minion||!RollOwned(minion))return false;
 unsigned qExpected=0,qBody=0,tExpected=0,tBody=0;
 if(!RollCapsule(queryOwner,qExpected,qBody)||!RollCapsule(target,tExpected,tBody)||tBody!=bid)return false;
 // Reject only capsule filter groups, not a weapon, projectile, ragdoll or ray with a different filter.
 if(qfilter!=qExpected||bfilter!=tExpected)return false;
 Ptr mods=0,pd=0,owner=0;int hp=0;
 return ReadValue(player+0x190,mods)&&ReadValue(mods,pd)&&ReadValue(pd+8,owner)&&owner==player&&ReadValue(pd+0x138,hp)&&hp>0;
}

struct PassWindow {Ptr minion=0,player=0;uint64_t handle=0,epoch=0;ULONGLONG start=0,last=0,until=0;necro::Position anchor{};};
static PassWindow passWindows[32]{};
static bool PassAlive(Ptr player){Ptr data=0;return !epochInvalid&&player==playerNow&&RollLocalPlayer(player)&&CurrentPlayerData(data);}
static bool PassState(Ptr minion,Ptr player,ULONGLONG now,bool contact){
 if(!PassAlive(player)||!RollOwned(minion))return false;
 uint64_t handle=0;if(!ReadValue(minion+8,handle))return false;
 PassWindow* slot=nullptr;
 for(auto& p:passWindows)if(p.minion==minion&&p.player==player&&p.handle==handle&&p.epoch==sessionEpoch){slot=&p;break;}
 if(slot&&now<slot->until)return true;
 if(!contact)return false;
 if(!slot){for(auto& p:passWindows)if(p.epoch!=sessionEpoch||now>p.last+4000){slot=&p;break;}if(!slot)return false;*slot={};slot->minion=minion;slot->player=player;slot->handle=handle;slot->epoch=sessionEpoch;}
 auto& p=*slot;necro::Position pos{},mp{};
 if(now>=ULONGLONG(InterlockedCompareExchange64(&rollDeadline,0,0))||!SacrificePosition(player,pos)||!SacrificePosition(minion,mp)||Distance2(pos,mp)>3.24f){p.start=0;p.last=now;return false;}
 // Actual physics contact plus sustained movement input and <25cm progress.
 if(!p.start||now>p.last+200||Distance2(pos,p.anchor)>.0625f){p.start=now;p.anchor=pos;}
 p.last=now;
 if(now-p.start<2000)return false;
 p.until=now+3000;p.start=0;
 InterlockedExchange64(&passActiveUntil,LONG64(p.until));
 if(InterlockedIncrement(&rollPasses)<=12)Log("MINION_PASS open=3s blocked=2s handle=%llx",(unsigned long long)handle);
 return true;
}
static bool HookRollFilter(Ptr filter,int queryType,Ptr query,Ptr body){
 bool result=originalRollFilter(filter,queryType,query,body);if(!result)return false;
 ULONGLONG now=GetTickCount64();if(now>=ULONGLONG(InterlockedCompareExchange64(&passActiveUntil,0,0)))return result;
 Ptr player=Ptr(InterlockedCompareExchange64(&rollActor,0,0));
 if(!player||!TryAcquireSRWLockExclusive(&spellLock))return result;
 bool reject=false;
 if(PassQueryEligible(query,body,player)){
  Ptr owner=0,holder=0,data=0,target=0;
  if(ReadValue(query+8,owner)&&ReadValue(body+0xa0,holder)&&ReadValue(holder,data)&&ReadValue(data+0x10,target))reject=PassState(owner==player?target:owner,player,now,false);
 }
 ReleaseSRWLockExclusive(&spellLock);return reject?false:result;
}
using ContactListener=void(*)(Ptr,Ptr,Ptr,Ptr);
static ContactListener originalPassContacts=nullptr;
using BodyUserData=Ptr(*)(unsigned);static BodyUserData passBodyData=nullptr;
static bool PassContactActor(unsigned bodyId,Ptr& actor){
 if((bodyId&0xffffff)==0xffffff||!passBodyData)return false;
 Ptr data=passBodyData(bodyId);unsigned short kind=0;unsigned filter=0,expected=0;
 return data&&ReadValue(data+8,kind)&&kind==2&&ReadValue(data+0x10,actor)&&actor&&RollCapsule(actor,filter,expected)&&expected==bodyId;
}
// c5ed50 consumes 64-byte contacts and edits matching 80-byte constraints.
// Compact only exact own-player/main-capsule constraints; preserve extra planes.
static unsigned passConstraintWrites=0;
static void FilterPassContacts(Ptr listener,Ptr contacts,Ptr output,ULONGLONG now){
 Ptr player=Ptr(InterlockedCompareExchange64(&rollActor,0,0)),owner=0,input=0,planes=0;int n=0,count=0;
 if(!player||!ReadValue(listener+0x18,owner))return;
 if(owner!=player){bool active=false;for(const auto& window:passWindows)if(window.minion==owner&&window.player==player&&window.epoch==sessionEpoch&&now<window.until){active=true;break;}if(!active)return;}
 if(!PassAlive(player)||
 !ReadValue(contacts,input)||!ReadValue(contacts+8,n)||n<=0||n>128||!ReadValue(output+0x48,planes)||!ReadValue(output+0x50,count)||count<n||count>160)return;
 bool skip[160]{};unsigned removed=0;
 for(int i=0;i<n;++i){unsigned id=0;Ptr target=0;
  if(!ReadValue(input+i*64+0x28,id)||!PassContactActor(id,target))continue;
  Ptr minion=owner==player?target:target==player?owner:0;
  if(minion&&PassState(minion,player,now,owner==player)){skip[i]=true;++removed;}
 }
 if(!removed)return;
 alignas(16) unsigned char packed[160*80];int keep=0;
 for(int i=0;i<count;++i)if(!skip[i]){if(!Read(planes+i*80,packed+keep*80,80))return;++keep;}
 if(Write(planes,packed,keep*80)&&Put<int>(output+0x50,keep)&&passConstraintWrites++<6)Log("MINION_PASS_CONSTRAINTS removed=%u",removed);
}
static void HookPassContacts(Ptr listener,Ptr proxy,Ptr contacts,Ptr output){
 originalPassContacts(listener,proxy,contacts,output);
 ULONGLONG now=GetTickCount64();
 if(now>=ULONGLONG(InterlockedCompareExchange64(&rollDeadline,0,0))&&now>=ULONGLONG(InterlockedCompareExchange64(&passActiveUntil,0,0)))return;
 if(!TryAcquireSRWLockExclusive(&spellLock))return;
 FilterPassContacts(listener,contacts,output,now);ReleaseSRWLockExclusive(&spellLock);
}

using PassBodyPair=bool(*)(Ptr,int,unsigned,unsigned);
using PassBodyBatch=int(*)(Ptr,Ptr,Ptr,int);
static PassBodyPair originalPassBodyPair=nullptr;
static PassBodyBatch originalPassBodyBatch=nullptr;
static unsigned passPairLogs=0,passBatchLogs=0,passConstraintLogs=0;
static bool PassBodyIds(unsigned a,unsigned b,ULONGLONG now){
 Ptr player=Ptr(InterlockedCompareExchange64(&rollActor,0,0)),ac=0,bc=0;
 if(!player||!PassAlive(player)||!PassContactActor(a,ac)||!PassContactActor(b,bc))return false;
 Ptr minion=ac==player?bc:bc==player?ac:0;
 return minion&&minion!=player&&PassState(minion,player,now,false);
}
static bool HookPassBodyPair(Ptr filter,int type,unsigned a,unsigned b){
 bool allowed=originalPassBodyPair(filter,type,a,b);ULONGLONG now=GetTickCount64();
 if(!allowed||now>=ULONGLONG(InterlockedCompareExchange64(&passActiveUntil,0,0))||!TryAcquireSRWLockExclusive(&spellLock))return allowed;
 bool skip=PassBodyIds(a,b,now);
 if(skip&&passPairLogs++<6)Log("MINION_PASS_BODY_PAIR rejected exact player/minion pair");
 ReleaseSRWLockExclusive(&spellLock);return skip?false:allowed;
}
static int HookPassBodyBatch(Ptr filter,Ptr world,Ptr pairs,int count){
 int n=originalPassBodyBatch(filter,world,pairs,count);ULONGLONG now=GetTickCount64();
 if(n<=0||n>count||n>4096||now>=ULONGLONG(InterlockedCompareExchange64(&passActiveUntil,0,0))||!TryAcquireSRWLockExclusive(&spellLock))return n;
 unsigned list[4096][2];int keep=0;
 if(!Read(pairs,list,size_t(n)*8)){ReleaseSRWLockExclusive(&spellLock);return n;}
 for(int i=0;i<n;++i)if(!PassBodyIds(list[i][0],list[i][1],now)){list[keep][0]=list[i][0];list[keep++][1]=list[i][1];}
 if(keep<n&&(keep==0||Write(pairs,list,size_t(keep)*8))){if(passBatchLogs++<6)Log("MINION_PASS_BODY_BATCH removed=%d",n-keep);n=keep;}
 ReleaseSRWLockExclusive(&spellLock);return n;
}
static bool ConfigureRollThrough(){
 static constexpr unsigned char filterBytes[]={0x48,0x89,0x5c,0x24,0x10,0x48,0x89,0x6c,0x24,0x18,0x48,0x89,0x74,0x24,0x20,0x57,0x48,0x83,0xec,0x20};
 static constexpr unsigned char contactBytes[]={0x4c,0x8b,0xdc,0x53,0x55,0x56,0x57,0x41,0x54,0x41,0x55,0x41,0x57};
 static constexpr unsigned char pairBytes[]={0x44,0x89,0x4c,0x24,0x20,0x44,0x89,0x44,0x24,0x18,0x41,0x56,0x48,0x83,0xec,0x30,0x41,0x8b,0xc0,0x4c};
 static constexpr unsigned char batchBytes[]={0x48,0x8b,0xc4,0x4c,0x89,0x40,0x18,0x48,0x89,0x50,0x10,0x48,0x89,0x48,0x8,0x56,0x41,0x55,0x41,0x56};
 unsigned char actual[32]{};
 if(!Read(base+0x3e8dc0,actual,sizeof(applySignature))||memcmp(actual,applySignature,sizeof(applySignature))||
 !Read(base+0xc636e0,actual,sizeof(filterBytes))||memcmp(actual,filterBytes,sizeof(filterBytes))||
 !Read(base+0xc637e0,actual,sizeof(pairBytes))||memcmp(actual,pairBytes,sizeof(pairBytes))||
 !Read(base+0xc63540,actual,sizeof(batchBytes))||memcmp(actual,batchBytes,sizeof(batchBytes))||
 !Read(base+0xc5ed50,actual,sizeof(contactBytes))||memcmp(actual,contactBytes,sizeof(contactBytes))){Log("MINION_PASS_DISABLED signature mismatch");return false;}
 passBodyData=(BodyUserData)(base+0xc68bc0);
 MH_STATUS s=MH_CreateHook((void*)(base+0x3e8dc0),(void*)&HookRollApply,(void**)&originalRollApply);
 if(s==MH_OK)s=MH_CreateHook((void*)(base+0xc636e0),(void*)&HookRollFilter,(void**)&originalRollFilter);
 if(s==MH_OK)s=MH_CreateHook((void*)(base+0xc5ed50),(void*)&HookPassContacts,(void**)&originalPassContacts);
 if(s==MH_OK)s=MH_CreateHook((void*)(base+0xc637e0),(void*)&HookPassBodyPair,(void**)&originalPassBodyPair);
 if(s==MH_OK)s=MH_CreateHook((void*)(base+0xc63540),(void*)&HookPassBodyBatch,(void**)&originalPassBodyBatch);
 if(s==MH_OK)s=MH_EnableHook((void*)(base+0x3e8dc0));
 if(s==MH_OK)s=MH_EnableHook((void*)(base+0xc636e0));
 if(s==MH_OK)s=MH_EnableHook((void*)(base+0xc5ed50));
 if(s==MH_OK)s=MH_EnableHook((void*)(base+0xc637e0));
 if(s==MH_OK)s=MH_EnableHook((void*)(base+0xc63540));
 Log("MINION_PASS_CONFIG v15 status=%d; body-pair and batch filters added; sustained2s contact/input/stall,3s exact pair; in-game verification required",int(s));return s==MH_OK;
}



