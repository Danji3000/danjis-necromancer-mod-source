#pragma once
// Verified native spell-cost query and post-spawn cost application. Queries never
// sacrifice. 3c0e70 is called only after successful dispatch and reads its context
// synchronously (0..cc). Its b8 field is the already modified, negative FP cost.
static constexpr int SalvoSpell=5094,SalvoStartBullet=18910013,SalvoLoopBullet=18910011;
using SalvoCost=int(*)(Ptr,Ptr,unsigned char);
using SalvoConsume=void(*)(Ptr);
static SalvoCost originalSalvoCost=nullptr;
static SalvoConsume originalSalvoConsume=nullptr;
static bool salvoReady=false;
struct SalvoCredit {uint64_t epoch=0;Ptr player=0,world=0;double start=0,until=0;};
static SalvoCredit salvoCredit{};
static unsigned salvoReports=0;
static constexpr int SalvoSoulBullet=18932100;
static constexpr int HealingSoulBullet=18932600;
static constexpr int PaymentSoulBullet=18933100;
// Stationary visual carriers:256 half-metre arc lengths, endpoint error<=25cm.
static int SalvoSoulVariant(float distance){if(!std::isfinite(distance)||distance<.05f||distance>128.f)return -1;int v=int(distance*2.f+.5f)-1;return v<0?0:v>255?255:v;}
struct SalvoSoul {bool active=false;uint64_t epoch=0;necro::Position position{};};
static bool SalvoSoulVisual(const SalvoSoul& soul,necro::Position* destination=nullptr,bool payment=false){
 if(!soul.active||!constructSacrificeInput||!originalSacrificeSpawn)return false;
 Ptr manager=0;uint64_t player=0;necro::Position end{};
 {SpellLock guard;Ptr data=0;
  if(soul.epoch!=sessionEpoch||!CurrentPlayerData(data)||!SacrificePosition(playerNow,end)||!ReadValue(playerNow+8,player)||!ReadValue(base+0x3d697c8,manager)||!manager)return false;
 }
 necro::Position origin=soul.position;
 // Healing souls must also arrive when the two actors overlap. Use a short
 // visible approach rather than losing the heal or granting it immediately.
 if((destination||payment)&&Distance2(origin,end)<.0025f)origin.x-=.5f;
 float dx=end.x-origin.x,dy=end.y-origin.y,dz=end.z-origin.z;
 if(destination){float span=std::sqrt(dx*dx+dy*dy+dz*dz);if(span>128.f){float q=127.5f/span;end={origin.x+dx*q,origin.y+dy*q,origin.z+dz*q};dx*=q;dy*=q;dz*=q;}}
 float length=std::sqrt(dx*dx+dy*dy+dz*dz);int variant=SalvoSoulVariant(length);if(variant<0)return false;
 float fx=dx/length,fy=dy/length,fz=dz/length;
 float horizontal=std::sqrt(fx*fx+fz*fz),rx=1,rz=0;
 if(horizontal>.001f){rx=fz/horizontal;rz=-fx/horizontal;}
 float transform[16]={rx,0,rz,0,-rz*fy,rz*fx-rx*fz,rx*fy,0,fx,fy,fz,0,origin.x,origin.y+1.f,origin.z,1};
 // right cross forward gives the opposite up: use forward cross right.
 transform[4]=fy*rz;transform[5]=fz*rx-fx*rz;transform[6]=-fy*rx;
 alignas(16) unsigned char input[0x110]{};constructSacrificeInput(input);
 const int spell=-1,bullet=(payment?PaymentSoulBullet:destination?HealingSoulBullet:SalvoSoulBullet)+variant;const uint64_t noTarget=~uint64_t(0);unsigned flags=0;
 memcpy(input,&player,8);memcpy(input+0xc,&spell,4);memcpy(input+0x14,&bullet,4);memcpy(input+0x20,&noTarget,8);
 memcpy(input+0x50,transform,sizeof(transform));memcpy(&flags,input+0x44,4);flags&=~8u;memcpy(input+0x44,&flags,4);
 int result=-1,error=0;originalSacrificeSpawn(manager,&result,input,&error);
 if(salvoReports++<120)Log("SALVO_SOUL arc_one_soul=1 spawn=%d error=%d player=%llx distance=%.2f variant=%d",result,error,(unsigned long long)player,length,variant);
 if(result!=-1&&destination)*destination=end;
 return result!=-1;
}
static bool SalvoLive(){
 Ptr data=0;
 if(!salvoReady||!enhancementReady||!originalSetHP||epochInvalid||!std::isfinite(spellTime)||!CurrentPlayerData(data)){
  salvoCredit={};return false;
 }
 if(salvoCredit.epoch!=sessionEpoch||salvoCredit.player!=playerNow||salvoCredit.world!=worldNow||spellTime<salvoCredit.start)salvoCredit={};
 return true;
}
static bool SalvoPaid(){return salvoCredit.epoch==sessionEpoch&&salvoCredit.player==playerNow&&salvoCredit.world==worldNow&&spellTime>=salvoCredit.start&&spellTime<salvoCredit.until;}
// Caller holds SpellLock. Only existing owned rosters are inspected; no global scan.
static bool SalvoCanPay(unsigned mode){
 if(mode>1||!SalvoLive())return false;
 if(mode==1&&SalvoPaid())return true;
 Recipient victim{};necro::Position p{};return ChooseSacrifice(0,victim,p);
}
static int SalvoPay(unsigned mode,int normalCost,SalvoSoul* soul=nullptr){
 if(mode>1||normalCost<=0||!SalvoLive())return normalCost;
 if(mode==0)salvoCredit={}; // A new cast cannot inherit an interrupted cast's credit.
 else if(SalvoPaid())return 0;
 Recipient chosen{},fresh{};necro::Position p{};
 if(!ChooseSacrifice(0,chosen,p)||!LookupRecipient(chosen.actor.id.handle,chosen.chr,fresh)||SacrificeReserved(fresh.actor.id.handle)||SacrificeTier(fresh)<0){
  if(salvoReports++<120)Log("SALVO_FP mode=%u normal=%d time=%.3f",mode,normalCost,spellTime);
  return normalCost;
 }
 const int collapse=SacrificeRevival(fresh);if(collapse<0)return normalCost;
 originalSetHP(fresh.data,collapse,0,0.f,1.f,1);
 int after=-1;
 if(!ReadValue(fresh.data+0x138,after)||after!=collapse){
  if(salvoReports++<120)Log("SALVO_ABORT collapse_failed handle=%llx",(unsigned long long)fresh.actor.id.handle);
  return normalCost;
 }
 salvoCredit={sessionEpoch,playerNow,worldNow,spellTime,spellTime+2.0};
 if(soul)*soul={true,sessionEpoch,p};
 if(salvoReports++<120)Log("SALVO_SACRIFICE mode=%u handle=%llx revival=%d saved_fp=%d time=%.3f paid_until=%.3f",mode,(unsigned long long)fresh.actor.id.handle,collapse,normalCost,spellTime,salvoCredit.until);
 return 0;
}
// Menu costs use PlayerGameData's private effect-manager copy, not ChrIns's
// live manager. Accept only the exact local menu copy, and only for UI or
// read-only availability callers. Never accept it on either payment path.
static bool SalvoMenuEffects(Ptr effects){
 Ptr manager=0,playerData=0,menuEffects=0;
 return effects&&ReadValue(base+0x3d64fb8,manager)&&manager&&ReadValue(manager+8,playerData)&&playerData&&ReadValue(playerData+0xa80,menuEffects)&&menuEffects==effects;
}
#include "NecroPayment.h"
static int SalvoQuote(Ptr wrapper,Ptr effects,unsigned mode,int cost,Ptr site){
 int selected=-1;if(ReadValue(wrapper,selected)&&NecroSpell(selected))return NecroQuote(wrapper,effects,mode,cost,site);
 // 690cd6: read-only availability. 685c2b: 685c00 called by390670,
 // from the sustained projectile update3930b0. That path checks/deducts FP
 // before continuing projectile emission, independently of3c0e70.
 const bool sustain=site==0x685c2b&&mode==1;
 const bool display=site==0x847e33||site==0x8480ec||site==0x872c11;
 if((site!=0x690cd6&&!display&&!sustain)||mode>1)return cost;
 int magic=-1,start=-1,loop=-1;Ptr row=0,owner=0,currentEffects=0;
 if(!ReadValue(wrapper,magic)||magic!=SalvoSpell||!ReadValue(wrapper+8,row)||!row||!ReadValue(row+0x78,start)||start!=SalvoStartBullet||!ReadValue(row+0x6c,loop)||loop!=SalvoLoopBullet)return cost;
 SalvoSoul soul{};int result=cost;
 {
  SpellLock guard;
  bool live=ReadValue(effects+0x10,owner)&&owner==playerNow&&ReadValue(playerNow+0x178,currentEffects)&&currentEffects==effects;
  bool menu=(display||site==0x690cd6)&&SalvoMenuEffects(effects);
  if(!live&&!menu)return cost;
  if(sustain)result=SalvoPay(1,cost,&soul);
  else result=SalvoCanPay(mode)?0:cost;
  if(display||site==0x690cd6){static int previous[4]={-1,-1,-1,-1};static unsigned reports=0;unsigned index=site==0x847e33?0:site==0x8480ec?1:site==0x872c11?2:3;int state=(menu?2:0)|(result==0?1:0);if(previous[index]!=state&&reports<24){previous[index]=state;++reports;Log("SALVO_HUD site=%llx menu_copy=%d cost=%d result=%d",(unsigned long long)site,int(menu),cost,result);}}
 }
 // A native spawn may reenter other game hooks. Never hold SpellLock here.
 SalvoSoulVisual(soul);return result;
}
static int HookSalvoCost(Ptr wrapper,Ptr effects,unsigned char mode){
 Ptr site=(Ptr)__builtin_return_address(0)-base;
 int cost=originalSalvoCost(wrapper,effects,mode);
 return SalvoQuote(wrapper,effects,mode,cost,site);
}
static void HookSalvoConsume(Ptr context){
 if(NecroConsume(context))return;
 Ptr caster=0;int magic=-1,bullet=-1,delta=0;unsigned char category=0;
 if(!ReadValue(context,caster)||caster!=playerNow||!ReadValue(context+0xc,magic)||magic!=SalvoSpell||!ReadValue(context+0x14,category)||category!=1||!ReadValue(context+0x18,bullet)||!ReadValue(context+0xb8,delta)||delta>=0||delta==INT32_MIN||(bullet!=SalvoStartBullet&&bullet!=SalvoLoopBullet)){
  originalSalvoConsume(context);return;
 }
 alignas(16) unsigned char local[0xd0];
 if(!Read(context,local,sizeof(local))){originalSalvoConsume(context);return;}
 int cost=-delta;SalvoSoul soul{};
 {SpellLock guard;cost=SalvoPay(bullet==SalvoStartBullet?0:1,cost,&soul);}
 if(cost==-delta){originalSalvoConsume(context);return;}
 // Keep HP, stamina, durability and every other native cost intact. Never write FP,
 // refund FP, invoke the explosion path, or modify the caller's context.
 delta=-cost;memcpy(local+0xb8,&delta,4);originalSalvoConsume((Ptr)local);SalvoSoulVisual(soul);
}
static bool ConfigureSalvoPayment(){
 const unsigned char costSig[]={0x48,0x89,0x5c,0x24,0x08,0x48,0x89,0x74,0x24,0x10,0x57,0x48,0x83,0xec,0x20,0x48,0x8b,0xf2};
 const unsigned char consumeSig[]={0x40,0x53,0x48,0x83,0xec,0x50,0x48,0x8b,0x01,0x48,0x8b,0xd9};
 unsigned char bytes[sizeof(costSig)];
 if(!Read(base+0x685c40,bytes,sizeof(costSig))||memcmp(bytes,costSig,sizeof(costSig))||!Read(base+0x3c0e70,bytes,sizeof(consumeSig))||memcmp(bytes,consumeSig,sizeof(consumeSig))){Log("SALVO_PAYMENT disabled_signature normal_fp_preserved=1");return false;}
 MH_STATUS a=MH_CreateHook((void*)(base+0x685c40),(void*)&HookSalvoCost,(void**)&originalSalvoCost);
 MH_STATUS b=MH_CreateHook((void*)(base+0x3c0e70),(void*)&HookSalvoConsume,(void**)&originalSalvoConsume);
 if(a==MH_OK&&b==MH_OK){
  b=MH_EnableHook((void*)(base+0x3c0e70));
  if(b==MH_OK){salvoReady=true;a=MH_EnableHook((void*)(base+0x685c40));}
 }
 if(a!=MH_OK||b!=MH_OK){salvoReady=false;MH_DisableHook((void*)(base+0x3c0e70));MH_DisableHook((void*)(base+0x685c40));}
 Log("SALVO_PAYMENT enabled=%d cost_hook=%d consume_hook=%d seconds_per_sacrifice=2",int(salvoReady),int(a),int(b));return salvoReady;
}
