#pragma once
// Five points in a 2.5m ring. No teleport, no new engine calls.
// The caller validates that the player is grounded. Adjacent terrain must still be game-tested.
static necro::Position CompactSpawn(const necro::Observation&o,unsigned slot,unsigned count){
 necro::Position p=o.position;
 if(count==2||count==3){
  if(slot>=count)return p;
  const float length2=o.forwardX*o.forwardX+o.forwardZ*o.forwardZ;
  if(!std::isfinite(length2)||length2<.8f||length2>1.2f)return p;
  const float inv=1.f/std::sqrt(length2),fx=o.forwardX*inv,fz=o.forwardZ*inv;
  constexpr float side2[2]={-1.5f,1.5f},ahead2[2]={2.f,2.f};
  constexpr float side3[3]={0.f,2.1650635f,-2.1650635f},ahead3[3]={2.5f,-1.25f,-1.25f};
  const float side=count==2?side2[slot]:side3[slot],ahead=count==2?ahead2[slot]:ahead3[slot];
  p.x+=fz*side+fx*ahead;p.z+=-fx*side+fz*ahead;return p;
 }
 if(count!=5||slot>=5)return p;
 const float length2=o.forwardX*o.forwardX+o.forwardZ*o.forwardZ;
 if(!std::isfinite(length2)||length2<.8f||length2>1.2f)return p;
 constexpr float side[5]={0.f,.855951f,.529007f,-.529007f,-.855951f};
 constexpr float ahead[5]={.9f,.278115f,-.728115f,-.728115f,.278115f};
 const float inv=1.f/std::sqrt(length2),fx=o.forwardX*inv,fz=o.forwardZ*inv;
 constexpr float radiusScale=2.5f/.9f;
 p.x+=radiusScale*(fz*side[slot]+fx*ahead[slot]);p.z+=radiusScale*(-fx*side[slot]+fz*ahead[slot]);
 return p;
}
