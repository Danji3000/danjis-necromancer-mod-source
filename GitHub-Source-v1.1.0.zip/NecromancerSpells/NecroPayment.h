#pragma once
struct NecroReference {int magic,category,id;};
static constexpr NecroReference necroReferences[]={
 {5070,2,1507000},{5080,1,18902000},{5080,1,18902050},
 {5090,1,18910015},{5090,1,18910019},{5091,1,18910000},
 {5092,1,18910002},{5092,1,18910003},{5093,1,18910005},{5093,1,18910007},
 {5095,1,18930000},{5096,2,8909001},{5097,1,18931000}};
static bool NecroSpell(int magic){for(const auto& r:necroReferences)if(r.magic==magic)return true;return false;}
static bool NecroReferenceMatches(int magic,int category,int ref){for(const auto& r:necroReferences)if(r.magic==magic&&r.category==category&&r.id==ref)return true;return false;}
static bool NecroPlayerFP(int& fp){Ptr data=0;int maximum=0;return SalvoLive()&&CurrentPlayerData(data)&&ReadValue(data+0x148,fp)&&ReadValue(data+0x14c,maximum)&&fp>=0&&fp<=maximum;}
static bool NecroCandidate(){Recipient victim{};necro::Position pos{};return ChooseSacrifice(0,victim,pos);}
struct SacrificeReceipt {uint64_t epoch=0;Ptr player=0,world=0;double time=-100;bool unused=false;};
static SacrificeReceipt sacrificeReceipt{};
// Called only after a real Created-to-Die victim is collapsed or reserved.
static void NoteSacrificePayment(){sacrificeReceipt={sessionEpoch,playerNow,worldNow,spellTime,true};}
static bool NecroReceipt(){return sacrificeReceipt.unused&&sacrificeReceipt.epoch==sessionEpoch&&sacrificeReceipt.player==playerNow&&sacrificeReceipt.world==worldNow&&spellTime>=sacrificeReceipt.time&&spellTime-sacrificeReceipt.time<.1;}
static int NecroQuote(Ptr wrapper,Ptr effects,unsigned mode,int cost,Ptr site){
 if(cost<=0||mode>1||(site!=0x690cd6&&site!=0x847e33&&site!=0x8480ec&&site!=0x872c11))return cost;
 int magic=-1,first=-1;Ptr row=0;
 if(!ReadValue(wrapper,magic)||!NecroSpell(magic)||!ReadValue(wrapper+8,row)||!row||!ReadValue(row+0x68,first))return cost;
 bool known=false;for(const auto& r:necroReferences)if(r.magic==magic&&r.id==first)known=true;if(!known)return cost;
 SpellLock guard;int fp=0;Ptr owner=0,current=0;
 bool live=ReadValue(effects+0x10,owner)&&owner==playerNow&&ReadValue(playerNow+0x178,current)&&current==effects;
 if((!live&&!SalvoMenuEffects(effects))||!NecroPlayerFP(fp)||fp>=cost)return cost;
 return NecroCandidate()?0:cost;
}
static bool NecroConsume(Ptr context){
 Ptr caster=0;int magic=-1,ref=-1,delta=0;unsigned char category=0;
 if(!ReadValue(context,caster)||caster!=playerNow||!ReadValue(context+0xc,magic)||!NecroSpell(magic)||!ReadValue(context+0x14,category)||!ReadValue(context+0x18,ref)||!NecroReferenceMatches(magic,category,ref)||!ReadValue(context+0xb8,delta)||delta>=0||delta==INT32_MIN)return false;
 alignas(16) unsigned char local[0xd0]{};if(!Read(context,local,sizeof(local)))return false;
 SalvoSoul soul{};bool paid=false;
 {
  SpellLock guard;int fp=0;if(!NecroPlayerFP(fp))return false;
  bool receipt=magic==SacrificeSpell&&NecroReceipt();
  if(magic==SacrificeSpell)sacrificeReceipt.unused=false;
  if(fp>=-delta)return false;
  if(magic==SacrificeSpell)paid=receipt;
  else{
   Recipient victim{},fresh{};necro::Position pos{};
   if(ChooseSacrifice(0,victim,pos)&&LookupRecipient(victim.actor.id.handle,victim.chr,fresh)&&!SacrificeReserved(fresh.actor.id.handle)&&SacrificeTier(fresh)>=0){
    int collapse=SacrificeRevival(fresh),after=-1;
    if(collapse>=0){originalSetHP(fresh.data,collapse,0,0.f,1.f,1);paid=ReadValue(fresh.data+0x138,after)&&after==collapse;if(paid)soul={true,sessionEpoch,pos};}
   }
  }
  if(paid){static unsigned reports=0;if(reports++<80)Log("NECRO_PAYMENT spell=%d normal_fp=%d remaining_fp=%d one_sacrifice=1 existing_created_to_die=%d",magic,-delta,fp,int(magic==SacrificeSpell));}
 }
 if(!paid)return false;
 int zero=0;memcpy(local+0xb8,&zero,4);originalSalvoConsume((Ptr)local);SalvoSoulVisual(soul,nullptr,true);return true;
}
