#pragma once
// Full upgrade progression. Level is captured once at animation impact.
namespace necro {
inline bool IsCallStaff(int id){return id>=33800000&&id<=33800025;}
inline bool IsSummonStaff(int id){return IsCallStaff(id)||(id>=33990000&&id<=33990025);}
inline int SummonStaffForCast(int left,int right,unsigned style){
 if(style==2)return IsSummonStaff(left)?left:-1;
 if(style==3||style==0||style==1)return IsSummonStaff(right)?right:-1;
 return -1;
}
inline Candidate CallCandidate(int level){return {3500,89091000+level,8905160,false,level>=0&&level<=25};}
inline bool IsCallIdentity(int model,int npc){return model==3500&&npc>=89091000&&npc<=89091025;}
inline bool IsStaff(int id){return id>=33990000&&id<=33990025;}
inline int StaffForCast(int left,int right,unsigned style){
 if(style==2)return IsStaff(left)?left:-1;
 if(style==3||style==0||style==1)return IsStaff(right)?right:-1;
 return -1;
}
constexpr Candidate sword0{3510,89070000,8905110,false,true};
constexpr Candidate sword1{3510,89070010,8905110,false,true};
constexpr Candidate sword2{3510,89070020,8905110,false,true};
constexpr Candidate sword3{3510,89070030,8905110,false,true};
constexpr Candidate sword4{3510,89070040,8905110,false,true};
constexpr Candidate sword5{3510,89070050,8905110,false,true};
constexpr Candidate sword6{3510,89070060,8905110,false,true};
constexpr Candidate shield7{3510,89070071,8905100,false,true};
constexpr Candidate shield8{3510,89070081,8905100,false,true};
constexpr Candidate shield9{3510,89070091,8905100,false,true};
constexpr Candidate spear10{3500,89070102,8905120,false,true};
constexpr Candidate bow10{3510,89070103,8905130,false,true};
constexpr Candidate spear11{3500,89070112,8905120,false,true};
constexpr Candidate bow11{3510,89070113,8905130,false,true};
constexpr Candidate spear12{3500,89070122,8905120,false,true};
constexpr Candidate bow12{3510,89070123,8905130,false,true};
constexpr Candidate dual13{3500,89070134,8905160,false,true};
constexpr Candidate spear13{3500,89070132,8905120,false,true};
constexpr Candidate bow13{3510,89070133,8905130,false,true};
constexpr Candidate dual14{3500,89070144,8905160,false,true};
constexpr Candidate spear14{3500,89070142,8905120,false,true};
constexpr Candidate bow14{3510,89070143,8905130,false,true};
constexpr Candidate dual15{3500,89070154,8905160,false,true};
constexpr Candidate spear15{3500,89070152,8905120,false,true};
constexpr Candidate bow15{3510,89070153,8905130,false,true};
constexpr Candidate dual16{3500,89070164,8905160,false,true};
constexpr Candidate heavy16{3500,89070165,8905140,false,true};
constexpr Candidate bow16{3510,89070163,8905130,false,true};
constexpr Candidate dual17{3500,89070174,8905160,false,true};
constexpr Candidate heavy17{3500,89070175,8905140,false,true};
constexpr Candidate bow17{3510,89070173,8905130,false,true};
constexpr Candidate dual18{3500,89070184,8905160,false,true};
constexpr Candidate heavy18{3500,89070185,8905140,false,true};
constexpr Candidate bow18{3510,89070183,8905130,false,true};
constexpr Candidate shield19{3510,89070191,8905100,false,true};
constexpr Candidate heavy19{3500,89070195,8905140,false,true};
constexpr Candidate bow19{3510,89070193,8905130,false,true};
constexpr Candidate shield20{3510,89070201,8905100,false,true};
constexpr Candidate heavy20{3500,89070205,8905140,false,true};
constexpr Candidate bow20{3510,89070203,8905130,false,true};
constexpr Candidate shield21{3510,89070211,8905100,false,true};
constexpr Candidate heavy21{3500,89070215,8905140,false,true};
constexpr Candidate bow21{3510,89070213,8905130,false,true};
constexpr Candidate shield22{3510,89070221,8905100,false,true};
constexpr Candidate heavy22{3500,89070225,8905140,false,true};
constexpr Candidate bow22{3510,89070223,8905130,false,true};
constexpr Candidate shield23{3510,89070231,8905100,false,true};
constexpr Candidate heavy23{3500,89070235,8905140,false,true};
constexpr Candidate bow23{3510,89070233,8905130,false,true};
constexpr Candidate shield24{3510,89070241,8905100,false,true};
constexpr Candidate heavy24{3500,89070245,8905140,false,true};
constexpr Candidate bow24{3510,89070243,8905130,false,true};
constexpr Candidate shield25{3510,89070251,8905100,false,true};
constexpr Candidate mage25{3500,89070256,8905150,false,true};
constexpr Candidate heavy25{3500,89070255,8905140,false,true};
constexpr Candidate axe22{3060,89070227,8905170,false,true};
constexpr Candidate mage22{3500,89070226,8905150,false,true};
constexpr Candidate axe23{3060,89070237,8905170,false,true};
constexpr Candidate mage23{3500,89070236,8905150,false,true};
constexpr Candidate axe24{3060,89070247,8905170,false,true};
constexpr Candidate mage24{3500,89070246,8905150,false,true};
constexpr Candidate axe25{3060,89070257,8905170,false,true};
constexpr Candidate colossus{4960,89090000,89090000,false,true};
constexpr Candidate balanceCandidates[]={colossus,skeleton,sword0,sword1,sword2,sword3,sword4,sword5,sword6,shield7,shield8,shield9,spear10,bow10,spear11,bow11,spear12,bow12,dual13,spear13,bow13,dual14,spear14,bow14,dual15,spear15,bow15,dual16,heavy16,bow16,dual17,heavy17,bow17,dual18,heavy18,bow18,shield19,heavy19,bow19,shield20,heavy20,bow20,shield21,heavy21,bow21,shield22,heavy22,bow22,shield23,heavy23,bow23,shield24,heavy24,bow24,shield25,mage25,heavy25,axe22,mage22,axe23,mage23,axe24,mage24,axe25};
inline bool ApprovedIdentity(int model,int npc){
 if(IsCallIdentity(model,npc))return true;
 for(const auto& c:balanceCandidates)if(c.model==model&&c.npc==npc)return true;
 return false;
}
inline bool ApprovedCandidate(const Candidate& c){
 if(c.boss||!c.approved)return false;
 if(IsCallIdentity(c.model,c.npc)&&c.think==8905160)return true;
 for(const auto& allowed:balanceCandidates)
  if(c.model==allowed.model&&c.npc==allowed.npc&&c.think==allowed.think)return true;
 return false;
}
inline Candidate CandidateForCast(int upgrade,unsigned slot){
 if(upgrade<0||upgrade>25||slot>=5)return skeleton;
 constexpr Candidate levels[26][5]={
{sword0,sword0,sword0,sword0,sword0},
{sword1,sword1,sword1,sword1,sword1},
{sword2,sword2,sword2,sword2,sword2},
{sword3,sword3,sword3,sword3,sword3},
{sword4,sword4,sword4,sword4,sword4},
{sword5,sword5,sword5,sword5,sword5},
{sword6,sword6,sword6,sword6,sword6},
{shield7,shield7,shield7,shield7,shield7},
{shield8,shield8,shield8,shield8,shield8},
{shield9,shield9,shield9,shield9,shield9},
{spear10,spear10,spear10,spear10,bow10},
{spear11,spear11,spear11,spear11,bow11},
{spear12,spear12,spear12,spear12,bow12},
{dual13,dual13,dual13,spear13,bow13},
{dual14,dual14,dual14,spear14,bow14},
{dual15,dual15,dual15,spear15,bow15},
{dual16,dual16,dual16,heavy16,bow16},
{dual17,dual17,dual17,heavy17,bow17},
{dual18,dual18,dual18,heavy18,bow18},
{shield19,shield19,shield19,heavy19,bow19},
{shield20,shield20,shield20,heavy20,bow20},
{shield21,shield21,shield21,heavy21,bow21},
{axe22,mage22,mage22,mage22,mage22},
{axe23,mage23,mage23,mage23,mage23},
{axe24,mage24,mage24,mage24,mage24},
{axe25,axe25,mage25,mage25,mage25},
 };return levels[upgrade][slot];
}
}
