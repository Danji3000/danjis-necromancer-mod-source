#pragma once
#include <stdint.h>
#include <cmath>
// Engine-independent policy. NOT a game hook: caller must bind verified engine
// hit interception, summon ownership, state-speed and lifecycle operations.
namespace necro_spells {
constexpr unsigned MaxRecipients=128;
constexpr double CovenantSeconds=60.0,ColossusSeconds=30.0;
constexpr unsigned ColossusLimit=2;
enum class Origin { Combat, Redirected, Other };
struct Identity {uint64_t handle=0,epoch=0;bool operator==(const Identity&b)const{return handle==b.handle&&epoch==b.epoch;}};
struct Actor {
 Identity id; bool loaded=false,summoned=false,friendly=false,isCaster=false;
 int64_t hp=0;bool Eligible()const{return id.handle&&loaded&&summoned&&friendly&&!isCaster&&hp>0;}
};
struct Portion {Identity target;int64_t damage=0;};
struct Split {int64_t player=0;unsigned count=0;Portion ally[MaxRecipients]{};};
struct Covenant {
 double until=0;uint64_t epoch=0;unsigned quarterCarry=0,recipientCursor=0,depth=0;
 bool Cast(double now,uint64_t world){if(!std::isfinite(now)||now<0||!world)return false;until=now+CovenantSeconds;epoch=world;return true;}
 bool Active(double now,uint64_t world)const{return std::isfinite(now)&&now>=0&&now<until&&world==epoch;}
 void Clear(){*this=Covenant{};}
 // Called on the engine's serial damage phase with a freshly validated snapshot.
 // No HP writes. Caller commits all portions within the same damage transaction.
 Split Plan(int64_t damage,Origin origin,double now,uint64_t world,const Actor*actors,unsigned count){
  Split result{};result.player=damage;
  if(damage<=0||origin!=Origin::Combat||depth||!Active(now,world)||count>MaxRecipients||(!actors&&count))return result;
  for(unsigned i=0;i<count;++i){
   const Actor&a=actors[i];if(!a.Eligible()||a.id.epoch!=world)continue;
   bool duplicate=false;for(unsigned j=0;j<result.count;++j)if(result.ally[j].target==a.id)duplicate=true;
   if(!duplicate)result.ally[result.count++].target=a.id;
  }
  if(!result.count)return result;
  // Preserve fractional quarters across hits; never create HP loss by rounding.
  int64_t pool=damage/4;unsigned rem=unsigned(damage%4)+quarterCarry;
  pool+=rem/4;quarterCarry=rem%4;result.player=damage-pool;
  const int64_t each=pool/result.count;const unsigned extra=unsigned(pool%result.count);
  for(unsigned j=0;j<result.count;++j)result.ally[j].damage=each;
  for(unsigned j=0;j<extra;++j)++result.ally[(recipientCursor+j)%result.count].damage;
  recipientCursor=(recipientCursor+extra)%result.count;return result;
 }
 bool SpeedAllowed(const Actor&a,double now,uint64_t world,bool attackingOrCasting)const{
  return Active(now,world)&&a.id.epoch==world&&a.Eligible()&&attackingOrCasting;
 }
};
struct RedirectGuard {Covenant&c;explicit RedirectGuard(Covenant&state):c(state){++c.depth;}~RedirectGuard(){--c.depth;}RedirectGuard(const RedirectGuard&)=delete;};
struct Giant {Identity id;double expires=0;uint64_t order=0;};
struct Giants {
 Giant slots[ColossusLimit]{};uint64_t sequence=0;
 unsigned Count()const{unsigned n=0;for(const auto&g:slots)if(g.id.handle)++n;return n;}
 Identity Oldest()const{const Giant*o=nullptr;for(const auto&g:slots)if(g.id.handle&&(!o||g.order<o->order))o=&g;return o?o->id:Identity{};}
 bool Capture(Identity id,double now){
  if(!id.handle||!id.epoch||!std::isfinite(now)||now<0)return false;
  for(const auto&g:slots)if(g.id==id)return false;
  for(auto&g:slots)if(!g.id.handle){g={id,now+ColossusSeconds,++sequence};return true;}
  return false; // Must successfully retire oldest BEFORE requesting a third spawn.
 }
 bool Due(Identity id,double now)const{for(const auto&g:slots)if(g.id==id)return std::isfinite(now)&&now>=g.expires;return false;}
 void ConfirmGone(Identity id){for(auto&g:slots)if(g.id==id)g=Giant{};}
 void WorldChanged(uint64_t world){for(auto&g:slots)if(g.id.epoch!=world)g=Giant{};}
};
}
