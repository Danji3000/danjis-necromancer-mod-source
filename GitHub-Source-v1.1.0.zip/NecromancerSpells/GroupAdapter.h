// Integrated group adapter. Reuses the confirmed v7 spawn/follow and v6 retirement primitives.
static bool CallHasOwnedOrPending();
static bool BeginCallCast(const necro::Observation&,bool);
struct GroupNPC {uint64_t handle=0;Ptr origin=0;CombatGate combat{};float missing=0;};
static constexpr unsigned kAriseSummonLimit=10;
static GroupNPC groupNPCs[kAriseSummonLimit];static unsigned groupCount=0,castRemaining=0,replaceRemaining=0,groupCastSize=0;
static bool groupSpawnPending=false,groupBlocked=false,groupManualRetire=false;
static float groupSpawnWait=0;static uint64_t groupCastEpoch=0;
static int groupUpgrade=-1;static necro::Candidate pendingCandidate=necro::skeleton;
static void SelectGroupNPC(unsigned i){npcHandle=groupNPCs[i].handle;npcOrigin=groupNPCs[i].origin;}
static void EraseGroupNPC(unsigned i){for(unsigned j=i+1;j<groupCount;++j)groupNPCs[j-1]=groupNPCs[j];groupNPCs[--groupCount]=GroupNPC{};}
static bool PayAriseCost(){
 Ptr mods=0,data=0;int fp=0,stamina=0,maxFP=0,maxStamina=0;
 if(!ReadValue(playerNow+0x190,mods)||!ReadValue(mods,data)||!data||!ReadValue(data+0x148,fp)||!ReadValue(data+0x14c,maxFP)||!ReadValue(data+0x154,stamina)||!ReadValue(data+0x158,maxStamina))return false;
 if(fp<50||fp>maxFP||stamina<30||stamina>maxStamina)return false;
 if(!Put<int>(data+0x148,fp-50))return false;
 if(!Put<int>(data+0x154,stamina-30)){Put<int>(data+0x148,fp);return false;}
 return true;
}
static bool BeginGroupCast(const necro::Observation&o,bool debug){
 if(callBusy||giantBusy||groupBlocked||epochInvalid||groupSpawnPending||castRemaining||groupManualRetire||!o.playerReady||!o.staffSelected||!o.onGround||!o.creatorReady)return false;
 unsigned amount=debug?1:5,replace=groupCount+amount>kAriseSummonLimit?groupCount+amount-kAriseSummonLimit:0;
 if(replace&&!removalAPI.detach)return false;
 const int staff=debug?debugStaff:castingStaff;
 if(!necro::IsStaff(staff))return false;
 if(!debug&&!PayAriseCost()){Log("ARISE_REJECTED: needs50FP and30stamina");return false;}
 groupUpgrade=staff-33990000;
 castRemaining=amount;groupCastSize=amount;replaceRemaining=replace;groupCastEpoch=sessionEpoch;
 Log("ARISE_ACCEPTED upgrade=%d count=%u replace_oldest=%u cost=%s",groupUpgrade,amount,replace,debug?"debug-free":"50FP/30stamina");return true;
}
static void TickGroup(const necro::Observation&o,float dt){
 if(!std::isfinite(dt)||dt<=0||dt>1)return;
 for(unsigned i=0;i<groupCount;){
  SelectGroupNPC(i);Ptr chr=0;Presence state=Probe(npcHandle,chr);
  if(state==Presence::Missing){groupNPCs[i].missing+=dt;if(groupNPCs[i].missing>=.5f){EraseGroupNPC(i);continue;}}
  else groupNPCs[i].missing=0;
  if(state==Presence::Present&&chr!=groupNPCs[i].origin){groupBlocked=true;castRemaining=replaceRemaining=0;Log("ARISE_OWNERSHIP_CHANGED: no NPC writes; restart required");return;}
  if(state==Presence::Present&&!epochInvalid&&!groupBlocked){
   Ptr mods=0,data=0;int hp=0;
   if(ReadValue(chr+0x190,mods)&&ReadValue(mods,data)&&ReadValue(data+0x138,hp)){
    groupNPCs[i].combat.Tick(playerHP,hp,playerActions,dt,playerInCombat);
    if(hp>0&&!SacrificeReserved(npcHandle)){AICommand(chr,groupNPCs[i].combat.Active()?1.f:0.f,true);CatchUp(chr,o);engine->SetAlly(sessionEpoch,npcHandle,47);necro::Position home{o.position.x-o.forwardX*2.8f,o.position.y,o.position.z-o.forwardZ*2.8f};engine->FollowHome(sessionEpoch,npcHandle,home);}
   }
  }
  ++i;
 }
 if(epochInvalid){castRemaining=replaceRemaining=0;groupManualRetire=false;if(groupCount==0&&!groupSpawnPending&&!giantBusy&&!CallHasOwnedOrPending()){epochInvalid=false;++sessionEpoch;}return;}
 if(groupSpawnPending){
  groupSpawnWait+=dt;Ptr candidate=0;uint64_t h=0;
  if(ReadValue(creatorNow+0x1b0,candidate)&&candidate&&ReadValue(candidate+8,h)&&Resolve(h)==candidate){
   int capturedNpc=0,capturedModel=0;
   if(!ReadValue(candidate+0x60,capturedNpc)||!ReadValue(candidate+0x64,capturedModel)||capturedNpc!=pendingCandidate.npc||capturedModel!=pendingCandidate.model){RestoreRiseInput();groupBlocked=true;castRemaining=0;Log("ARISE_WRONG_CANDIDATE: no ownership claimed; restart required");return;}
   bool duplicate=false;for(unsigned i=0;i<groupCount;++i)if(groupNPCs[i].handle==h)duplicate=true;
   if(duplicate||groupCount>=kAriseSummonLimit){groupBlocked=true;castRemaining=0;Log("ARISE_CAPTURE_REJECTED: restart required");return;}
   groupNPCs[groupCount]=GroupNPC{};groupNPCs[groupCount].handle=h;groupNPCs[groupCount].origin=candidate;groupNPCs[groupCount].combat.Reset();++groupCount;
   RestoreRiseInput();npcHandle=h;npcOrigin=candidate;engine->SetAlly(sessionEpoch,h,47);groupSpawnPending=false;sentOnce=false;if(castRemaining)--castRemaining;
   Ptr statModules=0,statData=0;int hp[2]={-1,-1};
   if(ReadValue(candidate+0x190,statModules)&&ReadValue(statModules,statData))Read(statData+0x138,hp,sizeof(hp));
   Log("ARISE_CREATED upgrade=%d npc=%d active=%u remaining=%u hp=%d max_hp=%d handle=%llx",groupUpgrade,capturedNpc,groupCount,castRemaining,hp[0],hp[1],(unsigned long long)h);
  }else if(groupSpawnWait>15){groupBlocked=true;castRemaining=0;Log("ARISE_SPAWN_TIMEOUT: restart required; survivors retained");}
  return;
 }
 if(!callBusy&&!giantBusy&&!groupBlocked&&castRemaining&&!replaceRemaining&&groupCount<kAriseSummonLimit&&o.creatorReady&&o.onGround&&o.staffSelected&&groupCastEpoch==sessionEpoch){
  sentOnce=false;npcHandle=0;npcOrigin=0;removalAttempted=removalFailed=false;
  const auto selected=necro::CandidateForCast(groupUpgrade,groupCastSize-castRemaining);
  necro::SpawnRequest request{selected,o.position,47,groupCastSize-castRemaining,groupCastSize};
  if(engine->Request(request)){pendingCandidate=selected;groupSpawnPending=true;groupSpawnWait=0;}
  else{castRemaining=0;Log("ARISE_SPAWN_REJECTED: batch stopped; survivors retained");}
 }
}
// Read-only, bounded diagnostic for the outstanding per-ash passive gate.
// Only on changed ash IDs, at most four polls/sec; never alters summon state.
static void ObserveAshContext(float dt){
 static float elapsed=0;static Ptr lastManager=0;static int lastRequested=-2,lastActive=-2;
 elapsed+=dt;if(elapsed<.25f)return;elapsed=0;
 Ptr manager=0;int ids[2]{};
 if(!ReadValue(worldNow+0x1e538,manager)||!manager||!Read(manager+0xe0,ids,sizeof(ids)))return;
 if(manager==lastManager&&ids[0]==lastRequested&&ids[1]==lastActive)return;
 lastManager=manager;lastRequested=ids[0];lastActive=ids[1];
 Log("ASH_CONTEXT requested_goods=%d active_goods=%d; read-only diagnostic, undead filter not active",ids[0],ids[1]);
}
// Layout reference: fromsoftware-rs cs/chr_ins.rs + cs/sp_effect.rs.
// Read-only, owner-validated, bounded list scan. No calls into unverified engine code.
#include "ImpactGate.h"
static AriseImpactGate ariseImpactGate;
static int AriseImpactMarker(){
 Ptr effects=0,head=0,owner=0;
 if(!ReadValue(playerNow+0x178,effects)||!effects||!ReadValue(effects+8,head)||!ReadValue(effects+0x10,owner)||owner!=playerNow)return -1;
 for(unsigned i=0;head&&i<128;++i){
  unsigned char entry[0x40]{};if(!Read(head,entry,sizeof(entry)))return -1;
  int id=0;Ptr next=0;memcpy(&id,entry+8,4);memcpy(&next,entry+0x30,8);
  if(id==8905200)return 1;
  if(next==head)return -1;head=next;
 }
 return head?-1:0;
}
static void PollAriseImpact(const necro::Observation&o,float dt){
 static float elapsed=0;
 if(!std::isfinite(dt)||dt<=0||dt>1)return;
 elapsed+=dt;if(elapsed<.05f)return;elapsed=0;
 if(!o.staffSelected)return; // Keep latch across a brief slot switch during the same marker.
 const int marker=AriseImpactMarker();
 if(ariseImpactGate.Observe(marker)){
  bool accepted=AriseHasPriority()&&(necro::IsCallStaff(castingStaff)?BeginCallCast(o,false):BeginGroupCast(o,false));
  Log("ARISE_ANIMATION_IMPACT accepted=%d marker=8905200",accepted);
 }
}

#include "SpellAdapter.h"
#include "CallAdapter.h"
static void ExecuteGroup(void*,const void* taskData){
 CallbackTiming timing(true);static bool hadPlayer=false,havePosition=false;static necro::Position last{};
 if(InterlockedCompareExchange(&stopped,0,0))return;
 SpellLock spellGuard;
 necro::Observation o{};if(!PlayerState(o)){ResetSpells();if(hadPlayer&&(groupCount||groupSpawnPending||giants.Count()||giantPending||CallHasOwnedOrPending()))epochInvalid=true;havePosition=false;ariseImpactGate.Reset();return;}hadPlayer=true;
 if(havePosition&&(groupCount||groupSpawnPending||giants.Count()||giantPending||CallHasOwnedOrPending())&&Distance2(last,o.position)>6400)epochInvalid=true;last=o.position;havePosition=true;
 float dt=TaskSeconds(taskData);
 static int lastCombat=-1;
 if(groupCount){int current=playerCombatReadable?(playerInCombat?1:0):-1;
  if(current!=lastCombat){Log("ARISE_PLAYER_COMBAT state=%d active=%u; -1=unreadable,0=peace,1=combat",current,groupCount);lastCombat=current;}
 }else lastCombat=-1;
 TickSpells(o,dt);ObserveAshContext(dt);SpiritFollow(o);TickCall(o,dt);TickGroup(o,dt);
 PollAriseImpact(o,dt);
}
static void ExecuteGroupRetirement(void*,const void* taskData){
 CallbackTiming timing(false);unsigned phase=0;
 if(InterlockedCompareExchange(&stopped,0,0)||!taskData||!ReadValue((Ptr)taskData+0x10,phase)||!IsRetirementPhase(phase))return;
 SpellLock spellGuard;
 RetireCall();
 if(callBusy)return;
 RetireGiants();
 if(giantBusy||groupBlocked||epochInvalid||groupSpawnPending||(!replaceRemaining&&!groupManualRetire))return;
 if(!groupCount){replaceRemaining=0;groupManualRetire=false;return;}
 necro::Observation o{};if(!PlayerState(o)||epochInvalid)return;
 SelectGroupNPC(0);removalAttempted=removalFailed=false;removalPhase=true;
 bool ok=RetireOwned(sessionEpoch,npcHandle);removalPhase=false;
 if(ok){EraseGroupNPC(0);if(replaceRemaining)--replaceRemaining;groupManualRetire=false;sentOnce=false;npcHandle=0;npcOrigin=0;Log("ARISE_OLDEST_REMOVED active=%u replace_remaining=%u",groupCount,replaceRemaining);}
 else{castRemaining=replaceRemaining=0;groupManualRetire=false;if(removalAttempted||removalFailed)groupBlocked=true;Log("ARISE_REMOVE_REJECTED blocked=%d; no more replacements",groupBlocked);}
}
