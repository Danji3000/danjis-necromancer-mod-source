#pragma once
// Four game sites calculate BehaviorParam/Magic stamina costs. Movement HKS
// AddStamina, guard damage, regeneration and native summon skills bypass them.
static bool AttackCostSite(uintptr_t rva){
 return rva==0x3c08d5||rva==0x3c0e1a||rva==0x44044f||rva==0x4433eb;
}
static int DiscountCost(int cost,bool active,bool local,bool valid,uintptr_t site){
 return cost>0&&active&&local&&valid&&AttackCostSite(site)?cost/2:cost;
}
using CalculateCost=int(*)(Ptr,int,int,unsigned char,unsigned);
static CalculateCost originalCost=nullptr;
static unsigned costReports=0;
static int HookAttackCost(Ptr chr,int amount,int reference,unsigned char flag,unsigned mode){
 const Ptr site=(Ptr)__builtin_return_address(0)-base;
 const int cost=originalCost(chr,amount,reference,flag,mode);
 if(cost<=0||chr!=playerNow||!AttackCostSite(site))return cost;
 SpellLock guard;
 Ptr data=0;
 const bool local=chr==playerNow;
 const bool active=!epochInvalid&&covenant.Active(spellTime,sessionEpoch);
 const bool valid=local&&active&&CurrentPlayerData(data);
 const int result=DiscountCost(cost,active,local,valid,site);
 if(result!=cost&&costReports++<80)Log("COVENANT_STAMINA site=%llx base=%d result=%d player_only=1",(unsigned long long)site,cost,result);
 return result;
}
static bool ConfigureStaminaDiscount(){
 static const unsigned char signature[]={0x48,0x89,0x6c,0x24,0x10,0x48,0x89,0x74,0x24,0x18,0x48,0x89,0x7c,0x24,0x20,0x41,0x56,0x48,0x83,0xec,0x60};
 unsigned char observed[sizeof(signature)];
 if(!Read(base+0x653190,observed,sizeof(observed))||memcmp(observed,signature,sizeof(signature))){Log("COVENANT_STAMINA disabled: signature mismatch");return false;}
 MH_STATUS status=MH_CreateHook((void*)(base+0x653190),(void*)&HookAttackCost,(void**)&originalCost);
 if(status==MH_OK)status=MH_EnableHook((void*)(base+0x653190));
 Log("COVENANT_STAMINA status=%d attack_spell_cost=50%% player_only=1 whitelisted_sites=4",int(status));
 return status==MH_OK;
}

