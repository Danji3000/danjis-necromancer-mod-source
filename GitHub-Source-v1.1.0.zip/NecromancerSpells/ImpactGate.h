#pragma once
// Unknown reads preserve the latch; a sustained marker can never trigger twice.
struct AriseImpactGate {
 bool latched=false;
 void Reset(){latched=false;}
 bool Observe(int state){if(state<0)return false;if(!state){latched=false;return false;}if(latched)return false;latched=true;return true;}
};
