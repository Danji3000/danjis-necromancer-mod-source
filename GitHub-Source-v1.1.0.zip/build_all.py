import pathlib, subprocess, shutil, sys, hashlib, json, os
root=pathlib.Path(__file__).resolve().parent
zig=pathlib.Path(os.environ['FP_ZIG']).resolve()
assert subprocess.check_output([str(zig),'version'],text=True).strip()=='0.15.2','Use Zig 0.15.2'
results=[]
for m in json.loads((root/'modules.json').read_text()):
 dest=root/'_build'/m['module']
 shutil.copytree(root/m['module'],dest,dirs_exist_ok=True)
 subprocess.run([sys.executable,str(dest/m['build']),m['main'],m['output']],check=True)
 binary=dest/m['output']; digest=hashlib.sha256(binary.read_bytes()).hexdigest()
 matched=digest==m['sha256']
 results.append(dict(module=m['module'],sha256=digest,release_sha256=m['sha256'],identical=matched))
 native=root/'_build/native'; native.mkdir(exist_ok=True)
 shutil.copy2(binary,native/m['release'])
 print(m['module'], 'IDENTICAL' if matched else 'DIFFERENT',flush=True)
(root/'_build/verification.json').write_text(json.dumps(results,indent=2)+'\n')
if not all(r['identical'] for r in results): sys.exit('One or more builds differ from the released DLLs; see verification.json.')
